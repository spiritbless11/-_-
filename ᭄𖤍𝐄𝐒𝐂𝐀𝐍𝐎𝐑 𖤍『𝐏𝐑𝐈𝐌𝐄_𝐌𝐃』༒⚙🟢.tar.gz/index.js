/**
╔═══════════════════════════════════════════════════════════════╗
║   ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒  WhatsApp Bot                 ║
║  Le Lion de l'Orgueil – Celui qui se tient au-dessus de tout  ║
║  Copyright (c) 2025 par ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒     ║
║  Version PRIME – Puissance absolue                           ║
╚═══════════════════════════════════════════════════════════════╝
*/

require('./settings');
const { Boom } = require('@hapi/boom');
const fs = require('fs');
const { rmSync } = require('fs');
const chalk = require('chalk');
const path = require('path');
const axios = require('axios');
const { handleMessages, handleGroupParticipantUpdate, handleStatus } = require('./main');
const PhoneNumber = require('awesome-phonenumber');
const { smsg, jidDecode, delay } = require('./lib/myfunc');
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore
} = require("@whiskeysockets/baileys");
const NodeCache = require("node-cache");
const pino = require("pino");
const readline = require("readline");
const QRCode = require('qrcode-terminal');
const store = require('./lib/lightweight_store');
const settings = require('./settings');

// 🗄️ Initialisation du Store
store.readFromFile();
setInterval(() => store.writeToFile(), settings.storeWriteInterval || 10000);

// 🔧 MONITEUR MÉMOIRE CORRIGÉ (Ne tue PLUS le processus)
setInterval(() => {
    const used = process.memoryUsage().rss / 1024 / 1024;
    console.log(`📊 Mémoire RAM utilisée: ${used.toFixed(2)} MB`);
    
    if (used > 900) {
        console.log('⚠️ Mémoire élevée détectée. Le Lion surveille...');
        if (global.gc) {
            global.gc();
            console.log('⚡ Nettoyage mémoire forcé effectué.');
        }
    }
}, 60_000);
// Garbage collector manuel
setInterval(() => {
    if (global.gc) {
        global.gc();
        console.log('⚡ Puissance concentrée – Nettoyage des âmes faibles effectué.');
    }
}, 60_000);

const pairingCode = false;
const userPhoneNumber = "243832881281";
let owner = JSON.parse(fs.readFileSync('./data/owner.json'));
global.botname = " ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒";
global.themeemoji = "☀️";

const rl = process.stdin.isTTY ? readline.createInterface({ input: process.stdin, output: process.stdout }) : null;
const question = (text) => rl ? new Promise(resolve => rl.question(text, resolve)) : Promise.resolve(settings.ownerNumber || userPhoneNumber);

async function startEscanorPrime() {
    try {
        let { version } = await fetchLatestBaileysVersion();
        const { state, saveCreds } = await useMultiFileAuthState(`./session`);
        const msgRetryCounterCache = new NodeCache();

        const EscanorPrime = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            printQRInTerminal: false,
            browser: ["EscanorPrime", "Chrome", "120.0.0"],
            auth: {
                creds: state.creds,
                keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" }).child({ level: "fatal" })),
            },
            markOnlineOnConnect: true,
            generateHighQualityLinkPreview: true,
            syncFullHistory: false,
            getMessage: async (key) => {
                const jid = jidDecode(key.remoteJid);
                const msg = await store.loadMessage(jid, key.id);
                return msg?.message || "";
            },
            msgRetryCounterCache,
            defaultQueryTimeoutMs: 60000,
            connectTimeoutMs: 60000,
            keepAliveIntervalMs: 10000,
        });

        EscanorPrime.ev.on('creds.update', saveCreds);
        store.bind(EscanorPrime.ev);
        EscanorPrime.decodeJid = (jid) => {
            if (!jid) return jid;
            if (/:\d+@/gi.test(jid)) {
                const decode = jidDecode(jid) || {};
                return decode.user && decode.server ? decode.user + '@' + decode.server : jid;
            }
            return jid;
        };

        EscanorPrime.public = true;
        EscanorPrime.serializeM = m => smsg(EscanorPrime, m, store);

        // 🔄 RELOAD DES COMMANDES – SANS SURVEILLER SESSION/
        const reloadCommands = () => {
            Object.keys(require.cache).forEach((key) => {
                if (key.includes('/commands/') || key.includes('/welcome') || key.includes('/help')) {
                    delete require.cache[key];
                }
            });
        };
        
        reloadCommands();
        
        // ✅ SURVEILLANCE SÉCURISÉE – N'WATCH PAS session/ ni temp/
        try {
            // Watch uniquement le dossier commands
            if (fs.existsSync('./commands')) {
                fs.watch('./commands', (eventType, filename) => {
                    if (filename && filename.endsWith('.js')) {
                        console.log(`🔄 Commande modifiée: ${filename}`);
                        reloadCommands();
                    }
                });
                console.log('✅ Surveillance des commandes activée');
            }
            
            // Watch les fichiers principaux (NON récursif pour éviter la boucle)
            const filesToWatch = ['./main.js', './settings.js', './config.js'];
            filesToWatch.forEach(file => {
                if (fs.existsSync(file)) {
                    fs.watch(file, () => {
                        console.log(`🔄 Fichier modifié: ${file}`);
                        reloadCommands();
                    });
                }
            });
            
        } catch (e) {
            console.log('⚠️ Surveillance des fichiers désactivée (mode hébergé détecté).');
            console.error('Erreur fs.watch:', e.message);        }

        EscanorPrime.ev.on('messages.upsert', async chatUpdate => {
            try {
                const mek = chatUpdate.messages[0];
                if (!mek.message) return;
                mek.message = Object.keys(mek.message)[0] === 'ephemeralMessage' ? mek.message.ephemeralMessage.message : mek.message;
                try { 
                    await handleMessages(EscanorPrime, chatUpdate, true); 
                } catch (err) { 
                    console.error("Erreur handleMessages: ", err); 
                }
            } catch (err) { 
                console.error("Erreur messages.upsert: ", err); 
            }
        });

        EscanorPrime.ev.on('group-participants.update', async update => { 
            await handleGroupParticipantUpdate(EscanorPrime, update); 
        });
        
        EscanorPrime.ev.on('status.update', async status => { 
            await handleStatus(EscanorPrime, status); 
        });
        
        EscanorPrime.ev.on('messages.reaction', async status => { 
            await handleStatus(EscanorPrime, status); 
        });

        EscanorPrime.ev.on('connection.update', async (s) => {
            const { connection, lastDisconnect, qr } = s;
            
            if (qr) {
                QRCode.generate(qr, { small: true });
            }
            
            if (connection === 'connecting') {
                console.log(chalk.yellow('🔥 Connexion en cours...'));
            }
            
            if (connection === 'open') {
                console.log(chalk.green('☀️ LE LION EST RÉVEILLÉ ☀️'));
            }
            
            if (connection === 'close') {
                const statusCode = lastDisconnect?.error?.output?.statusCode;
                const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
                
                if (statusCode === DisconnectReason.loggedOut) {
                    console.log('🚫 Session expirée. Suppression des fichiers de session...');                    try {
                        rmSync('./session', { recursive: true, force: true });
                    } catch (e) {
                        console.error('Erreur suppression session:', e);
                    }
                }
                
                if (shouldReconnect) {
                    console.log(`🔄 Reconnexion dans 5 secondes... (Code: ${statusCode || 'Inconnu'})`);
                    await delay(5000);
                    startEscanorPrime();
                } else {
                    console.log('❌ Connexion définitivement fermée.');
                    process.exit(0); // ✅ Exit propre pour arrêter la boucle
                }
            }
        });

        // Anti-Call
        const antiCallNotified = new Set();
        EscanorPrime.ev.on('call', async calls => {
            const { readState: readAnticallState } = require('./commands/anticall');
            const anticallState = readAnticallState();
            if (!anticallState.enabled) return;
            
            for (const call of calls) {
                const callerJid = call.from || call.peerJid || call.chatId;
                if (!callerJid) continue;
                
                try {
                    if (!antiCallNotified.has(callerJid)) {
                        antiCallNotified.add(callerJid);
                        setTimeout(() => antiCallNotified.delete(callerJid), 60000);
                        await EscanorPrime.sendMessage(callerJid, { 
                            text: '☀️ *OSES-TU DÉRANGER LE LION ?* ☀️\nAppel rejeté. Tu vas être bloqué.' 
                        });
                    }
                } catch (e) {
                    console.error('Erreur anti-call:', e);
                }
                
                setTimeout(async () => { 
                    try { 
                        await EscanorPrime.updateBlockStatus(callerJid, 'block'); 
                    } catch (e) { 
                        console.error('Erreur block:', e);
                    } 
                }, 800);
            }
        });
        return EscanorPrime;
    } catch (error) {
        console.error('Erreur startEscanorPrime:', error);
        await delay(5000);
        startEscanorPrime();
    }
}

startEscanorPrime().catch(error => { 
    console.error('Erreur fatale:', error); 
    process.exit(1); 
});

// Filets de sécurité – NE TUE PAS LE PROCESSUS
process.on('uncaughtException', (err) => {
    console.error('☀️ Exception non capturée:', err);
    // Ne pas appeler process.exit() – laisser Baileys gérer
});

process.on('unhandledRejection', (err) => {
    console.error('☀️ Promesse rejetée non gérée:', err);
    // Ne pas appeler process.exit() – laisser Baileys gérer
});