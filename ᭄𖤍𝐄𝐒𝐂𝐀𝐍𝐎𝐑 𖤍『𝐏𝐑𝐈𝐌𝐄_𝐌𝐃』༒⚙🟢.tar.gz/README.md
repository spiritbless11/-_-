# ☀️ ༒ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ ☀️

**Le Lion de l'Orgueil – Celui qui se tient au-dessus de tout**

Ce bot WhatsApp est construit avec la bibliothèque Baileys. Il incarne la puissance absolue d'Escanor, le Lion de l'Orgueil. Conçu pour la gestion de groupes, il permet de mentionner tous les membres, muter/réactiver, et bien plus encore. Il est destiné à aider les administrateurs à gérer efficacement leurs groupes WhatsApp.

<div align="center"> 
  <a href="https://git.io/typing-svg"> 
    <img src="https://readme-typing-svg.demolab.com?font=Ribeye&size=50&pause=1000&color=FF4500&center=true&width=910&height=100&lines=ESCCANOR+PRIME;Multi+Device+Whatsapp+Bot;Coded+By+BLESSDEV" alt="Typing SVG" />
  </a> 
</div> 

<div align="center"> 
  <a href="https://whatsapp.com/channel/0029VbCkNJH47XeGyXRusZ0K"> 
    <img src="https://github.com/mruniquehacker/Knightbot-MD/blob/main/assets/bot_image.jpg" alt="Escanor Prime" height="300"> 
  </a> 
</div>

<div align="center">
  <img src="https://img.shields.io/github/followers/mruniquehacker?style=for-the-badge&label=Followers" alt="Followers"/>
  <img src="https://img.shields.io/github/stars/mruniquehacker/Knightbot-MD?style=for-the-badge&label=Stars" alt="Stars"/>
  <img src="https://img.shields.io/github/forks/mruniquehacker/Knightbot-MD?style=for-the-badge&label=Forks" alt="Forks"/>
  <img src="https://img.shields.io/github/watchers/mruniquehacker/Knightbot-MD?style=for-the-badge&label=Watchers" alt="Watchers"/>
</div>

---
<div>
  <a href="https://www.thordata.com/products/residential-proxies?ls=YouTube&lk=Knightbot" target="_blank">
    <img src="assets/thor.png" alt="ThorData Proxies" width="100%" />
  </a>
</div>

<br>

<div align="left">
  <b>Thordata: Obtenez des proxys mondiaux fiables à un prix imbattable.</b><br><br>
  Collecte de données en un clic avec une stabilité et une conformité de niveau entreprise.<br>
  Rejoignez les milliers de développeurs qui utilisent ThorData pour des opérations à grande échelle.<br><br>
  🎁 <b>Offre exclusive :</b> Inscrivez-vous pour un essai gratuit de proxy résidentiel et 2 000 <b>appels API SERP GRATUITS !</b>
</div>

<br>

<div align="left">
  <a href="https://www.thordata.com/products/residential-proxies?ls=YouTube&lk=Knightbot" target="_blank">
    <img src="https://img.shields.io/badge/À tester maintenant-28a745?style=for-the-badge" alt="Try now"/>
  </a>
</div>

---

## 🚀 Étapes pour déployer le bot

### Étape 1 : Fork le dépôt

Cliquez sur le bouton ci-dessous pour forker le dépôt du bot Escanor Prime vers votre compte GitHub :

<div align="center">
  <a href="https://github.com/mruniquehacker/Knightbot-MD/fork">
    <img src="https://img.shields.io/badge/Fork-Repository-blue?style=for-the-badge" alt="Fork the repository"/>
  </a>
</div>

---

### Étape 2 : Obtenir le code de pairage

Déployez le bot et connectez-le facilement à votre compte WhatsApp via un code de pairage. Cliquez sur le bouton ci-dessous pour déployer le bot sur Replit.

<div align="center">
  <a href="https://knight-bot-paircode.onrender.com" target="_blank">
    <img src="https://img.shields.io/badge/OBTENIR%20LE%20CODE%20DE%20PAIRAGE-Méthode%20Facile-ff4d4d?style=for-the-badge" alt="Generate Pair Code"/>
  </a>
</div>

### Après avoir obtenu le fichier creds.json, uploadez-le dans le dossier session

---

### Étape 3 : Déployer maintenant

Pour plus de personnalisation et de conseils d'installation, cliquez sur le bouton ci-dessous :

<div align="center">
  <a href="https://youtu.be/-oz_u1iMgf8">
    <img src="https://img.shields.io/badge/Tutoriel de déploiement-dc3545?style=for-the-badge&logo=youtube" alt="YouTube Link"/>
  </a>
  <a href="https://bot-hosting.net/?aff=1068419752923508776">
    <img src="https://img.shields.io/badge/Déployer sur Panel-28a745?style=for-the-badge" alt="Deploy on Panel"/>
  </a>
</div>

### Déployer sur VPS

<div align="center">
  <a href="https://client.petrosky.io/aff.php?aff=394" target="_blank">
    <img src="https://img.shields.io/badge/petrosky vps-0078E7?style=for-the-badge" alt="petrosky vps"/>
  </a>
</div>

### Déployer sur le panel ci-dessous
<div align="center">
<a href="https://dashboard.katabump.com/auth/login#d6b7d6" target="_blank">
  <img src="https://img.shields.io/badge/Katabump-D6B7D6?style=for-the-badge&logo=server&logoColor=black" alt="Katabump"/>
</a>
</div>

### Rejoignez-nous

<div align="center">
  <a href="https://t.me/+3QhFUZHx-nhhZmY1">
    <img src="https://img.shields.io/badge/Rejoindre Telegram-0078E7?style=for-the-badge&logo=telegram&logoColor=white" alt="Join Telegram"/>
  </a>
  <a href="https://whatsapp.com/channel/0029VbCkNJH47XeGyXRusZ0K">
    <img src="https://img.shields.io/badge/Rejoindre WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" alt="Join WhatsApp"/>
  </a>
</div>

---

## ⚙️ Fonctionnalités

- **Mentionner tous les membres du groupe** avec la commande `.tagall`
- **Utilisation restreinte aux administrateurs** (Seuls les admins du groupe peuvent utiliser certaines commandes)
- **Jeux** comme le Tic-Tac-Toe pour l'engagement interactif en groupe
- **Synthèse vocale** avec `.tts`
- **Création de stickers** avec `.sticker`
- **Détection anti-liens** pour la sécurité des groupes
- **Avertir et gérer les membres du groupe** avec contrôle administrateur

---

## 📖 À propos

Le bot WhatsApp Escanor Prime aide les administrateurs de groupes en leur fournissant des outils pour gérer efficacement les grands groupes WhatsApp. Le bot utilise la bibliothèque Baileys pour interagir avec l'API WhatsApp Web et prend en charge les fonctionnalités multi-appareils.

Il est léger et peut être facilement personnalisé pour ajouter plus de commandes selon vos besoins. Le bot fonctionne dans un environnement Node.js et fournit une authentification basée sur QR code pour lier votre compte WhatsApp.

---

## 🛠️ Installation et configuration

### Prérequis

- Node.js installé sur votre système
- Git installé (pour cloner le dépôt)

### Installation étape par étape

1. **Cloner le dépôt :**

    ```bash
    git clone https://github.com/mruniquehacker/Knightbot-MD.git
    cd Knightbot-MD
    ```

2. **Installer les dépendances :**

    ```bash
    npm install
    ```

3. **Lancer le bot :**

    ```bash
    node index.js
    ```

4. **Scanner le QR code :**

    Une fois le bot démarré, un QR code apparaîtra dans le terminal. Scannez ce QR code en utilisant la fonction "Appareils liés" de WhatsApp pour connecter votre compte WhatsApp au bot.

---

## 📄 Licence

Ce projet est sous licence [MIT License](https://opensource.org/licenses/MIT) – voir le fichier [LICENSE](https://github.com/mruniquehacker/Knightbot-MD/blob/main/LICENSE) pour plus de détails.

---

## 🙌 Contributions

Les contributions, les problèmes et les demandes de fonctionnalités sont les bienvenus ! N'hésitez pas à consulter la [page des issues](https://github.com/mruniquehacker/Knightbot-MD/issues).

---

## 🌟 Montrez votre soutien

Si ce projet vous plaît, n'hésitez pas à lui donner [⭐️ une étoile sur GitHub](https://github.com/mruniquehacker/Knightbot) !

## Crédits

- [BLESSDEV](https://github.com/mruniquehacker) – Maître suprême, celui qui a dompté le Lion
- [Baileys](https://github.com/adiwajshing/Baileys) – La base de la puissance
- [TechGod143](https://github.com/TechGod143) – Pour le code de pairage
- [Dgxeon](https://github.com/Dgxeon) – Pour le code de pairage

---

## ⚠️ Avertissement important

**Note :** Ce bot est créé à des fins éducatives uniquement. Ce n'est PAS un bot WhatsApp officiel. L'utilisation de ce bot peut entraîner le bannissement de votre compte WhatsApp. Utilisez-le à vos propres risques. Les développeurs ne seront pas tenus responsables des conséquences ou des bannissements de compte qui pourraient survenir lors de l'utilisation de ce bot.

## 📝 Légal

- Ce projet n'est pas affilié, autorisé, maintenu, sponsorisé ou approuvé par WhatsApp ou l'une de ses filiales ou sociétés affiliées.
- Il s'agit d'un logiciel indépendant et non officiel. À utiliser à vos propres risques.
- N'utilisez pas ce bot pour spammer les gens.
- N'utilisez pas ce bot pour envoyer des messages en masse ou à des fins illégales.
- Les développeurs n'assument aucune responsabilité et ne sont pas responsables de toute utilisation abusive ou de tout dommage causé par ce programme.

### Licence
Ce projet est sous licence MIT. Cependant, vous devez :
- Utiliser ce logiciel conformément à toutes les lois et réglementations applicables
- Inclure la licence originale et les avis de droit d'auteur
- Créditer les auteurs originaux
- Ne pas l'utiliser à des fins de spam ou malveillantes

## 📜 Avis de droit d'auteur

Copyright (c) 2024 BLESSDEV. Tous droits réservés.

Ce projet contient du code provenant de divers projets open source :
- Baileys (Licence MIT)
- Autres bibliothèques listées dans package.json

---

☀️ *"Je suis celui qui se tient au-dessus de tout. Qui ose me défier ?"* – Escanor, Le Lion de l'Orgueil ☀️