/**
 * ☀️ COMMANDE GROUPMANAGE – ESCANOR PRIME ☀️
 * Gestion complète d'un groupe : nom, description, photo – avec l'autorité du Lion
 */

const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const sendStyledMessage = require('../utils/sendStyledMessage');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE – BOUTON CHAÎNE + IMAGE FALLBACK
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

const FALLBACK_IMAGE = 'https://i.imgur.com/2wzGhpF.jpeg';

// ============================================================================
// 🔐 VÉRIFICATION GROUPE + PERMISSIONS – FONCTION INTERNE
// ============================================================================
async function ensureGroupAndAdmin(sock, chatId, senderId, message) {
    const isGroup = chatId.endsWith('@g.us');
    if (!isGroup) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *CETTE COMMANDE N'EST DISPONIBLE QU'EN GROUPE.* ☀️\n\n⚡ *LE LION NE RÈGNE QUE SUR SON DOMAINE.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        return { ok: false };
    }
    
    const isAdmin = require('../lib/isAdmin');
    const adminStatus = await isAdmin(sock, chatId, senderId);
    
    if (!adminStatus.isBotAdmin) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️\n\n⚡ *LE LION NE PEUT GÉRER SANS AUTORITÉ.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        return { ok: false };
    }    
    if (!adminStatus.isSenderAdmin) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *SEULS LES ADMINISTRATEURS PEUVENT GÉRER LE GROUPE.* ☀️\n\n⚠️ *TU N'AS PAS LE POUVOIR DE COMMANDER LE LION.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        return { ok: false };
    }
    
    return { ok: true };
}

// ============================================================================
// 📝 .SETGDESC – METTRE À JOUR LA DESCRIPTION DU GROUPE
// ============================================================================
async function setGroupDescription(sock, chatId, senderId, text, message) {
    const check = await ensureGroupAndAdmin(sock, chatId, senderId, message);
    if (!check.ok) return;
    
    const desc = (text || '').trim();
    if (!desc) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *UTILISATION – DÉFINIR LA DESCRIPTION* ☀️\n\n⚡ *.setgdesc <ton texte ici>*\n\n☀️ *DONNE UN ORDRE CLAIR AU LION.* ☀️`, 
            message, [], channelContext
        );
        return;
    }
    
    try {
        await sock.groupUpdateDescription(chatId, desc);
        await sendStyledMessage(sock, chatId, 
            `☀️ *DESCRIPTION DU DOMAINE MISE À JOUR.* ☀️\n\n📝 *NOUVEAU TEXTE:*\n_${desc}_\n\n🔥 *LE LION A GRAVÉ TES MOTS DANS LA PIERRE.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    } catch (e) {
        console.error('☀️ ERREUR SETGDESC:', e);
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DE LA MISE À JOUR.* ☀️\n\n⚠️ *LE LION RENCONTRE UN OBSTACLE. VÉRIFIE TES PRÉR OGATIVES ET RÉESSAIE.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

// ============================================================================
// 📛 .SETGNAME – METTRE À JOUR LE NOM DU GROUPE
// ============================================================================
async function setGroupName(sock, chatId, senderId, text, message) {
    const check = await ensureGroupAndAdmin(sock, chatId, senderId, message);
    if (!check.ok) return;
        const name = (text || '').trim();
    if (!name) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *UTILISATION – RENOMMER LE DOMAINE* ☀️\n\n⚡ *.setgname <nouveau nom>*\n\n☀️ *DONNE UN NOM DIGNE DU LION.* ☀️`, 
            message, [], channelContext
        );
        return;
    }
    
    try {
        await sock.groupUpdateSubject(chatId, name);
        await sendStyledMessage(sock, chatId, 
            `☀️ *NOM DU DOMAINE MIS À JOUR.* ☀️\n\n📛 *NOUVEAU NOM:* ${name.toUpperCase()}\n\n🔥 *CE NOM RÉSONNERA DANS TOUT LE ROYAUME.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    } catch (e) {
        console.error('☀️ ERREUR SETGNAME:', e);
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DE LA MISE À JOUR.* ☀️\n\n⚠️ *LE LION RENCONTRE UN OBSTACLE. VÉRIFIE TES PRÉR OGATIVES ET RÉESSAIE.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

// ============================================================================
// 🖼️ .SETGPP – METTRE À JOUR LA PHOTO DE GROUPE
// ============================================================================
async function setGroupPhoto(sock, chatId, senderId, message) {
    const check = await ensureGroupAndAdmin(sock, chatId, senderId, message);
    if (!check.ok) return;

    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    const imageMessage = quoted?.imageMessage || quoted?.stickerMessage;
    
    if (!imageMessage) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *UTILISATION – CHANGER L'EMBLÈME DU DOMAINE* ☀️\n\n⚡ *RÉPONDS À UNE IMAGE/STICKER AVEC .setgpp*\n\n☀️ *LE LION ATTEND TON SYMBOLE.* ☀️`, 
            message, [], channelContext
        );
        return;
    }
    
    try {
        // 📁 Préparation du dossier temporaire
        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

        // 📥 Téléchargement de l'image
        const stream = await downloadContentFromMessage(imageMessage, 'image');
        let buffer = Buffer.from([]);        for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

        const imgPath = path.join(tmpDir, `gpp_${Date.now()}.jpg`);
        fs.writeFileSync(imgPath, buffer);

        // 🖼️ Mise à jour de la photo de groupe
        await sock.updateProfilePicture(chatId, { url: imgPath });
        
        // 🧹 Nettoyage du fichier temporaire
        try { fs.unlinkSync(imgPath); } catch (_) {}
        
        await sendStyledMessage(sock, chatId, 
            `☀️ *EMBLÈME DU DOMAINE MIS À JOUR.* ☀️\n\n🖼️ *NOUVEAU SYMBOLE APPLIQUÉ.*\n\n🔥 *CE SIGNE REPRÉSENTE DÉSORMAIS L'AUTORITÉ DU LION.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`, 
            message, [], { ...channelContext, image: { url: imgPath } } // ✅ Utiliser la nouvelle photo comme image du message
        );
        
    } catch (e) {
        console.error('☀️ ERREUR SETGPP:', e);
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DE LA MISE À JOUR.* ☀️\n\n⚠️ *LE LION RENCONTRE UN OBSTACLE. VÉRIFIE L'IMAGE ET RÉESSAIE.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

// ============================================================================
// 📦 EXPORTS
// ============================================================================
module.exports = {
    setGroupDescription,
    setGroupName,
    setGroupPhoto
};