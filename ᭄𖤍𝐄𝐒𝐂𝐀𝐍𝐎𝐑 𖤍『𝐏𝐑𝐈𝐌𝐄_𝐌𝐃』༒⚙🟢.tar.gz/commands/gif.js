const axios = require('axios');
const settings = require('../settings');

async function gifCommand(sock, chatId, query) {
    const apiKey = settings.giphyApiKey;

    if (!query) {
        await sock.sendMessage(chatId, { text: '☀️ *DONNE-MOI UNE RECHERCHE DE GIF, MORTEL.* ☀️' });
        return;
    }

    try {
        const response = await axios.get(`https://api.giphy.com/v1/gifs/search`, {
            params: {
                api_key: apiKey,
                q: query,
                limit: 1,
                rating: 'g'
            }
        });

        const gifUrl = response.data.data[0]?.images?.downsized_medium?.url;

        if (gifUrl) {
            await sock.sendMessage(chatId, { video: { url: gifUrl }, caption: `☀️ Voici ton GIF pour "${query}" – Profite-en, mortel. ☀️` });
        } else {
            await sock.sendMessage(chatId, { text: '☀️ *AUCUN GIF TROUVÉ.* ☀️\nLe Lion n\'a rien trouvé pour ta requête.' });
        }
    } catch (error) {
        console.error('☀️ Erreur lors de la récupération du GIF:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION DU GIF.* ☀️\nRéessaie, mortel.' });
    }
}

module.exports = gifCommand;