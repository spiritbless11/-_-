const fs = require('fs');
const path = require('path');
const isOwnerOrSudo = require('../lib/isOwner');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '☀️ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ ☀️',
            serverMessageId: -1
        }
    }
};

// Liste des emojis pour réagir aux statuts
const statusEmojis = [
    '☀️', '🔥', '🦁', '👑', '💪', '✨', '🌟', '⭐', '🌞', '⚡',
    '❤️', '💛', '💚', '💙', '💜', '🖤', '🤍', '🤎', '💗', '💓',
    '👍', '👏', '🙌', '🤝', '💯', '🎉', '🥳', '🎊', '🏆', '👑'
];

// Path to store auto status configuration
const configPath = path.join(__dirname, '../data/autoStatus.json');

// Initialize config file if it doesn't exist
if (!fs.existsSync(configPath)) {
    fs.writeFileSync(configPath, JSON.stringify({ 
        enabled: false, 
        reactOn: false 
    }));
}

// Fonction pour obtenir un emoji aléatoire
function getRandomEmoji() {
    return statusEmojis[Math.floor(Math.random() * statusEmojis.length)];
}

async function autoStatusCommand(sock, chatId, msg, args) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *SEUL MON MAÎTRE PEUT UTILISER CETTE COMMANDE.* ☀️\nLe Lion n\'obéit qu\'à celui qui l\'a dompté.',
                ...channelInfo
            });
            return;
        }

        // Read current config
        let config = JSON.parse(fs.readFileSync(configPath));

        // If no arguments, show current status
        if (!args || args.length === 0) {
            const status = config.enabled ? 'activé' : 'désactivé';
            const reactStatus = config.reactOn ? 'activées' : 'désactivées';
            await sock.sendMessage(chatId, { 
                text: `☀️ *AUTOSTATUS – LA VIGILANCE DU LION* ☀️\n\n📱 *Auto-status:* ${status}\n💫 *Réactions aux statuts:* ${reactStatus}\n\n*Commandes:*\n.autostatus on - Activer l'auto-status\n.autostatus off - Désactiver l'auto-status\n.autostatus react on - Activer les réactions\n.autostatus react off - Désactiver les réactions`,
                ...channelInfo
            });
            return;
        }

        // Handle on/off commands
        const command = args[0].toLowerCase();
        
        if (command === 'on') {
            config.enabled = true;
            fs.writeFileSync(configPath, JSON.stringify(config));
            await sock.sendMessage(chatId, { 
                text: '☀️ *AUTO-STATUS ACTIVÉ* ☀️\nLe Lion regarde désormais tous les statuts automatiquement.',
                ...channelInfo
            });
        } else if (command === 'off') {
            config.enabled = false;
            fs.writeFileSync(configPath, JSON.stringify(config));
            await sock.sendMessage(chatId, { 
                text: '☀️ *AUTO-STATUS DÉSACTIVÉ* ☀️\nLe Lion baisse sa garde... pour l\'instant.',
                ...channelInfo
            });
        } else if (command === 'react') {
            // Handle react subcommand
            if (!args[1]) {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *COMMANDE INCOMPLÈTE* ☀️\nUtilisation: .autostatus react on/off',
                    ...channelInfo
                });
                return;
            }
            
            const reactCommand = args[1].toLowerCase();
            if (reactCommand === 'on') {
                config.reactOn = true;
                fs.writeFileSync(configPath, JSON.stringify(config));
                await sock.sendMessage(chatId, { 
                    text: '☀️ *RÉACTIONS AUX STATUTS ACTIVÉES* ☀️\nLe Lion réagit désormais aux statuts.',
                    ...channelInfo
                });
            } else if (reactCommand === 'off') {
                config.reactOn = false;
                fs.writeFileSync(configPath, JSON.stringify(config));
                await sock.sendMessage(chatId, { 
                    text: '☀️ *RÉACTIONS AUX STATUTS DÉSACTIVÉES* ☀️\nLe Lion ne réagit plus aux statuts.',
                    ...channelInfo
                });
            } else {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *COMMANDE INVALIDE* ☀️\nUtilisation: .autostatus react on/off',
                    ...channelInfo
                });
            }
        } else {
            await sock.sendMessage(chatId, { 
                text: '☀️ *COMMANDE INVALIDE* ☀️\nUtilisation:\n.autostatus on/off - Activer/désactiver l\'auto-status\n.autostatus react on/off - Activer/désactiver les réactions',
                ...channelInfo
            });
        }

    } catch (error) {
        console.error('☀️ Erreur dans la commande autostatus:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            ...channelInfo
        });
    }
}

// Function to check if auto status is enabled
function isAutoStatusEnabled() {
    try {
        const config = JSON.parse(fs.readFileSync(configPath));
        return config.enabled;
    } catch (error) {
        console.error('☀️ Erreur lors de la vérification de la config auto-status:', error);
        return false;
    }
}

// Function to check if status reactions are enabled
function isStatusReactionEnabled() {
    try {
        const config = JSON.parse(fs.readFileSync(configPath));
        return config.reactOn;
    } catch (error) {
        console.error('☀️ Erreur lors de la vérification des réactions status:', error);
        return false;
    }
}

// Function to react to status with random emoji
async function reactToStatus(sock, statusKey) {
    try {
        if (!isStatusReactionEnabled()) {
            return;
        }

        const randomEmoji = getRandomEmoji();

        await sock.relayMessage(
            'status@broadcast',
            {
                reactionMessage: {
                    key: {
                        remoteJid: 'status@broadcast',
                        id: statusKey.id,
                        participant: statusKey.participant || statusKey.remoteJid,
                        fromMe: false
                    },
                    text: randomEmoji
                }
            },
            {
                messageId: statusKey.id,
                statusJidList: [statusKey.remoteJid, statusKey.participant || statusKey.remoteJid]
            }
        );
        
    } catch (error) {
        console.error('☀️ Erreur lors de la réaction au statut:', error.message);
    }
}

// Function to handle status updates
async function handleStatusUpdate(sock, status) {
    try {
        if (!isAutoStatusEnabled()) {
            return;
        }

        // Add delay to prevent rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));

        // Handle status from messages.upsert
        if (status.messages && status.messages.length > 0) {
            const msg = status.messages[0];
            if (msg.key && msg.key.remoteJid === 'status@broadcast') {
                try {
                    await sock.readMessages([msg.key]);
                    
                    // React to status if enabled
                    await reactToStatus(sock, msg.key);
                    
                } catch (err) {
                    if (err.message?.includes('rate-overlimit')) {
                        console.log('⚠️ Limite de débit atteinte, attente avant réessai...');
                        await new Promise(resolve => setTimeout(resolve, 2000));
                        await sock.readMessages([msg.key]);
                    } else {
                        throw err;
                    }
                }
                return;
            }
        }

        // Handle direct status updates
        if (status.key && status.key.remoteJid === 'status@broadcast') {
            try {
                await sock.readMessages([status.key]);
                
                // React to status if enabled
                await reactToStatus(sock, status.key);
                
            } catch (err) {
                if (err.message?.includes('rate-overlimit')) {
                    console.log('⚠️ Limite de débit atteinte, attente avant réessai...');
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    await sock.readMessages([status.key]);
                } else {
                    throw err;
                }
            }
            return;
        }

        // Handle status in reactions
        if (status.reaction && status.reaction.key.remoteJid === 'status@broadcast') {
            try {
                await sock.readMessages([status.reaction.key]);
                
                // React to status if enabled
                await reactToStatus(sock, status.reaction.key);
                
            } catch (err) {
                if (err.message?.includes('rate-overlimit')) {
                    console.log('⚠️ Limite de débit atteinte, attente avant réessai...');
                    await new Promise(resolve => setTimeout(resolve, 2000));
                    await sock.readMessages([status.reaction.key]);
                } else {
                    throw err;
                }
            }
            return;
        }

    } catch (error) {
        console.error('☀️ Erreur dans l\'auto-status:', error.message);
    }
}

module.exports = {
    autoStatusCommand,
    handleStatusUpdate
};