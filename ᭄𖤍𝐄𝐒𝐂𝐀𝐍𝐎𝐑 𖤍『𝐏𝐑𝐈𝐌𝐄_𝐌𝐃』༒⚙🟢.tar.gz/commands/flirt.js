const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '☀️ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ ☀️',
            serverMessageId: -1
        }
    }
};

// Images élégantes d'Escanor (style poète / soleil / fierté)
const escanorImages = [
    'https://i.imgur.com/2wzGhpF.jpeg',
    'https://wallpapercave.com/wp/wp9471757.jpg',
    'https://wallpapercave.com/wp/wp9471764.jpg',
    'https://wallpapercave.com/wp/wp9471769.jpg',
    'https://wallpapercave.com/wp/wp9471774.jpg',
    'https://wallpapercave.com/wp/wp9471780.jpg',
    'https://wallpapercave.com/wp/wp9471786.jpg',
    'https://wallpapercave.com/wp/wp9471792.jpg'
];

// Poèmes d'Escanor (drague élégante et fière)
const escanorFlirts = [
    "Ton regard brille plus que le soleil à son zénith. Et pourtant, c'est moi qui illumine le monde. Curieux, n'est-ce pas ?",
    "Je ne m'incline devant personne, mais ta présence... elle me donne envie de m'arrêter un instant.",
    "La chaleur du soleil est ma force, mais la tienne... elle réchauffe ce que je croyais glacé.",
    "On dit que je suis fier. Peut-être. Mais si je baisse ma garde un jour, ce sera pour toi.",
    "Le monde tremble devant moi. Toi, tu me fais sourire. Ne dis rien. Laisse-moi profiter de ce miracle.",
    "Je suis celui qui se tient au-dessus de tout. Pourtant, devant toi, je me sens... à ma place.",
    "Tu n'as pas peur de moi. C'est rare. C'est... rafraîchissant. Reste ainsi.",
    "Si le soleil me donne la force, c'est peut-être parce qu'il a vu ton visage avant moi.",
    "Je n'ai jamais couru après personne. Mais si tu t'éloignes... je pourrais faire une exception.",
    "Ta simple existence est une insulte à ma fierté. Parce que tu me rappelles que même les lions peuvent être émus.",
    "Je défie les dieux, je défie les rois. Mais toi... tu me défies d'être meilleur.",
    "On raconte que je suis arrogant. C'est vrai. Mais avec toi, mon arrogance devient timidité. Ne le répète à personne.",
    "La puissance absolue est ma nature. Mais la douceur... elle est ce que tu inspires.",
    "Je ne demande rien à personne. Pourtant, j'aimerais que tu restes. Juste un peu plus longtemps.",
    "Le soleil se lève chaque jour pour éclairer le monde. Mais depuis que je t'ai vue, je sais pourquoi il se lève vraiment.",
    "Tu te demandes pourquoi je suis si fort ? Parce que le soleil lui-même est jaloux de ta lumière.",
    "Je pourrais réduire ce monde en cendres d'un clignement d'œil. Mais je préfère le regarder à travers tes yeux.",
    "On m'appelle le Lion de l'Orgueil. Mais avec toi, mon orgueil s'incline. Ne t'habitue pas à ce privilège."
];

async function flirtCommand(sock, chatId, message) {
    try {
        // Vérifier si un utilisateur est mentionné ou cité
        let userToFlirt = null;
        let userName = "";

        if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            userToFlirt = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
            userName = userToFlirt.split('@')[0];
        } else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToFlirt = message.message.extendedTextMessage.contextInfo.participant;
            userName = userToFlirt.split('@')[0];
        }

        // Sélectionner un message et une image aléatoires
        const randomIndex = Math.floor(Math.random() * escanorFlirts.length);
        const randomImage = escanorImages[Math.floor(Math.random() * escanorImages.length)];
        let flirtMessage = escanorFlirts[randomIndex];

        // Ajouter la mention si un utilisateur est ciblé
        if (userName) {
            flirtMessage = `@${userName}, ${flirtMessage.toLowerCase()}`;
        }

        // Ajouter la signature d'Escanor
        const caption = `☀️ * ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 – LE LION POÈTE* ☀️\n\n${flirtMessage}\n\n☀️ *"Le soleil brille pour tout le monde. Mais aujourd'hui, il brille un peu plus pour toi."* ☀️\n\n💀 *᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒* 💀`;

        // Télécharger l'image localement (optionnel, ou envoyer via URL)
        let imageBuffer;
        try {
            const response = await axios.get(randomImage, { responseType: 'arraybuffer' });
            imageBuffer = Buffer.from(response.data);
        } catch {
            imageBuffer = null;
        }

        if (imageBuffer) {
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: caption,
                mentions: userToFlirt ? [userToFlirt] : [],
                ...channelInfo
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, {
                text: caption,
                mentions: userToFlirt ? [userToFlirt] : [],
                ...channelInfo
            }, { quoted: message });
        }
    } catch (error) {
        console.error('☀️ Erreur dans la commande flirt:', error);
        await sock.sendMessage(chatId, {
            text: `☀️ *ÉCHEC DE LA POÉSIE* ☀️\n\nMême le Lion peut avoir un hoquet. Réessaie, mortel.`,
            ...channelInfo
        }, { quoted: message });
    }
}

module.exports = { flirtCommand };