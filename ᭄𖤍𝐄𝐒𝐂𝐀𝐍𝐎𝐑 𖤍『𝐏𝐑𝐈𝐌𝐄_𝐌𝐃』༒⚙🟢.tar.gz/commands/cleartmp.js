const fs = require('fs');
const path = require('path');
const isOwnerOrSudo = require('../lib/isOwner');

// NEWSLETTER
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ಢྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

// Nettoyer un dossier
function clearDirectory(dirPath) {
    try {
        if (!fs.existsSync(dirPath)) {
            return { success: false, message: `☀️ Dossier introuvable: ${dirPath}` };
        }

        const files = fs.readdirSync(dirPath);
        let deletedCount = 0;

        for (const file of files) {
            try {
                const filePath = path.join(dirPath, file);
                const stat = fs.lstatSync(filePath);

                if (stat.isDirectory()) {
                    fs.rmSync(filePath, { recursive: true, force: true });
                } else {
                    fs.unlinkSync(filePath);
                }

                deletedCount++;
            } catch (err) {
                console.error(`☀️ Erreur suppression ${file}:`, err);
            }
        }

        return {
            success: true,
            message: `☀️ ${deletedCount} fichiers nettoyes dans ${path.basename(dirPath)}`,
            count: deletedCount
        };

    } catch (error) {
        console.error('☀️ Erreur clearDirectory:', error);

        return {
            success: false,
            message: `☀️ Echec nettoyage ${path.basename(dirPath)}`,
            error: error.message
        };
    }
}

// Nettoyer tmp + temp
async function clearTmpDirectory() {
    const tmpDir = path.join(process.cwd(), 'tmp');
    const tempDir = path.join(process.cwd(), 'temp');

    const results = [];
    results.push(clearDirectory(tmpDir));
    results.push(clearDirectory(tempDir));

    const success = results.every(r => r.success);
    const totalDeleted = results.reduce((sum, r) => sum + (r.count || 0), 0);
    const message = results.map(r => r.message).join(' | ');

    return { success, message, count: totalDeleted };
}

// Commande
async function clearTmpCommand(sock, chatId, msg) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);

        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *SEUL MON MAITRE PEUT UTILISER CETTE COMMANDE.* ☀️\nLe Lion n\'obeit qu\'a son createur.',
                ...channelInfo
            });
            return;
        }

        const result = await clearTmpDirectory();

        if (result.success) {
            await sock.sendMessage(chatId, { 
                text: `☀️ *NETTOYAGE REUSSI* ☀️\n${result.message}`,
                ...channelInfo
            });
        } else {
            await sock.sendMessage(chatId, { 
                text: `☀️ *ECHEC DU NETTOYAGE* ☀️\n${result.message}`,
                ...channelInfo
            });
        }

    } catch (error) {
        console.error('☀️ Erreur cleartmp:', error);

        await sock.sendMessage(chatId, { 
            text: '☀️ *ECHEC DU NETTOYAGE TEMP.* ☀️\nLe Lion a echoue... Reessaie.',
            ...channelInfo
        });
    }
}

// Auto clean
function startAutoClear() {

    clearTmpDirectory().then(result => {
        if (!result.success) {
            console.error(`☀️ [Auto] ${result.message}`);
        }
    });

    setInterval(async () => {
        const result = await clearTmpDirectory();

        if (!result.success) {
            console.error(`☀️ [Auto] ${result.message}`);
        }

    }, 6 * 60 * 60 * 1000);
}

startAutoClear();

module.exports = clearTmpCommand;