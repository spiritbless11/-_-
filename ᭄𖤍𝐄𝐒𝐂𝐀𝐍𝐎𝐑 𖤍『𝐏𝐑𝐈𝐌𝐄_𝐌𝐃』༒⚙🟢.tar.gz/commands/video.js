/**
 * ☀️ COMMANDE VIDEO – ESCANOR PRIME ☀️
 * Télécharge des vidéos YouTube avec la puissance du Lion
 */

const yts = require('yt-search');
const axios = require('axios');
const sendStyledMessage = require('../utils/sendStyledMessage');
const ytdl = require('@distube/ytdl-core');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

const FALLBACK_IMAGE = 'https://i.imgur.com/2wzGhpF.jpeg';

// ============================================================================
// 🎵 UTILITAIRES
// ============================================================================
function formatDuration(seconds) {
    if (!seconds) return 'Inconnue';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatViews(views) {
    if (!views) return '0';
    if (views >= 1000000) return (views / 1000000).toFixed(1) + 'M';
    if (views >= 1000) return (views / 1000).toFixed(1) + 'K';
    return views.toString();
}

// ============================================================================
// 🦁 COMMANDE VIDEO
// ============================================================================
async function videoCommand(sock, chatId, message) {
    let searchingMsgKey = null; // Pour supprimer le message de recherche
    try {
        const text = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text || 
                     "";

        const args = text.split(' ').slice(1);
        const searchQuery = args.join(' ').trim();

        // ❌ Aucune requête
        if (!searchQuery) {
            await sendStyledMessage(sock, chatId, 
                `☀️ *UTILISATION – DEMANDE UNE VIDÉO AU LION* ☀️\n\n⚡ *.video <nom de la vidéo>*\n⚡ *.video <lien YouTube>*\n\n🎬 *EXEMPLE:* .video bot WhatsApp tutorial\n\n☀️ *LE LION ATTEND TA REQUÊTE.* ☀️`, 
                message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
            );
            return;
        }

        // 🔍 Message de recherche (on stocke la clé pour suppression)
        searchingMsgKey = await sock.sendMessage(chatId, 
            { text: `☀️ *LE LION CHERCHE TA VIDÉO...* ☀️\n\n⏳ *PATIENCE, LA PUISSANCE DU SOLEIL S'ACTIVE.* ☀️` },
            { quoted: message }
        );

        let videoUrl = '';
        let videoInfo = null;

        try {
            if (searchQuery.startsWith('http://') || searchQuery.startsWith('https://')) {
                videoUrl = searchQuery;
                const ytId = (videoUrl.match(/(?:youtu\.be\/|v=)([a-zA-Z0-9_-]{11})/) || [])[1];
                if (ytId) {
                    videoInfo = await yts({ videoId: ytId });
                }
            } else {
                const search = await yts(searchQuery);
                if (!search.videos || search.videos.length === 0) {
                    await sendStyledMessage(sock, chatId, 
                        `☀️ *AUCUNE VIDÉO TROUVÉE.* ☀️\n\n⚡ *ESSAIE D'AUTRES MOTS-CLÉS, MORTEL.* ☀️`, 
                        message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
                    );
                    return;
                }
                videoInfo = search.videos[0];
                videoUrl = videoInfo.url;
            }

            if (!videoInfo) {
                throw new Error('No video info');
            }
            const title = videoInfo.title || searchQuery;
            const duration = videoInfo.seconds ? formatDuration(videoInfo.seconds) : 'Inconnue';
            const views = formatViews(videoInfo.views);
            const author = videoInfo.author?.name || 'Inconnu';
            const thumbnail = videoInfo.thumbnail || FALLBACK_IMAGE;

            // 🗑️ SUPPRIMER le message de recherche AVANT d'envoyer les infos
            try {
                if (searchingMsgKey) {
                    await sock.sendMessage(chatId, { delete: searchingMsgKey.key });
                }
            } catch (e) {
                console.log('Erreur suppression message recherche:', e.message);
            }

            // 📜 Info vidéo
            const infoText = `☀️ *ESCANOR PRIME – TÉLÉCHARGEMENT VIDÉO* ☀️\n\n🎬 *TITRE:* ${title}\n👤 *CRÉATEUR:* ${author}\n⏱️ *DURÉE:* ${duration}\n👁️ *VUES:* ${views}\n\n🔥 *QUE LA PUISSANCE DU SOLEIL TÉLÉCHARGE CETTE VIDÉO.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;

            await sock.sendMessage(chatId, {
                image: { url: thumbnail },
                caption: infoText,
                contextInfo: {
                    ...channelContext.contextInfo,
                    externalAdReply: {
                        title: "🎬 " + title.substring(0, 50),
                        body: `👤 ${author} | ⏱️ ${duration}`,
                        thumbnailUrl: thumbnail,
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        sourceUrl: videoUrl
                    }
                }
            });

            // 🎥 TÉLÉCHARGEMENT VIDÉO – MÊME MÉTHODE QUE SONG.JS
            let videoBuffer = null;
            let downloadSuccess = false;

            // MÉTHODE 1: ytdl-core
            try {
                console.log('🎥 Téléchargement avec ytdl-core...');
                
                const stream = ytdl(videoUrl, {
                    quality: '18', // MP4 360p
                    filter: format => format.container === 'mp4',
                    highWaterMark: 1 << 25
                });

                const chunks = [];
                for await (const chunk of stream) {                    chunks.push(chunk);
                }
                
                videoBuffer = Buffer.concat(chunks);
                
                if (videoBuffer.length > 1000) {
                    downloadSuccess = true;
                    console.log(`✅ Vidéo téléchargée: ${(videoBuffer.length / 1024 / 1024).toFixed(2)} MB`);
                }
                
            } catch (ytdlError) {
                console.error('Erreur ytdl-core:', ytdlError.message);
                
                // MÉTHODE 2: APIs de secours (MÊMES QUE SONG.JS MAIS YTMP4)
                const apiUrls = [
                    `https://api.davidcyriltech.my.id/download/ytmp4?url=${encodeURIComponent(videoUrl)}`,
                    `https://api.lolhuman.xyz/api/ytmp4?apikey=beta&url=${encodeURIComponent(videoUrl)}`,
                    `https://yt-dl.officialhectormanuel.workers.dev/?url=${encodeURIComponent(videoUrl)}&type=video`
                ];

                for (const apiUrl of apiUrls) {
                    try {
                        console.log(`🔄 Tentative API: ${apiUrl}`);
                        
                        const { data } = await axios.get(apiUrl, { 
                            timeout: 30000,
                            headers: {
                                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                'Accept': '*/*'
                            }
                        });
                        
                        // Extraire l'URL selon la structure de l'API
                        const downloadUrl = data?.result?.download_url || 
                                          data?.result?.url || 
                                          data?.download?.url ||
                                          data?.data?.download_url;
                        
                        if (downloadUrl) {
                            const videoResponse = await axios.get(downloadUrl, {
                                responseType: 'arraybuffer',
                                timeout: 90000,
                                headers: { 
                                    'User-Agent': 'Mozilla/5.0',
                                    'Accept': '*/*'
                                }
                            });
                            
                            videoBuffer = Buffer.from(videoResponse.data);
                                                        if (videoBuffer.length > 1000) {
                                downloadSuccess = true;
                                console.log(`✅ Vidéo téléchargée via API`);
                                break;
                            }
                        }
                        
                    } catch (apiErr) {
                        console.log(`❌ API échouée: ${apiUrl} - ${apiErr.message}`);
                        continue;
                    }
                }
            }

            if (!downloadSuccess || !videoBuffer || videoBuffer.length < 1000) {
                await sendStyledMessage(sock, chatId, 
                    `☀️ *IMPOSSIBLE DE RÉCUPÉRER LA VIDÉO.* ☀️\n\n⚠️ *ESSAIE UNE AUTRE VIDÉO, MORTEL.* ☀️`, 
                    message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
                );
                return;
            }

            // 🎬 Envoi vidéo
            const safeTitle = title.replace(/[<>:"/\\|?*]+/g, '').substring(0, 100);

            await sock.sendMessage(chatId, {
                video: videoBuffer,
                mimetype: "video/mp4",
                fileName: `${safeTitle}.mp4`,
                caption: `☀️ *TÉLÉCHARGEMENT TERMINÉ, MORTEL !* ☀️\n\n🎬 *${safeTitle}*\n📦 *FORMAT:* MP4 Vidéo\n🎥 *QUALITÉ:* 360p\n\n☀️ *PROFITE DE TA VIDÉO. LE LION TE SALUE.* ☀️`,
                contextInfo: {
                    ...channelContext.contextInfo,
                    externalAdReply: {
                        title: "🎬 " + safeTitle.substring(0, 50),
                        body: "☀️ Téléchargé par ESCANOR PRIME ☀️",
                        thumbnailUrl: thumbnail,
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        sourceUrl: "https://whatsapp.com/channel/0029Vb78ycrInlqYocbYLX0P"
                    }
                }
            }, { quoted: message });

        } catch (error) {
            console.error('☀️ ERREUR VIDEO:', error);
            
            // Supprimer message recherche en cas d'erreur aussi
            try {
                if (searchingMsgKey) {
                    await sock.sendMessage(chatId, { delete: searchingMsgKey.key });                }
            } catch (e) {}
            
            await sendStyledMessage(sock, chatId, 
                `☀️ *ÉCHEC DU TÉLÉCHARGEMENT.* ☀️\n\n⚠️ *MÊME LE LION PEUT AVOIR UN HOQUET. RÉESSAIE, MORTEL.* ☀️`, 
                message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
            );
        }

    } catch (error) {
        console.error('☀️ ERREUR GLOBALE:', error);
        
        try {
            if (searchingMsgKey) {
                await sock.sendMessage(chatId, { delete: searchingMsgKey.key });
            }
        } catch (e) {}
        
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DU TÉLÉCHARGEMENT.* ☀️\n\n⚠️ *MÊME LE LION PEUT AVOIR UN HOQUET. RÉESSAIE, MORTEL.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

module.exports = videoCommand;