const fetch = require('node-fetch');
const fs = require('fs');
const { exec } = require('child_process');
const path = require('path');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '༄ྀ 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function emojimixCommand(sock, chatId, msg) {
    try {
        const text = msg.message?.conversation?.trim() || 
                    msg.message?.extendedTextMessage?.text?.trim() || '';
        
        const args = text.split(' ').slice(1);
        
        if (!args[0]) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *EXEMPLE:* .emojimix 😎+🥰',
                ...channelInfo
            });
            return;
        }

        if (!text.includes('+')) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *SÉPARE LES ÉMOJIS AVEC UN +* ☀️\n\n📌 Exemple: .emojimix 😎+🥰',
                ...channelInfo
            });
            return;
        }

        let [emoji1, emoji2] = args[0].split('+').map(e => e.trim());

        const url = `https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}`;

        const response = await fetch(url);
        const data = await response.json();

        if (!data.results || data.results.length === 0) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *CES ÉMOJIS NE PEUVENT PAS ÊTRE MÉLANGÉS.* ☀️\nLe Lion n’a trouvé aucune combinaison. Essaie autre chose.',
                ...channelInfo
            });
            return;
        }

        const imageUrl = data.results[0].url;

        const tmpDir = path.join(process.cwd(), 'tmp');
        if (!fs.existsSync(tmpDir)) {
            fs.mkdirSync(tmpDir, { recursive: true });
        }

        const tempFile = path.join(tmpDir, `temp_${Date.now()}.png`).replace(/\\/g, '/');
        const outputFile = path.join(tmpDir, `sticker_${Date.now()}.webp`).replace(/\\/g, '/');

        const imageResponse = await fetch(imageUrl);
        const buffer = await imageResponse.buffer();
        fs.writeFileSync(tempFile, buffer);

        const ffmpegCommand = `ffmpeg -i "${tempFile}" -vf "scale=512:512:force_original_aspect_ratio=decrease,format=rgba,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=#00000000" "${outputFile}"`;
        
        await new Promise((resolve, reject) => {
            exec(ffmpegCommand, (error) => {
                if (error) {
                    console.error('FFmpeg error:', error);
                    reject(error);
                } else {
                    resolve();
                }
            });
        });

        if (!fs.existsSync(outputFile)) {
            throw new Error('Failed to create sticker file');
        }

        const stickerBuffer = fs.readFileSync(outputFile);

        await sock.sendMessage(chatId, { 
            sticker: stickerBuffer,
            ...channelInfo
        }, { quoted: msg });

        try {
            fs.unlinkSync(tempFile);
            fs.unlinkSync(outputFile);
        } catch (err) {
            console.error('☀️ Erreur de nettoyage:', err);
        }

    } catch (error) {
        console.error('☀️ Erreur dans la commande emojimix:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DU MÉLANGE D\'ÉMOJIS.* ☀️\nUtilise des émojis valides.\n\n📌 Exemple: .emojimix 😎+🥰',
            ...channelInfo
        });
    }
}

module.exports = emojimixCommand;