const axios = require('axios');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const { uploadImage } = require('../lib/uploadImage');

async function getQuotedOrOwnImageUrl(sock, message) {
    const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
    if (quoted?.imageMessage) {
        const stream = await downloadContentFromMessage(quoted.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);
        return await uploadImage(buffer);
    }

    if (message.message?.imageMessage) {
        const stream = await downloadContentFromMessage(message.message.imageMessage, 'image');
        const chunks = [];
        for await (const chunk of stream) chunks.push(chunk);
        const buffer = Buffer.concat(chunks);
        return await uploadImage(buffer);
    }

    return null;
}

module.exports = {
    name: 'removebg',
    alias: ['rmbg', 'nobg'],
    category: 'general',
    desc: 'Remove background from images',
    async exec(sock, message, args) {
        try {
            const chatId = message.key.remoteJid;
            let imageUrl = null;
            
            if (args.length > 0) {
                const url = args.join(' ');
                if (isValidUrl(url)) {
                    imageUrl = url;
                } else {
                    return sock.sendMessage(chatId, { 
                        text: '☀️ *URL INVALIDE.* ☀️\n\nUtilisation: .removebg https://exemple.com/image.jpg' 
                    }, { quoted: message });
                }
            } else {
                imageUrl = await getQuotedOrOwnImageUrl(sock, message);
                
                if (!imageUrl) {
                    return sock.sendMessage(chatId, { 
                        text: '☀️ *COMMANDE REMOVEBG* ☀️\n\nUtilisation:\n• `.removebg <url_image>`\n• Réponds à une image avec `.removebg`\n• Envoie une image avec `.removebg`' 
                    }, { quoted: message });
                }
            }

            const apiUrl = `https://api.siputzx.my.id/api/iloveimg/removebg?image=${encodeURIComponent(imageUrl)}`;
            
            const response = await axios.get(apiUrl, {
                responseType: 'arraybuffer',
                timeout: 30000,
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                }
            });

            if (response.status === 200 && response.data) {
                await sock.sendMessage(chatId, {
                    image: response.data,
                    caption: '☀️ *FOND SUPPRIMÉ PAR LE LION* ☀️'
                }, { quoted: message });
            } else {
                throw new Error('Failed to process image');
            }

        } catch (error) {
            console.error('☀️ Erreur RemoveBG:', error.message);
            
            let errorMessage = '☀️ *ÉCHEC DE LA SUPPRESSION DU FOND.* ☀️';
            
            if (error.response?.status === 429) {
                errorMessage = '☀️ *TROP DE DEMANDES.* ☀️\nRéessaie plus tard, mortel.';
            } else if (error.response?.status === 400) {
                errorMessage = '☀️ *URL INVALIDE.* ☀️';
            } else if (error.response?.status === 500) {
                errorMessage = '☀️ *ERREUR SERVEUR.* ☀️\nRéessaie plus tard.';
            } else if (error.code === 'ECONNABORTED') {
                errorMessage = '☀️ *TIMEOUT.* ☀️\nRéessaie, mortel.';
            } else if (error.message.includes('ENOTFOUND') || error.message.includes('ECONNREFUSED')) {
                errorMessage = '☀️ *ERREUR RÉSEAU.* ☀️\nVérifie ta connexion.';
            }
            
            await sock.sendMessage(chatId, { 
                text: errorMessage 
            }, { quoted: message });
        }
    }
};

function isValidUrl(string) {
    try {
        new URL(string);
        return true;
    } catch (_) {
        return false;
    }
}