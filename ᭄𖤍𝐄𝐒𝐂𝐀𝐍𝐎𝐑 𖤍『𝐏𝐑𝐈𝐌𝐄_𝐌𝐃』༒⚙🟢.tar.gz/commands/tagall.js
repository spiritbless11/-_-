const fs = require('fs');
const isAdmin = require('../lib/isAdmin');

const NEWSLETTER_JID = "120363419277738229@newsletter";
const MENU_IMAGE = "./assets/bot_image2.jpg";

const DECOR = `
☀️ *LE LION APPELLE SES MORTELS* ☀️

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ 📣 *ATTENTION À TOUS*
┃
┃ 🔥 Ceci est un appel du Lion.
┃ ☀️ *ESCCANOR PRIME* VEILLE.
┃
┃ 💬 Un message du maître vous attend.
┃ 📩 Répondez à l'appel, mortels.
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️
`;

async function tagAllCommand(sock, chatId, senderId, message) {
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️' }, { quoted: message });
            return;
        }

        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT TAGGER TOUS.* ☀️' }, { quoted: message });
            return;
        }

        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants;

        if (!participants || participants.length === 0) {
            await sock.sendMessage(chatId, { text: '☀️ *AUCUN PARTICIPANT TROUVÉ.* ☀️' });
            return;
        }

        await sock.sendMessage(chatId, {
            image: fs.readFileSync(MENU_IMAGE),
            caption: DECOR,
            mentions: participants.map(p => p.id),
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: NEWSLETTER_JID,
                    newsletterName: "☀️ ESCANOR PRIME – LE LION DE L'ORGUEIL ☀️",
                    serverMessageId: 1
                }
            }
        }, { quoted: message });

    } catch (error) {
        console.error('☀️ Erreur dans tagall:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DU TAGALL.* ☀️\nMême le Lion peut avoir un hoquet.' });
    }
}

module.exports = tagAllCommand;