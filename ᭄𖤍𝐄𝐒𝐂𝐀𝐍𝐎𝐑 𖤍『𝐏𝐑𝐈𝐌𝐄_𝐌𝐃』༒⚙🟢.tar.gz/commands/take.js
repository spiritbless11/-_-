const fs = require('fs');
const path = require('path');
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const webp = require('node-webpmux');
const crypto = require('crypto');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function takeCommand(sock, chatId, message, args) {
    try {
        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quotedMessage?.stickerMessage) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *RÉPONDS À UN STICKER AVEC .take <nom du pack>* ☀️',
                ...channelInfo
            });
            return;
        }

        const packname = args.join(' ') || '☀️  ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ ☀️';

        try {
            const stickerBuffer = await downloadMediaMessage(
                {
                    key: message.message.extendedTextMessage.contextInfo.stanzaId,
                    message: quotedMessage,
                    messageType: 'stickerMessage'
                },
                'buffer',
                {},
                {
                    logger: console,
                    reuploadRequest: sock.updateMediaMessage
                }
            );

            if (!stickerBuffer) {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *ÉCHEC DU TÉLÉCHARGEMENT.* ☀️',
                    ...channelInfo
                });
                return;
            }

            const img = new webp.Image();
            await img.load(stickerBuffer);

            const json = {
                'sticker-pack-id': crypto.randomBytes(32).toString('hex'),
                'sticker-pack-name': packname,
                'emojis': ['🦁']
            };

            const exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00]);
            const jsonBuffer = Buffer.from(JSON.stringify(json), 'utf8');
            const exif = Buffer.concat([exifAttr, jsonBuffer]);
            exif.writeUIntLE(jsonBuffer.length, 14, 4);

            img.exif = exif;

            const finalBuffer = await img.save(null);

            await sock.sendMessage(chatId, { 
                sticker: finalBuffer,
                ...channelInfo
            }, {
                quoted: message
            });

        } catch (error) {
            console.error('☀️ Erreur traitement sticker:', error);
            await sock.sendMessage(chatId, { 
                text: '☀️ *ÉCHEC DU TRAITEMENT.* ☀️',
                ...channelInfo
            });
        }

    } catch (error) {
        console.error('☀️ Erreur take:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DE LA COMMANDE.* ☀️',
            ...channelInfo
        });
    }
}

module.exports = takeCommand;