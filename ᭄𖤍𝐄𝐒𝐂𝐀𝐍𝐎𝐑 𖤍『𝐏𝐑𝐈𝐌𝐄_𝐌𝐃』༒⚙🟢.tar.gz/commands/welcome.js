const { addWelcome, delWelcome, isWelcomeOn, getWelcome, addGoodbye, delGoodBye, isGoodByeOn, getGoodbye } = require('../lib/index');

// Configuration du bouton "Voir la chaîne"
const channelButton = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

// ========== COMMANDE WELCOME ==========
async function welcomeCommand(sock, chatId, message) {
    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const args = text.trim().split(' ').slice(1);
    const match = args.join(' ');

    if (!match) {
        const status = await isWelcomeOn(chatId) ? '**ACTIVÉ**' : '**DÉSACTIVÉ**';
        return sock.sendMessage(chatId, {
            text: `☀️ *MESSAGE D'ACCUEIL – LE LION SALUE* ☀️\n\nStatut: ${status}\n\n✅ .welcome on — Activer\n🛠️ .welcome set [message] — Personnaliser\n🚫 .welcome off — Désactiver\n\nVariables: {user}, {group}, {groupSize}, {adminCount}, {date}, {time}`,
            ...channelButton
        }, { quoted: message });
    }

    const [command, ...argsMsg] = match.split(' ');
    const lowerCommand = command.toLowerCase();
    const customMessage = argsMsg.join(' ');

    if (lowerCommand === 'on') {
        if (await isWelcomeOn(chatId)) {
            return sock.sendMessage(chatId, { text: "☀️ **L'ACCUEIL EST DÉJÀ ACTIF.** ☀️", ...channelButton }, { quoted: message });
        }
        const defaultMessage = `☀️ **BIENVENUE DANS L'ANTRE DU LION** ☀️

👤 *NOUVEAU MORTEL : {user}*
👥 *GROUPE : {group}*
📊 *MEMBRES : {groupSize}*
👑 *ADMINS : {adminCount}*
📅 *DATE : {date}*
⏰ *HEURE : {time}*

☀️ *"JE SUIS ESCANOR, LE LION DE L'ORGUEIL. CELUI QUI SE TIENT AU-DESSUS DE TOUT."* ☀️

🔥 *RÈGLES :* 🔥
• *RESPECTE LES AUTRES MORTELS*
• *PAS DE LIENS NI CONTENUS INTERDITS*
• *AMUSE-TOI, MAIS NE ME DÉRANGE PAS SANS RAISON*

🎉 *BIENVENUE PARMI NOUS. TA VIE VIENT DE CHANGER.* 🎉

> © * ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ – LE LION DE L'ORGUEIL*`;
        await addWelcome(chatId, true, defaultMessage);
        return sock.sendMessage(chatId, { text: "☀️ **ACCUEIL ACTIVÉ** ☀️\nLe Lion accueillera les nouveaux membres.", ...channelButton }, { quoted: message });
    }

    if (lowerCommand === 'off') {
        if (!(await isWelcomeOn(chatId))) {
            return sock.sendMessage(chatId, { text: "☀️ **L'ACCUEIL EST DÉJÀ DÉSACTIVÉ.** ☀️", ...channelButton }, { quoted: message });
        }
        await delWelcome(chatId);
        return sock.sendMessage(chatId, { text: "☀️ **ACCUEIL DÉSACTIVÉ** ☀️\nLe Lion n'accueillera plus les nouveaux.", ...channelButton }, { quoted: message });
    }

    if (lowerCommand === 'set') {
        if (!customMessage) {
            return sock.sendMessage(chatId, { text: "☀️ **DONNE-MOI UN MESSAGE** ☀️\nExemple: .welcome set BIENVENUE {user} !", ...channelButton }, { quoted: message });
        }
        await addWelcome(chatId, true, customMessage.toUpperCase());
        return sock.sendMessage(chatId, { text: "☀️ **MESSAGE PERSONNALISÉ** ☀️\nNOUVEAU MESSAGE D'ACCUEIL ENREGISTRÉ.", ...channelButton }, { quoted: message });
    }

    return sock.sendMessage(chatId, {
        text: "☀️ **COMMANDE INVALIDE** ☀️\n.welcome on → Activer\n.welcome set [message] → Personnaliser\n.welcome off → Désactiver",
        ...channelButton
    }, { quoted: message });
}

// ========== COMMANDE GOODBYE ==========
async function goodbyeCommand(sock, chatId, message) {
    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const args = text.trim().split(' ').slice(1);
    const match = args.join(' ');

    if (!match) {
        const status = await isGoodByeOn(chatId) ? '**ACTIVÉ**' : '**DÉSACTIVÉ**';
        return sock.sendMessage(chatId, {
            text: `☀️ **MESSAGE D'AU REVOIR – LE LION SALUE LE DÉPART** ☀️\n\nStatut: ${status}\n\n✅ .goodbye on — Activer\n🛠️ .goodbye set [message] — Personnaliser\n🚫 .goodbye off — Désactiver\n\nVariables: {user}, {group}, {groupSize}, {adminCount}, {date}, {time}`,
            ...channelButton
        }, { quoted: message });
    }

    const [command, ...argsMsg] = match.split(' ');
    const lowerCommand = command.toLowerCase();
    const customMessage = argsMsg.join(' ');

    if (lowerCommand === 'on') {
        if (await isGoodByeOn(chatId)) {
            return sock.sendMessage(chatId, { text: "☀️ **L'AU REVOIR EST DÉJÀ ACTIF.** ☀️", ...channelButton }, { quoted: message });
        }
        const defaultMessage = `☀️ *AU REVOIR, LE LION TE SALUE, MORTEL** ☀️

👤 **MORTEL : {user}**
👥 **GROUPE : {group}**
📊 **MEMBRES RESTANTS : {groupSize}**
👑 **ADMINS : {adminCount}**
📅 **DATE : {date}**
⏰ **HEURE : {time}**

🔥 *"PUISE TA FIERTÉ TE MÈNE AILLEURS. LE LION NE TE RETIENT PAS."* 🔥

> © * ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ – LE LION DE L'ORGUEIL*`;
        await addGoodbye(chatId, true, defaultMessage);
        return sock.sendMessage(chatId, { text: "☀️ **AU REVOIR ACTIVÉ** ☀️\nLe Lion saluera les départs.", ...channelButton }, { quoted: message });
    }

    if (lowerCommand === 'off') {
        if (!(await isGoodByeOn(chatId))) {
            return sock.sendMessage(chatId, { text: "☀️ **L'AU REVOIR EST DÉJÀ DÉSACTIVÉ.** ☀️", ...channelButton }, { quoted: message });
        }
        await delGoodBye(chatId);
        return sock.sendMessage(chatId, { text: "☀️ **AU REVOIR DÉSACTIVÉ** ☀️\nLe Lion ne saluera plus les départs.", ...channelButton }, { quoted: message });
    }

    if (lowerCommand === 'set') {
        if (!customMessage) {
            return sock.sendMessage(chatId, { text: "☀️ **DONNE-MOI UN MESSAGE** ☀️\nExemple: .goodbye set AU REVOIR {user} !", ...channelButton }, { quoted: message });
        }
        await addGoodbye(chatId, true, customMessage.toUpperCase());
        return sock.sendMessage(chatId, { text: "☀️ **MESSAGE PERSONNALISÉ** ☀️\nNOUVEAU MESSAGE D'AU REVOIR ENREGISTRÉ.", ...channelButton }, { quoted: message });
    }

    return sock.sendMessage(chatId, {
        text: "☀️ **COMMANDE INVALIDE** ☀️\n.goodbye on → Activer\n.goodbye set [message] → Personnaliser\n.goodbye off → Désactiver",
        ...channelButton
    }, { quoted: message });
}

// ========== ÉVÉNEMENT JOIN ==========
async function handleJoinEvent(sock, chatId, participants) {
    if (!await isWelcomeOn(chatId)) return;

    const groupMetadata = await sock.groupMetadata(chatId);
    const groupName = groupMetadata.subject;
    const groupSize = groupMetadata.participants.length;
    const adminCount = groupMetadata.participants.filter(p => p.admin).length;
    
    const now = new Date();
    const date = now.toLocaleDateString("fr-FR");
    const time = now.toLocaleTimeString("fr-FR");

    // Récupérer la photo du groupe (fallback)
    let groupPic = null;
    try {
        groupPic = await sock.profilePictureUrl(chatId, 'image');
    } catch {
        groupPic = 'https://i.imgur.com/2wzGhpF.jpeg';
    }

    for (const participant of participants) {
        try {
            const participantId = typeof participant === 'string' ? participant : participant.id || participant.toString();
            const userName = participantId.split('@')[0];

            // Récupérer la photo du membre (3 tentatives)
            let userPic = null;
            for (let attempt = 1; attempt <= 3; attempt++) {
                try {
                    userPic = await sock.profilePictureUrl(participantId, 'image');
                    if (userPic) break;
                } catch (err) {
                    if (attempt < 3) await new Promise(r => setTimeout(r, 1000));
                }
            }

            // Priorité: photo du membre > photo du groupe
            const finalImage = userPic || groupPic;

            let welcomeMsg = await getWelcome(chatId);
            if (!welcomeMsg) return;

            const finalMessage = welcomeMsg
                .replace(/{user}/g, `@${userName}`)
                .replace(/{group}/g, groupName)
                .replace(/{groupSize}/g, groupSize)
                .replace(/{adminCount}/g, adminCount)
                .replace(/{date}/g, date)
                .replace(/{time}/g, time)
                .toUpperCase(); // Majuscule pour tout le message

            await sock.sendMessage(chatId, {
                image: { url: finalImage },
                caption: `**${finalMessage}**`, // Gras pour tout le message
                mentions: [participantId],
                ...channelButton
            });
        } catch (error) {
            console.error('☀️ ERREUR ENVOI WELCOME:', error);
        }
    }
}

// ========== ÉVÉNEMENT LEAVE ==========
async function handleLeaveEvent(sock, chatId, participants) {
    if (!await isGoodByeOn(chatId)) return;

    const groupMetadata = await sock.groupMetadata(chatId);
    const groupName = groupMetadata.subject;
    const groupSize = groupMetadata.participants.length;
    const adminCount = groupMetadata.participants.filter(p => p.admin).length;
    
    const now = new Date();
    const date = now.toLocaleDateString("fr-FR");
    const time = now.toLocaleTimeString("fr-FR");

    for (const participant of participants) {
        try {
            const participantId = typeof participant === 'string' ? participant : participant.id || participant.toString();
            const userName = participantId.split('@')[0];

            let goodbyeMsg = await getGoodbye(chatId);
            if (!goodbyeMsg) return;

            const finalMessage = goodbyeMsg
                .replace(/{user}/g, `@${userName}`)
                .replace(/{group}/g, groupName)
                .replace(/{groupSize}/g, groupSize)
                .replace(/{adminCount}/g, adminCount)
                .replace(/{date}/g, date)
                .replace(/{time}/g, time)
                .toUpperCase();

            await sock.sendMessage(chatId, {
                text: `**${finalMessage}**`,
                mentions: [participantId],
                ...channelButton
            });
        } catch (error) {
            console.error('☀️ ERREUR ENVOI GOODBYE:', error);
        }
    }
}

module.exports = { welcomeCommand, goodbyeCommand, handleJoinEvent, handleLeaveEvent };