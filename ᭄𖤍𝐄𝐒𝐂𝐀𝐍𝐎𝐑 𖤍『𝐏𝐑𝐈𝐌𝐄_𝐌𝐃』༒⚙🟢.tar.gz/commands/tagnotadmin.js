const isAdmin = require('../lib/isAdmin');

async function tagNotAdminCommand(sock, chatId, senderId, message) {
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️' }, { quoted: message });
            return;
        }

        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT TAGGER LES NON-ADMINS.* ☀️' }, { quoted: message });
            return;
        }

        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants || [];

        const nonAdmins = participants.filter(p => !p.admin).map(p => p.id);
        if (nonAdmins.length === 0) {
            await sock.sendMessage(chatId, { text: '☀️ *AUCUN NON-ADMIN À TAGGER.* ☀️' }, { quoted: message });
            return;
        }

        let text = '☀️ *MORTELS (NON-ADMINS)* ☀️\n\n';
        nonAdmins.forEach(jid => {
            text += `@${jid.split('@')[0]}\n`;
        });

        await sock.sendMessage(chatId, { text, mentions: nonAdmins }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur tagnotadmin:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DU TAG.* ☀️' }, { quoted: message });
    }
}

module.exports = tagNotAdminCommand;