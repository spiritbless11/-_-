const fs = require('fs');

function readJsonSafe(path, fallback) {
    try {
        const txt = fs.readFileSync(path, 'utf8');
        return JSON.parse(txt);
    } catch (_) {
        return fallback;
    }
}

const isOwnerOrSudo = require('../lib/isOwner');

async function settingsCommand(sock, chatId, message) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        if (!message.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { text: '☀️ *SEUL MON MAÎTRE PEUT VOIR LES RÉGLAGES.* ☀️' }, { quoted: message });
            return;
        }

        const isGroup = chatId.endsWith('@g.us');
        const dataDir = './data';

        const mode = readJsonSafe(`${dataDir}/messageCount.json`, { isPublic: true });
        const autoStatus = readJsonSafe(`${dataDir}/autoStatus.json`, { enabled: false });
        const autoread = readJsonSafe(`${dataDir}/autoread.json`, { enabled: false });
        const autotyping = readJsonSafe(`${dataDir}/autotyping.json`, { enabled: false });
        const pmblocker = readJsonSafe(`${dataDir}/pmblocker.json`, { enabled: false });
        const anticall = readJsonSafe(`${dataDir}/anticall.json`, { enabled: false });
        const userGroupData = readJsonSafe(`${dataDir}/userGroupData.json`, {
            antilink: {}, antibadword: {}, welcome: {}, goodbye: {}, chatbot: {}, antitag: {}
        });
        const autoReaction = Boolean(userGroupData.autoReaction);

        const groupId = isGroup ? chatId : null;
        const antilinkOn = groupId ? Boolean(userGroupData.antilink && userGroupData.antilink[groupId]) : false;
        const antibadwordOn = groupId ? Boolean(userGroupData.antibadword && userGroupData.antibadword[groupId]) : false;
        const welcomeOn = groupId ? Boolean(userGroupData.welcome && userGroupData.welcome[groupId]) : false;
        const goodbyeOn = groupId ? Boolean(userGroupData.goodbye && userGroupData.goodbye[groupId]) : false;
        const chatbotOn = groupId ? Boolean(userGroupData.chatbot && userGroupData.chatbot[groupId]) : false;
        const antitagCfg = groupId ? (userGroupData.antitag && userGroupData.antitag[groupId]) : null;

        const lines = [];
        lines.push('☀️ *RÉGLAGES DU LION* ☀️');
        lines.push('');
        lines.push(`• Mode: ${mode.isPublic ? 'PUBLIC' : 'PRIVÉ'}`);
        lines.push(`• Auto Status: ${autoStatus.enabled ? 'ACTIF' : 'INACTIF'}`);
        lines.push(`• Autoread: ${autoread.enabled ? 'ACTIF' : 'INACTIF'}`);
        lines.push(`• Autotyping: ${autotyping.enabled ? 'ACTIF' : 'INACTIF'}`);
        lines.push(`• PM Blocker: ${pmblocker.enabled ? 'ACTIF' : 'INACTIF'}`);
        lines.push(`• Anticall: ${anticall.enabled ? 'ACTIF' : 'INACTIF'}`);
        lines.push(`• Auto Reaction: ${autoReaction ? 'ACTIVE' : 'INACTIVE'}`);
        if (groupId) {
            lines.push('');
            lines.push(`📌 Groupe: ${groupId}`);
            if (antilinkOn) {
                const al = userGroupData.antilink[groupId];
                lines.push(`• Antilink: ACTIF (action: ${al.action || 'delete'})`);
            } else {
                lines.push('• Antilink: INACTIF');
            }
            if (antibadwordOn) {
                const ab = userGroupData.antibadword[groupId];
                lines.push(`• Antibadword: ACTIF (action: ${ab.action || 'delete'})`);
            } else {
                lines.push('• Antibadword: INACTIF');
            }
            lines.push(`• Welcome: ${welcomeOn ? 'ACTIF' : 'INACTIF'}`);
            lines.push(`• Goodbye: ${goodbyeOn ? 'ACTIF' : 'INACTIF'}`);
            lines.push(`• Chatbot: ${chatbotOn ? 'ACTIF' : 'INACTIF'}`);
            if (antitagCfg && antitagCfg.enabled) {
                lines.push(`• Antitag: ACTIF (action: ${antitagCfg.action || 'delete'})`);
            } else {
                lines.push('• Antitag: INACTIF');
            }
        } else {
            lines.push('');
            lines.push('💡 Les réglages par groupe seront affichés dans un groupe.');
        }

        await sock.sendMessage(chatId, { text: lines.join('\n') }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans settings:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA LECTURE DES RÉGLAGES.* ☀️' }, { quoted: message });
    }
}

module.exports = settingsCommand;