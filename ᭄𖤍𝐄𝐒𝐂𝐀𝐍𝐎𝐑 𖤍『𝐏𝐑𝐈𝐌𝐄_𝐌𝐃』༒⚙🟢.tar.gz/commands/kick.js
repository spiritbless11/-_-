/**
 * ☀️ COMMANDE KICK – ESCANOR PRIME ☀️
 * Expulse un membre avec l'autorité du Lion
 */

const isAdmin = require('../lib/isAdmin');
const sendStyledMessage = require('../utils/sendStyledMessage');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE – BOUTON CHAÎNE + IMAGE FALLBACK
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

const FALLBACK_IMAGE = 'https://i.imgur.com/2wzGhpF.jpeg';

// ============================================================================
// 🦁 COMMANDE KICK – VERSION PRINCIPALE
// ============================================================================
async function kickCommand(sock, chatId, senderId, mentionedJids, message) {
    const isOwner = message.key.fromMe;
    
    // 🔐 Vérifications de permissions
    if (!isOwner) {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sendStyledMessage(sock, chatId, 
                `☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️\n\n⚡ *LE LION NE PEUT FRAPPER SANS AUTORITÉ.* ☀️`, 
                message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
            );
            return;
        }

        if (!isSenderAdmin) {
            await sendStyledMessage(sock, chatId, 
                `☀️ *SEULS LES ADMINISTRATEURS PEUVENT EXCLURE.* ☀️\n\n⚠️ *TU N'AS PAS LE POUVOIR D'ORDONNER AU LION.* ☀️`, 
                message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
            );
            return;
        }    }

    // 🎯 Récupération des cibles à kicker
    let usersToKick = [];
    
    if (mentionedJids && mentionedJids.length > 0) {
        usersToKick = mentionedJids.map(jid => jid.includes('@') ? jid : `${jid}@s.whatsapp.net`);
    }
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        usersToKick = [message.message.extendedTextMessage.contextInfo.participant];
    }
    
    if (usersToKick.length === 0) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *DÉSIGNE LE MORTEL À EXCLURE.* ☀️\n\n⚡ *MENTIONNE-LE OU RÉPONDS À SON MESSAGE.* ☀️`, 
            message, [], channelContext
        );
        return;
    }

    // 🛡️ PROTECTION : EMPÊCHER DE KICK LE BOT (LOGIQUE ORIGINALE CONSERVÉE)
    const botId = sock.user?.id || '';
    const botLid = sock.user?.lid || '';
    const botPhoneNumber = botId.includes(':') ? botId.split(':')[0] : (botId.includes('@') ? botId.split('@')[0] : botId);
    const botIdFormatted = botPhoneNumber + '@s.whatsapp.net';
    const botLidNumeric = botLid.includes(':') ? botLid.split(':')[0] : (botLid.includes('@') ? botLid.split('@')[0] : botLid);
    const botLidWithoutSuffix = botLid.includes('@') ? botLid.split('@')[0] : botLid;

    const metadata = await sock.groupMetadata(chatId);
    const participants = metadata.participants || [];

    const isTryingToKickBot = usersToKick.some(userId => {
        const userPhoneNumber = userId.includes(':') ? userId.split(':')[0] : (userId.includes('@') ? userId.split('@')[0] : userId);
        const userLidNumeric = userId.includes('@lid') ? userId.split('@')[0].split(':')[0] : '';
        
        const directMatch = (
            userId === botId || userId === botLid || userId === botIdFormatted ||
            userPhoneNumber === botPhoneNumber ||
            (userLidNumeric && botLidNumeric && userLidNumeric === botLidNumeric)
        );
        
        if (directMatch) return true;
        
        const participantMatch = participants.some(p => {
            const pPhoneNumber = p.phoneNumber ? p.phoneNumber.split('@')[0] : '';
            const pId = p.id ? p.id.split('@')[0] : '';
            const pLid = p.lid ? p.lid.split('@')[0] : '';
            const pFullId = p.id || '';
            const pFullLid = p.lid || '';
            const pLidNumeric = pLid.includes(':') ? pLid.split(':')[0] : pLid;            
            const isThisParticipantBot = (
                pFullId === botId || pFullLid === botLid || pLidNumeric === botLidNumeric ||
                pPhoneNumber === botPhoneNumber || pId === botPhoneNumber ||
                p.phoneNumber === botIdFormatted ||
                (botLid && pLid && botLidWithoutSuffix === pLid)
            );
            
            if (isThisParticipantBot) {
                return (
                    userId === pFullId || userId === pFullLid ||
                    userPhoneNumber === pPhoneNumber || userPhoneNumber === pId ||
                    userId === p.phoneNumber ||
                    (pLid && userLidNumeric && userLidNumeric === pLidNumeric) ||
                    (userLidNumeric && pLidNumeric && userLidNumeric === pLidNumeric)
                );
            }
            return false;
        });
        
        return participantMatch;
    });

    if (isTryingToKickBot) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *TU NE PEUX PAS EXCLURE LE LION, MORTEL.* ☀️\n\n🦁 *LE SOLEIL NE SE COUCHE JAMAIS SUR ORDRE.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        return;
    }

    // ⚡ EXÉCUTION DU KICK
    try {
        await sock.groupParticipantsUpdate(chatId, usersToKick, "remove");
        
        // ✅ Formatage des mentions pour WhatsApp : @NUMÉRO (sans +, sans espace)
        const kickedTags = usersToKick.map(jid => `@${jid.split('@')[0]}`);
        const senderNum = senderId.split('@')[0];

        const kickMessage = `☀️ *EXCLUSION – LE LION CHASSE UN MORTEL* ☀️\n\n👤 *EXPULSÉ${usersToKick.length > 1 ? 'S' : ''}:*\n┃ ${kickedTags.join('\n┃ ')}\n\n👑 *PAR:* @${senderNum}\n\n📅 *DATE:* ${new Date().toLocaleString()}\n\n🔥 *LE DÉSERT T'ATTEND. NE REVIENS PAS SANS L'AUTORISATION DU LION.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;
        
        // 📤 Envoi avec sendStyledMessage + mentions cliquables + bouton chaîne + image
        await sendStyledMessage(
            sock, 
            chatId, 
            kickMessage, 
            message, 
            [...usersToKick, senderId], // 👈 JIDs complets pour mentions cliquables
            { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );        
    } catch (error) {
        console.error('☀️ ERREUR DANS LA COMMANDE KICK:', error);
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DE L'EXCLUSION.* ☀️\n\n⚠️ *MÊME LE LION PEUT AVOIR UN HOQUET. RÉESSAIE, MORTEL.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

module.exports = kickCommand;