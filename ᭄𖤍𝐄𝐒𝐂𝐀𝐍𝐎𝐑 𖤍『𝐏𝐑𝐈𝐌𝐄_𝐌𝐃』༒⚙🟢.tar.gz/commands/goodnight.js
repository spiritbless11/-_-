/**
 * ☀️ COMMANDE GOODNIGHT – ESCANOR PRIME ☀️
 * Envoie un message de bonne nuit avec la sagesse du Lion
 */

const fetch = require('node-fetch');
const sendStyledMessage = require('../utils/sendStyledMessage');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE – BOUTON CHAÎNE + IMAGE FALLBACK
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

const FALLBACK_IMAGE = 'https://i.imgur.com/2wzGhpF.jpeg';

// ============================================================================
// 🦁 COMMANDE GOODNIGHT – VERSION PRINCIPALE
// ============================================================================
async function goodnightCommand(sock, chatId, message) {
    try {
        const senderJid = message.key.participant || message.key.remoteJid;
        const shizokeys = 'shizo';
        
        // 🌙 Appel API pour récupérer un message de bonne nuit
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/lovenight?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const goodnightMessage = json.result;

        // 📜 Message style Escanor – 100% MAJUSCULE + GRAS
        const finalMessage = `☀️ *BONNE NUIT, MORTEL* ☀️\n\n${goodnightMessage}\n\n🔥 *LE LION SE RETIRE. QUE LA FIERTÉ TE GUIDE JUSQU'À L'AUBE.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;

        // 📤 Envoi avec sendStyledMessage + bouton chaîne + image aléatoire
        await sendStyledMessage(
            sock, 
            chatId, 
            finalMessage, 
            message, 
            [senderJid], // Mention de l'utilisateur pour personnalisation
            { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        
    } catch (error) {
        console.error('☀️ ERREUR DANS LA COMMANDE GOODNIGHT:', error);
        
        // 🌙 Message de secours en cas d'échec API
        const fallbackMessage = `☀️ *BONNE NUIT, MORTEL* ☀️\n\n🦁 *MÊME QUAND LES ÉTOILES SE TAISENT, LE LION VEILLE.*\n\n💤 *REPOSE-TOI. DEMAIN, LE SOLEIL SE LÈVERA DE NOUVEAU.*\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;
        
        await sendStyledMessage(
            sock, 
            chatId, 
            fallbackMessage, 
            message, 
            [message.key.participant || message.key.remoteJid], 
            { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

module.exports = { goodnightCommand };