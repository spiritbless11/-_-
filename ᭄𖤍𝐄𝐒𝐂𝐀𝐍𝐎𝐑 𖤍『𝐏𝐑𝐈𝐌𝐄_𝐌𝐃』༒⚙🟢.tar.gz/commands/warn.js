const fs = require('fs');
const path = require('path');
const isAdmin = require('../lib/isAdmin');

const databaseDir = path.join(process.cwd(), 'data');
const warningsPath = path.join(databaseDir, 'warnings.json');

function initializeWarningsFile() {
    if (!fs.existsSync(databaseDir)) {
        fs.mkdirSync(databaseDir, { recursive: true });
    }
    
    if (!fs.existsSync(warningsPath)) {
        fs.writeFileSync(warningsPath, JSON.stringify({}), 'utf8');
    }
}

async function warnCommand(sock, chatId, senderId, mentionedJids, message) {
    try {
        initializeWarningsFile();

        if (!chatId.endsWith('@g.us')) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *CETTE COMMANDE N\'EST DISPONIBLE QU\'EN GROUPE.* ☀️'
            });
            return;
        }

        try {
            const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);
            
            if (!isBotAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️'
                });
                return;
            }

            if (!isSenderAdmin) {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT AVERTIR.* ☀️'
                });
                return;
            }
        } catch (adminError) {
            console.error('☀️ Erreur vérification admin:', adminError);
            await sock.sendMessage(chatId, { 
                text: '☀️ *ASSUREZ-VOUS QUE LE LION EST ADMIN.* ☀️'
            });
            return;
        }

        let userToWarn;
        
        if (mentionedJids && mentionedJids.length > 0) {
            userToWarn = mentionedJids[0];
        }
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToWarn = message.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!userToWarn) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *DÉSIGNE LE MORTEL À AVERTIR.* ☀️\nMentionne-le ou réponds à son message.'
            });
            return;
        }

        await new Promise(resolve => setTimeout(resolve, 1000));

        try {
            let warnings = {};
            try {
                warnings = JSON.parse(fs.readFileSync(warningsPath, 'utf8'));
            } catch (error) {
                warnings = {};
            }

            if (!warnings[chatId]) warnings[chatId] = {};
            if (!warnings[chatId][userToWarn]) warnings[chatId][userToWarn] = 0;
            
            warnings[chatId][userToWarn]++;
            fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));

            const warningMessage = `☀️ *AVERTISSEMENT DU LION* ☀️\n\n` +
                `👤 *Averti:* @${userToWarn.split('@')[0]}\n` +
                `⚠️ *Compteur:* ${warnings[chatId][userToWarn]}/3\n` +
                `👑 *Par:* @${senderId.split('@')[0]}\n\n` +
                `📅 *Date:* ${new Date().toLocaleString()}\n\n☀️ *Ne défie pas le Lion, mortel.* ☀️`;

            await sock.sendMessage(chatId, { 
                text: warningMessage,
                mentions: [userToWarn, senderId]
            });

            if (warnings[chatId][userToWarn] >= 3) {
                await new Promise(resolve => setTimeout(resolve, 1000));

                await sock.groupParticipantsUpdate(chatId, [userToWarn], "remove");
                delete warnings[chatId][userToWarn];
                fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));
                
                const kickMessage = `☀️ *EXPULSION DU LION* ☀️\n\n` +
                    `@${userToWarn.split('@')[0]} a été expulsé après 3 avertissements.\n\n🔥 *Le Lion n'aime pas les récidivistes.* 🔥`;

                await sock.sendMessage(chatId, { 
                    text: kickMessage,
                    mentions: [userToWarn]
                });
            }
        } catch (error) {
            console.error('☀️ Erreur warn:', error);
            await sock.sendMessage(chatId, { 
                text: '☀️ *ÉCHEC DE L\'AVERTISSEMENT.* ☀️'
            });
        }
    } catch (error) {
        console.error('☀️ Erreur warn:', error);
        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *TROP DE DEMANDES.* ☀️\nRéessaie dans quelques instants, mortel.'
                });
            } catch (retryError) {
                console.error('☀️ Erreur d\'envoi:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *ÉCHEC DE L\'AVERTISSEMENT.* ☀️\nAssurez-vous que le Lion est admin.'
                });
            } catch (sendError) {
                console.error('☀️ Erreur d\'envoi:', sendError);
            }
        }
    }
}

module.exports = warnCommand;