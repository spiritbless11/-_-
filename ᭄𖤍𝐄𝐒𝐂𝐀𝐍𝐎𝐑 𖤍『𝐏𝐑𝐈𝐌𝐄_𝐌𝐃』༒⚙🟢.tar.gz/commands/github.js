const moment = require('moment-timezone');
const fetch = require('node-fetch');
const fs = require('fs');
const path = require('path');

async function githubCommand(sock, chatId, message) {
  try {
    const res = await fetch('https://api.github.com/repos/mruniquehacker/Knightbot-md');
    if (!res.ok) throw new Error('☀️ Erreur lors de la récupération du dépôt');
    const json = await res.json();

    let txt = `☀️ *ESCCANOR PRIME – LE LION DE L'ORGUEIL* ☀️\n\n`;
    txt += `🦁 *Nom :* ESCANOR PRIME\n`;
    txt += `👁️ *Watchers :* ${json.watchers_count}\n`;
    txt += `📦 *Taille :* ${(json.size / 1024).toFixed(2)} MB\n`;
    txt += `📅 *Dernière mise à jour :* ${moment(json.updated_at).format('DD/MM/YY - HH:mm:ss')}\n`;
    txt += `🔗 *Lien :* https://www.mediafire.com/file/7rhmc95s4rt8tr6/🌹+𝕳𝕰́𝕷𝕰̀𝕹𝕰-𝕸𝕯+🌹.zip/file\n`;
    txt += `🍴 *Forks :* ${json.forks_count}\n`;
    txt += `⭐ *Stars :* ${json.stargazers_count}\n\n`;
    txt += `☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;

    const imgPath = path.join(__dirname, '../assets/bot_image3.jpg');
    const imgBuffer = fs.readFileSync(imgPath);

    await sock.sendMessage(chatId, { image: imgBuffer, caption: txt }, { quoted: message });
  } catch (error) {
    console.error('☀️ Erreur github:', error);
    await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION DES INFOS.* ☀️' }, { quoted: message });
  }
}

module.exports = githubCommand;