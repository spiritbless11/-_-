const fs = require('fs');
const isAdmin = require('../lib/isAdmin');
const { isSudo } = require('../lib/index');

// ✅ Channel Info intégré directement
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ོྀ🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function banCommand(sock, chatId, message) {

    const isGroup = chatId.endsWith('@g.us');

    if (isGroup) {
        const senderId = message.key.participant || message.key.remoteJid;
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, {
                text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️\nLe Lion ne peut pas punir sans les droits nécessaires.',
                ...channelInfo
            }, { quoted: message });
            return;
        }

        if (!isSenderAdmin && !message.key.fromMe) {
            await sock.sendMessage(chatId, {
                text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT BANNIR.* ☀️\nTu n\'as pas le pouvoir de commander le Lion.',
                ...channelInfo
            }, { quoted: message });
            return;
        }

    } else {
        const senderId = message.key.participant || message.key.remoteJid;
        const senderIsSudo = await isSudo(senderId);

        if (!message.key.fromMe && !senderIsSudo) {
            await sock.sendMessage(chatId, {
                text: '☀️ *SEUL MON MAÎTRE PEUT BANNIR EN PRIVÉ.* ☀️',
                ...channelInfo
            }, { quoted: message });
            return;
        }
    }

    let userToBan;

    // ✅ Mention
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToBan = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // ✅ Réponse
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToBan = message.message.extendedTextMessage.contextInfo.participant;
    }

    if (!userToBan) {
        await sock.sendMessage(chatId, {
            text: '☀️ *DÉSIGNE LE MORTEL À BANNIR.* ☀️\nMentionne-le ou réponds à son message.',
            ...channelInfo
        }, { quoted: message });
        return;
    }

    // ❌ Empêche de bannir le bot
    try {
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net';

        if (userToBan === botId || userToBan === botId.replace('@s.whatsapp.net', '@lid')) {
            await sock.sendMessage(chatId, {
                text: '☀️ *TU NE PEUX PAS BANNIR LE LION, MORTEL.* ☀️',
                ...channelInfo
            }, { quoted: message });
            return;
        }
    } catch {}

    try {
        let bannedUsers = [];

        // ✅ Sécurité si fichier vide ou inexistant
        if (fs.existsSync('./data/banned.json')) {
            bannedUsers = JSON.parse(fs.readFileSync('./data/banned.json'));
        }

        if (!bannedUsers.includes(userToBan)) {
            bannedUsers.push(userToBan);

            fs.writeFileSync('./data/banned.json', JSON.stringify(bannedUsers, null, 2));

            await sock.sendMessage(chatId, {
                text: `☀️ *BANNI !* ☀️\n@${userToBan.split('@')[0]} a été jugé indigne par le Lion.`,
                mentions: [userToBan],
                ...channelInfo
            }, { quoted: message });

        } else {
            await sock.sendMessage(chatId, {
                text: `☀️ *DÉJÀ BANNI* ☀️\n@${userToBan.split('@')[0]} est déjà dans l'ombre du Lion.`,
                mentions: [userToBan],
                ...channelInfo
            }, { quoted: message });
        }

    } catch (error) {
        console.error('☀️ Erreur dans la commande ban:', error);

        await sock.sendMessage(chatId, {
            text: '☀️ *ÉCHEC DU BAN.* ☀️\nMême le Lion peut trébucher... Réessaie, mortel.',
            ...channelInfo
        }, { quoted: message });
    }
}

module.exports = banCommand;