const fs = require('fs');
const path = require('path');
const isAdmin = require('../lib/isAdmin');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '☀️ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ ☀️',
            serverMessageId: -1
        }
    }
};

// Stockage des messages par utilisateur
const userMessages = new Map();

async function handleAntispamCommand(sock, chatId, message, senderId, isSenderAdmin, args) {
    try {
        // Récupérer le statut admin directement depuis le groupe si non fourni
        let adminStatus = isSenderAdmin;
        if (!adminStatus && !message.key.fromMe) {
            const adminCheck = await isAdmin(sock, chatId, senderId);
            adminStatus = adminCheck.isSenderAdmin;
        }

        // Vérifier si l'utilisateur est admin ou le propriétaire du bot
        const isOwner = senderId === '243832881281@s.whatsapp.net' || 
                        senderId === '243832881281' || 
                        senderId.includes('243832881281');

        if (!adminStatus && !message.key.fromMe && !isOwner) {
            return sock.sendMessage(chatId, {
                text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT GÉRER L\'ANTISPAM.* ☀️\nLe Lion n\'obéit qu\'à ceux qui ont le pouvoir.',
                ...channelInfo
            }, { quoted: message });
        }

        const action = args[0]?.toLowerCase();
        const configPath = path.join(__dirname, '../data/antispam.json');
        let config = { enabled: false, action: 'delete', limit: 5, interval: 3000 };

        if (fs.existsSync(configPath)) {
            config = JSON.parse(fs.readFileSync(configPath));
        }

        if (!action) {
            return sock.sendMessage(chatId, {
                text: `☀️ *ANTISPAM – PROTECTION DU LION* ☀️\n\nStatut: ${config.enabled ? 'ACTIVÉ' : 'DÉSACTIVÉ'}\nAction: ${config.action}\nLimite: ${config.limit} messages / ${config.interval/1000}s\n\nCommandes:\n.antispam on → Activer\n.antispam off → Désactiver\n.antispam set delete/kick/warn → Changer l'action\n.antispam limit <nombre> → Changer la limite\n.antispam interval <secondes> → Changer l'intervalle`,
                ...channelInfo
            }, { quoted: message });
        }

        switch (action) {
            case 'on':
                config.enabled = true;
                fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
                return sock.sendMessage(chatId, { text: '☀️ *ANTISPAM ACTIVÉ* ☀️\nLe Lion veille sur le spam.', ...channelInfo }, { quoted: message });

            case 'off':
                config.enabled = false;
                fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
                return sock.sendMessage(chatId, { text: '☀️ *ANTISPAM DÉSACTIVÉ* ☀️\nLe Lion baisse sa garde...', ...channelInfo }, { quoted: message });

            case 'set':
                const newAction = args[1]?.toLowerCase();
                if (!newAction || !['delete', 'kick', 'warn'].includes(newAction)) {
                    return sock.sendMessage(chatId, { text: '☀️ *ACTION INVALIDE* ☀️\nChoisis: delete, kick ou warn.', ...channelInfo }, { quoted: message });
                }
                config.action = newAction;
                fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
                return sock.sendMessage(chatId, { text: `☀️ *ACTION ANTISPAM DÉFINIE SUR: ${newAction.toUpperCase()}* ☀️`, ...channelInfo }, { quoted: message });

            case 'limit':
                const newLimit = parseInt(args[1]);
                if (isNaN(newLimit) || newLimit < 2 || newLimit > 20) {
                    return sock.sendMessage(chatId, { text: '☀️ *LIMITE INVALIDE* ☀️\nUtilise un nombre entre 2 et 20.', ...channelInfo }, { quoted: message });
                }
                config.limit = newLimit;
                fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
                return sock.sendMessage(chatId, { text: `☀️ *LIMITE ANTISPAM: ${newLimit} MESSAGES* ☀️`, ...channelInfo }, { quoted: message });

            case 'interval':
                const newInterval = parseInt(args[1]) * 1000;
                if (isNaN(newInterval) || newInterval < 1000 || newInterval > 30000) {
                    return sock.sendMessage(chatId, { text: '☀️ *INTERVALLE INVALIDE* ☀️\nUtilise un nombre entre 1 et 30 secondes.', ...channelInfo }, { quoted: message });
                }
                config.interval = newInterval;
                fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
                return sock.sendMessage(chatId, { text: `☀️ *INTERVALLE ANTISPAM: ${args[1]} SECONDES* ☀️`, ...channelInfo }, { quoted: message });

            default:
                return sock.sendMessage(chatId, { text: '☀️ *COMMANDE INVALIDE* ☀️\nUtilise .antispam pour voir les options.', ...channelInfo }, { quoted: message });
        }
    } catch (error) {
        console.error('☀️ Erreur antispam command:', error);
        await sock.sendMessage(chatId, { text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️', ...channelInfo }, { quoted: message });
    }
}

// Détection du spam
async function handleSpamDetection(sock, chatId, message, senderId, userMessage) {
    // Vérifier si c'est un groupe
    if (!chatId.endsWith('@g.us')) return;

    const configPath = path.join(__dirname, '../data/antispam.json');
    if (!fs.existsSync(configPath)) return;
    
    const config = JSON.parse(fs.readFileSync(configPath));
    if (!config.enabled) return;

    // Vérifier si le bot est admin
    const { isBotAdmin } = await isAdmin(sock, chatId, senderId);
    if (!isBotAdmin) return;

    // Vérifier si l'expéditeur est admin
    const { isSenderAdmin } = await isAdmin(sock, chatId, senderId);
    if (isSenderAdmin) return;

    // Vérifier si l'expéditeur est le propriétaire
    const isOwner = senderId === '243832881281@s.whatsapp.net' || 
                    senderId === '243832881281' || 
                    senderId.includes('243832881281');
    if (isOwner) return;

    const now = Date.now();
    const userKey = `${chatId}_${senderId}`;

    if (!userMessages.has(userKey)) {
        userMessages.set(userKey, { times: [], count: 0 });
    }

    const userData = userMessages.get(userKey);
    userData.times.push(now);
    userData.count++;

    // Nettoyer les anciens messages (hors intervalle)
    userData.times = userData.times.filter(t => now - t < config.interval);

    if (userData.count >= config.limit && userData.times.length >= config.limit) {
        // Spam détecté
        const action = config.action || 'delete';

        // Supprimer le message
        try {
            await sock.sendMessage(chatId, { delete: message.key });
        } catch (e) {}

        if (action === 'delete') {
            await sock.sendMessage(chatId, {
                text: `☀️ *SPAM DÉTECTÉ* ☀️\n@${senderId.split('@')[0]}, ne spamme pas. Le Lion veille.`,
                mentions: [senderId],
                ...channelInfo
            });
        } else if (action === 'kick') {
            await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
            await sock.sendMessage(chatId, {
                text: `☀️ *SPAM DÉTECTÉ* ☀️\n@${senderId.split('@')[0]} a été expulsé pour spam.`,
                mentions: [senderId],
                ...channelInfo
            });
        } else if (action === 'warn') {
            const warningsPath = path.join(__dirname, '../data/warnings.json');
            let warnings = {};
            if (fs.existsSync(warningsPath)) {
                warnings = JSON.parse(fs.readFileSync(warningsPath));
            }
            if (!warnings[chatId]) warnings[chatId] = {};
            if (!warnings[chatId][senderId]) warnings[chatId][senderId] = 0;
            warnings[chatId][senderId]++;

            if (warnings[chatId][senderId] >= 3) {
                await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
                delete warnings[chatId][senderId];
                await sock.sendMessage(chatId, {
                    text: `☀️ *SPAM DÉTECTÉ* ☀️\n@${senderId.split('@')[0]} a été expulsé après 3 avertissements.`,
                    mentions: [senderId],
                    ...channelInfo
                });
            } else {
                await sock.sendMessage(chatId, {
                    text: `☀️ *SPAM DÉTECTÉ* ☀️\n@${senderId.split('@')[0]} avertissement ${warnings[chatId][senderId]}/3.`,
                    mentions: [senderId],
                    ...channelInfo
                });
            }
            fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));
        }

        // Réinitialiser le compteur
        userData.times = [];
        userData.count = 0;
    }

    // Nettoyage périodique (toutes les 5 minutes)
    setTimeout(() => {
        const oldData = userMessages.get(userKey);
        if (oldData && oldData.times.length === 0 && oldData.count === 0) {
            userMessages.delete(userKey);
        }
    }, 300000);
}

module.exports = { handleAntispamCommand, handleSpamDetection };