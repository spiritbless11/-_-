const { isAdmin } = require('../lib/isAdmin');
const sendStyledMessage = require('../utils/sendStyledMessage');

const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

// 🗡️ ANTI-DOUBLON POUR DÉMOTION (Map JID + Timestamp)
const recentDemotions = new Map();

// ============================================================================
// 🦁 COMMANDE DEMOTE – RÉTROGRADER UN ADMIN
// ============================================================================
async function demoteCommand(sock, chatId, mentionedJids, message) {
    let userToDemote = [];
    
    // 🎯 Récupération de la cible via mention ou réponse
    if (mentionedJids && mentionedJids.length > 0) {
        userToDemote = mentionedJids.map(jid => 
            jid.includes('@') ? jid : `${jid}@s.whatsapp.net`
        );
    } else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToDemote = [message.message.extendedTextMessage.contextInfo.participant];
    }
    
    // ❌ Aucune cible spécifiée
    if (userToDemote.length === 0) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *DÉSIGNE LE MORTEL À RÉTROGRADER.* ☀️\n\n⚡ *MENTIONNE-LE OU RÉPONDS À SON MESSAGE.* ☀️`, 
            message, [], channelContext
        );
        return;
    }

    try {
        // 🔒 Marquer comme traité AVANT exécution pour bloquer l'événement automatique
        const now = Date.now();
        userToDemote.forEach(jid => recentDemotions.set(jid.split('@')[0], now));

        // ✅ Exécution de la démotion
        await sock.groupParticipantsUpdate(chatId, userToDemote, "demote");
                const senderJid = message.key.participant || message.key.remoteJid;
        const senderNum = senderJid.split('@')[0];
        
        // ⚠️ FORMATAGE STRICT POUR MENTIONS WHATSAPP : @NUMÉRO (sans +, sans espace)
        const demotedTags = userToDemote.map(jid => `@${jid.split('@')[0]}`);

        const demotionMessage = `☀️ *DÉMOTION – LE LION DÉCHOIT UN MORTEL* ☀️\n\n👤 *RÉTROGRADÉ${userToDemote.length > 1 ? 'S' : ''}:*\n┃ ${demotedTags.join('\n┃ ')}\n\n👑 *PAR:* @${senderNum}\n\n📅 *DATE:* ${new Date().toLocaleString()}\n\n☀️ *LE POUVOIR A ÉTÉ RETIRÉ. L'HUMILITÉ S'IMPOSE.* ☀️\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;
        
        // 📦 5ème argument = tableau de JIDs complets pour mentions cliquables
        await sendStyledMessage(
            sock, 
            chatId, 
            demotionMessage, 
            message, 
            [...userToDemote, senderJid], 
            channelContext
        );
        
    } catch (error) {
        console.error('☀️ ERREUR DANS LA COMMANDE DEMOTE:', error);
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DE LA DÉMOTION.* ☀️\n\n⚠️ *LE LION RENCONTRE UN OBSTACLE.* ☀️`, 
            message, [], channelContext
        );
    }
}

// ============================================================================
// 🔄 GESTIONNAIRE D'ÉVÉNEMENT DÉMOTION (AUTOMATIQUE)
// ============================================================================
async function handleDemotionEvent(sock, groupId, participants, author) {
    try {
        if (!Array.isArray(participants) || participants.length === 0) return;

        // 🛡️ VÉRIFICATION ANTI-DOUBLON (Fenêtre de 3 secondes)
        const now = Date.now();
        const isRecent = participants.some(p => {
            const pNum = (typeof p === 'string' ? p : (p.id || p.toString())).split('@')[0];
            const time = recentDemotions.get(pNum);
            return time && (now - time < 3000);
        });

        if (isRecent) {
            console.log('☀️ Démotion déjà annoncée par commande → Événement ignoré.');
            return; // 👈 Tue le double message
        }

        // ✅ Normalisation des JIDs
        const normalizedParticipants = participants.map(jid => {
            const jidString = typeof jid === 'string' ? jid : (jid.id || jid.toString());            return jidString.includes('@') ? jidString : `${jidString}@s.whatsapp.net`;
        });

        const demotedTags = normalizedParticipants.map(jid => `@${jid.split('@')[0]}`);
        let demotedBy = 'SYSTÈME';
        let mentionList = [...normalizedParticipants];

        if (author && author.length > 0) {
            const authorJid = typeof author === 'string' ? author : (author.id || author.toString());
            const normAuthor = authorJid.includes('@') ? authorJid : `${authorJid}@s.whatsapp.net`;
            demotedBy = `@${normAuthor.split('@')[0]}`;
            mentionList.push(normAuthor);
        }

        const demotionMessage = `☀️ *DÉMOTION AUTOMATIQUE – LE LION VEILLE* ☀️\n\n👤 *RÉTROGRADÉ${normalizedParticipants.length > 1 ? 'S' : ''}:*\n┃ ${demotedTags.join('\n┃ ')}\n\n👑 *PAR:* ${demotedBy}\n\n📅 *DATE:* ${new Date().toLocaleString()}\n\n☀️ *LE LION RETIRE SA CONFIANCE. RESPECTEZ SA DÉCISION.* ☀️\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;
        
        await sendStyledMessage(
            sock, 
            groupId, 
            demotionMessage, 
            null, 
            mentionList, 
            channelContext
        );
        
    } catch (error) {
        console.error('☀️ ERREUR ÉVÉNEMENT DÉMOTION:', error);
    }
}

module.exports = { demoteCommand, handleDemotionEvent };