/**
 * ☀️ COMMANDE HIDETAG – ESCANOR PRIME ☀️
 * Envoie un message en mentionnant tous les non-admins de façon "masquée"
 */

const isAdmin = require('../lib/isAdmin');
const sendStyledMessage = require('../utils/sendStyledMessage');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ .  🅓𝐄𝐕 𝐋𝐁 𝐁 ᥬ𝐑 𝐁𝐋𝐄𝐒᭄ 🅓𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

const FALLBACK_IMAGE = 'https://i.imgur.com/2wzGhpF.jpeg';

// ============================================================================
// 📥 TÉLÉCHARGEMENT DE MÉDIA
// ============================================================================
async function downloadMediaMessage(message, mediaType) {
    const stream = await downloadContentFromMessage(message, mediaType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
        buffer = Buffer.concat([buffer, chunk]);
    }
    
    const tmpDir = path.join(__dirname, '../temp/');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
    
    const filePath = path.join(tmpDir, `${Date.now()}.${mediaType}`);
    fs.writeFileSync(filePath, buffer);
    return filePath;
}

// ============================================================================
// 🦁 COMMANDE HIDETAG
// ============================================================================
async function hideTagCommand(sock, chatId, senderId, messageText, replyMessage, message) {    const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

    if (!isBotAdmin) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️\n\n⚡ *LE LION NE PEUT PARLER À LA FOULE SANS AUTORITÉ.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        return;
    }

    if (!isSenderAdmin) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *SEULS LES ADMINISTRATEURS PEUVENT MENTIONNER EN MASQUE.* ☀️\n\n⚠️ *TU N'AS PAS LE POUVOIR DE COMMANDER LE LION.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        return;
    }

    const groupMetadata = await sock.groupMetadata(chatId);
    const participants = groupMetadata.participants || [];
    const nonAdmins = participants.filter(p => !p.admin).map(p => p.id);

    if (nonAdmins.length === 0) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *AUCUN MORTEL À MENTIONNER.* ☀️\n\n⚡ *TOUS LES MEMBRES SONT DÉJÀ DES ÉLUS DU LION.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        return;
    }

    try {
        if (replyMessage) {
            let content = {};
            let mediaPath = null;

            if (replyMessage.imageMessage) {
                mediaPath = await downloadMediaMessage(replyMessage.imageMessage, 'image');
                content = { 
                    image: { url: mediaPath }, 
                    caption: messageText || replyMessage.imageMessage.caption || '', 
                    mentions: nonAdmins 
                };
            }
            else if (replyMessage.videoMessage) {
                mediaPath = await downloadMediaMessage(replyMessage.videoMessage, 'video');
                content = { 
                    video: { url: mediaPath }, 
                    caption: messageText || replyMessage.videoMessage.caption || '', 
                    mentions: nonAdmins 
                };            }
            else if (replyMessage.documentMessage) {
                mediaPath = await downloadMediaMessage(replyMessage.documentMessage, 'document');
                content = { 
                    document: { url: mediaPath }, 
                    fileName: replyMessage.documentMessage.fileName, 
                    caption: messageText || '', 
                    mentions: nonAdmins 
                };
            }
            else if (replyMessage.conversation || replyMessage.extendedTextMessage) {
                const textContent = replyMessage.conversation || replyMessage.extendedTextMessage.text;
                const styledText = textContent.toUpperCase().replace(/\*\*/g, '*');
                
                content = { 
                    text: styledText, 
                    mentions: nonAdmins 
                };
            }

            if (Object.keys(content).length > 0) {
                const finalOptions = {
                    ...content,
                    contextInfo: {
                        ...channelContext.contextInfo,
                        ...(content.contextInfo || {})
                    }
                };
                
                await sock.sendMessage(chatId, finalOptions, { quoted: message });
                
                if (mediaPath && fs.existsSync(mediaPath)) {
                    try { 
                        fs.unlinkSync(mediaPath); 
                    } catch (e) {
                        console.error('☀️ ERREUR NETTOYAGE FICHIER:', e);
                    }
                }
            }
        } else {
            const finalText = messageText 
                ? `☀️ *MESSAGE DU LION – MENTION MASQUÉE* ☀️\n\n${messageText.toUpperCase()}\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐒𝐒𝐃𝐄 𖤍『𝐘𝐒_𝐇𝐀𝐂𝐄』༒* ☀️`
                : `☀️ *MESSAGE DU LION – MENTION MASQUÉE* ☀️\n\n🔥 *LE LION PARLE. TOUS LES MORTELS ÉCOUTENT.* 🔥\n\n☀️ *© ᴹᴿ𖤍𝐋𝐄𝐒𝐃𝐄𝐕 『𝐒𝐒_𝐀𝐂𝐄』༒* ☀️`;
            
            await sendStyledMessage(
                sock, 
                chatId, 
                finalText, 
                message, 
                nonAdmins,                { ...channelContext, image: { url: FALLBACK_IMAGE } }
            );
        }
    } catch (error) {
        console.error('☀️ ERREUR DANS LA COMMANDE HIDETAG:', error);
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DE L'ENVOI MASQUÉ.* ☀️\n\n⚠️ *MÊME LE LION PEUT AVOIR UN HOQUET. RÉESSAIE, MORTEL.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

module.exports = hideTagCommand;