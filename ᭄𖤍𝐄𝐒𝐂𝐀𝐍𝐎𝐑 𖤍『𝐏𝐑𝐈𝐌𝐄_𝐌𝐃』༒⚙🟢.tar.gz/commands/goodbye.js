/**
 * ☀️ COMMANDE GOODBYE – ESCANOR PRIME ☀️
 * Message de départ stylisé quand un membre quitte le groupe
 */

const sendStyledMessage = require('../utils/sendStyledMessage');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

// 🖼️ IMAGES DE SECOURS SI PHOTO DE PROFIL INDISPONIBLE
const FALLBACK_IMAGES = [
    'https://i.imgur.com/vuxb8q8.jpeg',
    'https://i.imgur.com/bnNqadw.jpeg',
    'https://i.imgur.com/dPs7W0M.jpeg',
    'https://i.imgur.com/yfzN3SF.jpeg',
    'https://i.imgur.com/CsM1J92.jpeg'
];

// 🗄️ STATUT GOODBYE PAR GROUPE (Idéalement à remplacer par SQLite/JSON persistant)
const goodbyeStatus = {};

// ============================================================================
// 🦁 GESTIONNAIRE D'ÉVÉNEMENT DÉPART – HANDLE LEAVE
// ============================================================================
async function handleLeaveEvent(sock, chatId, participants) {
    if (!goodbyeStatus[chatId]) return;

    try {
        const groupMetadata = await sock.groupMetadata(chatId);
        const groupName = groupMetadata.subject || 'DOMAINE INCONNU';
        const totalMembers = groupMetadata.participants?.length || 0;
        const totalAdmins = groupMetadata.participants?.filter(p => p.admin)?.length || 0;

        for (const participant of participants) {
            const participantJid = typeof participant === 'string' ? participant : (participant.id || participant.toString());
            const userName = participantJid.split('@')[0];
            const userMention = `@${userName}`;
            // 🖼️ Récupérer la photo de profil ou fallback
            let userPic;
            try {
                userPic = await sock.profilePictureUrl(participantJid, 'image');
            } catch {
                userPic = FALLBACK_IMAGES[Math.floor(Math.random() * FALLBACK_IMAGES.length)];
            }

            // 🕐 Variables dynamiques
            const now = new Date();
            const time = now.toLocaleTimeString("fr-FR", { timeZone: "Africa/Douala" });
            const date = now.toLocaleDateString("fr-FR", { timeZone: "Africa/Douala" });

            // 📜 Message style Escanor – 100% MAJUSCULE + GRAS
            const goodbyeMessage = `☀️ *LE LION TE SALUE, MORTEL* ☀️\n\n🦁 *UTILISATEUR :* ${userMention}\n🏰 *DOMAINE :* ${groupName.toUpperCase()}\n📊 *MEMBRES RESTANTS :* ${totalMembers}\n👑 *ADMINS :* ${totalAdmins}\n⏰ *HEURE :* ${time}\n📅 *DATE :* ${date}\n\n🔥 *PUISE TA FIERTÉ AILLEURS. LE LION NE TE RETIENT PAS.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;

            // 📤 Envoi avec sendStyledMessage + mentions cliquables + bouton chaîne + image
            await sendStyledMessage(
                sock,
                chatId,
                goodbyeMessage,
                null,
                [participantJid], // 👈 JID complet pour mention cliquable
                { ...channelContext, image: { url: userPic } }
            );
        }
    } catch (error) {
        console.error('☀️ ERREUR GOODBYE EVENT:', error);
    }
}

// ============================================================================
// ⚙️ COMMANDE .GOODBYE – ACTIVER / DÉSACTIVER / TESTER
// ============================================================================
async function goodbyeCommand(sock, chatId, message) {
    // 🔐 Vérification : commande groupe uniquement
    if (!chatId.endsWith('@g.us')) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *CETTE COMMANDE N'EST DISPONIBLE QU'EN GROUPE.* ☀️`, 
            message, [], channelContext
        );
        return;
    }

    const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
    const args = text.trim().split(/\s+/).slice(1);
    const action = args[0]?.toLowerCase();

    if (action === 'on') {        goodbyeStatus[chatId] = true;
        await sendStyledMessage(sock, chatId, 
            `☀️ *MESSAGES DE DÉPART ACTIVÉS DANS CE DOMAINE.* ☀️\n\n🦁 *LE LION SALUERA CHAQUE MORTEL QUI S'EN VA.* ☀️`, 
            message, [], channelContext
        );
    } else if (action === 'off') {
        goodbyeStatus[chatId] = false;
        await sendStyledMessage(sock, chatId, 
            `☀️ *MESSAGES DE DÉPART DÉSACTIVÉS DANS CE DOMAINE.* ☀️\n\n🦁 *LE LION SE TAIT. LES DÉPARTS PASSERONT INAPERÇUS.* ☀️`, 
            message, [], channelContext
        );
    } else if (action === 'test') {
        const senderJid = message.key.participant || message.key.remoteJid;
        await handleLeaveEvent(sock, chatId, [senderJid]);
        await sendStyledMessage(sock, chatId, 
            `☀️ *TEST GOODBYE EFFECTUÉ.* ☀️\n\n⚡ *LE LION A PARLÉ.* ☀️`, 
            message, [], channelContext
        );
    } else {
        const helpText = `☀️ *COMMANDE GOODBYE – CONTRÔLE LES ADIEUX* ☀️\n\n⚡ *.goodbye on* – Activer les messages de départ\n⚡ *.goodbye off* – Désactiver\n⚡ *.goodbye test* – Tester immédiatement\n\n☀️ *LE LION ATTEND TON ORDRE.* ☀️`;
        await sendStyledMessage(sock, chatId, helpText, message, [], channelContext);
    }
}

// ============================================================================
// 📦 UTILITAIRES EXPORTÉS
// ============================================================================
function setGoodbye(groupId, status) {
    goodbyeStatus[groupId] = !!status;
}

function isGoodbyeOn(groupId) {
    return !!goodbyeStatus[groupId];
}

module.exports = { handleLeaveEvent, goodbyeCommand, setGoodbye, isGoodbyeOn };