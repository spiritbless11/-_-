async function shipCommand(sock, chatId, msg, groupMetadata) {
    try {
        const participants = await sock.groupMetadata(chatId);
        const ps = participants.participants.map(v => v.id);
        
        let firstUser, secondUser;
        
        firstUser = ps[Math.floor(Math.random() * ps.length)];
        
        do {
            secondUser = ps[Math.floor(Math.random() * ps.length)];
        } while (secondUser === firstUser);

        const formatMention = id => '@' + id.split('@')[0];

        await sock.sendMessage(chatId, {
            text: `☀️ *MATCH DU LION* ☀️\n\n${formatMention(firstUser)} ❤️ ${formatMention(secondUser)}\n\n🔥 *Le Lion bénit cette union mortelle.* 🔥`,
            mentions: [firstUser, secondUser]
        });

    } catch (error) {
        console.error('☀️ Erreur dans ship:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DU SHIP.* ☀️\nAssure-toi d\'être dans un groupe.' });
    }
}

module.exports = shipCommand;