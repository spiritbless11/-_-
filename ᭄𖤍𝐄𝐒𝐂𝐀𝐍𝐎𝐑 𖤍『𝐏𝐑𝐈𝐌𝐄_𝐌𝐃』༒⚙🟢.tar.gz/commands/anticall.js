const fs = require('fs');
const path = require('path');
const sendStyledMessage = require('../utils/sendStyledMessage'); // ✅ AJOUT

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

const ANTICALL_PATH = './data/anticall.json';

function readState() {
    try {
        if (!fs.existsSync(ANTICALL_PATH)) {
            const defaultState = { enabled: false };
            fs.writeFileSync(ANTICALL_PATH, JSON.stringify(defaultState, null, 2));
            return defaultState;
        }
        const raw = fs.readFileSync(ANTICALL_PATH, 'utf8');
        const data = JSON.parse(raw || '{}');
        return { enabled: !!data.enabled };
    } catch {
        return { enabled: false };
    }
}

function writeState(enabled) {
    try {
        if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
        fs.writeFileSync(ANTICALL_PATH, JSON.stringify({ enabled: !!enabled }, null, 2));
    } catch {}
}

async function anticallCommand(sock, chatId, message, args) {
    const state = readState();
    const sub = (args || '').trim().toLowerCase();

    // 📜 MENU
    if (!sub || (sub !== 'on' && sub !== 'off' && sub !== 'status')) {
        await sendStyledMessage(sock, chatId,
            '☀️ *ANTICALL – LA PROTECTION DU LION* ☀️\n\n.anticall on  - Activer le blocage automatique des appels\n.anticall off - Désactiver l\'anticall\n.anticall status - Voir l\'état actuel',
            message
        );
        return;
    }

    // 📊 STATUS
    if (sub === 'status') {
        await sendStyledMessage(sock, chatId,
            `☀️ *ÉTAT DE L'ANTICALL* ☀️\n\nLa protection du Lion est actuellement *${state.enabled ? 'ACTIVÉE' : 'DÉSACTIVÉE'}*.`,
            message
        );
        return;
    }

    // 🔄 ON / OFF
    const enable = sub === 'on';
    writeState(enable);

    await sendStyledMessage(sock, chatId,
        `☀️ *ANTICALL* ☀️\n\nLa protection du Lion est désormais *${enable ? 'ACTIVÉE' : 'DÉSACTIVÉE'}*. ${enable ? 'Que les mortels téméraires tremblent.' : 'Le Lion baisse sa garde... pour l\'instant.'}`,
        message
    );
}

// 📞 GESTION DES APPELS (MODIFIÉ AUSSI)
async function handleCall(sock, call) {
    const state = readState();
    if (!state.enabled) return;

    try {
        const callerJid = call.from || call.peerJid || call.chatId;
        if (!callerJid) return;

        // ❌ Rejeter l'appel
        try {
            if (typeof sock.rejectCall === 'function' && call.id) {
                await sock.rejectCall(call.id, callerJid);
            } else if (typeof sock.sendCallOfferAck === 'function' && call.id) {
                await sock.sendCallOfferAck(call.id, callerJid, 'reject');
            }
        } catch {}

        // ⚠️ Message stylé
        await sendStyledMessage(sock, callerJid,
            '☀️ *OSES-TU DÉRANGER LE LION ?* ☀️\nAppel rejeté. Tu vas être bloqué. La prochaine fois, réfléchis à deux fois avant de défier la fierté absolue.',
            null // pas de message à quote ici
        );

        // 🚫 Blocage
        setTimeout(async () => {
            try {
                await sock.updateBlockStatus(callerJid, 'block');
                console.log(`☀️ Utilisateur ${callerJid} bloqué pour appel`);
            } catch (e) {}
        }, 1000);

    } catch (error) {
        console.error('☀️ Erreur dans anticall:', error);
    }
}

module.exports = { anticallCommand, readState, handleCall };