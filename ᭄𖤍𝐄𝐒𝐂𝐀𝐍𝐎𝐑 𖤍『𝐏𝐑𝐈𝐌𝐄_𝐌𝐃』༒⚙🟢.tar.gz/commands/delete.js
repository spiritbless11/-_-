/**
 * ☀️ COMMANDE DELETE – ESCANOR PRIME ☀️
 * Supprime des messages avec l'autorité du Lion
 */

const isAdmin = require('../lib/isAdmin');
const sendStyledMessage = require('../utils/sendStyledMessage');
const store = require('../lib/lightweight_store');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE – BOUTON CHAÎNE + IMAGE FALLBACK
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

const FALLBACK_IMAGE = 'https://i.imgur.com/2wzGhpF.jpeg';

// ============================================================================
// 🦁 COMMANDE DELETE – VERSION PRINCIPALE
// ============================================================================
async function deleteCommand(sock, chatId, message, senderId) {
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        // 🔐 Vérification : le bot doit être admin
        if (!isBotAdmin) {
            await sendStyledMessage(sock, chatId, 
                `☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️\n\n⚡ *LE LION NE PEUT PAS SUPPRIMER SANS LES DROITS NÉCESSAIRES.* ☀️`, 
                message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
            );
            return;
        }

        // 🔐 Vérification : seul un admin peut utiliser cette commande
        if (!isSenderAdmin) {
            await sendStyledMessage(sock, chatId, 
                `☀️ *SEULS LES ADMINISTRATEURS PEUVENT SUPPRIMER.* ☀️\n\n⚠️ *TU N'AS PAS LE POUVOIR DE COMMANDER LE LION.* ☀️`, 
                message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
            );
            return;
        }
        // 📝 Analyse des arguments
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text || '';
        const parts = text.trim().split(/\s+/);
        let countArg = null;
        
        // Vérifier si un nombre est fourni
        if (parts.length > 1) {
            const maybeNum = parseInt(parts[1], 10);
            if (!isNaN(maybeNum) && maybeNum > 0) {
                countArg = Math.min(maybeNum, 50); // Max 50 messages
            }
        }
        
        // Contexte du message cité
        const ctxInfo = message.message?.extendedTextMessage?.contextInfo || {};
        const repliedParticipant = ctxInfo.participant || null;
        const mentioned = Array.isArray(ctxInfo.mentionedJid) && ctxInfo.mentionedJid.length > 0 ? ctxInfo.mentionedJid[0] : null;
        
        // Si pas de nombre mais réponse à un message → défaut à 1
        if (countArg === null && repliedParticipant) {
            countArg = 1;
        }
        // Si pas de nombre et pas de cible → afficher l'aide
        else if (countArg === null && !repliedParticipant && !mentioned) {
            await sendStyledMessage(sock, chatId, 
                `☀️ *COMMANDE DE SUPPRESSION – LE LION EFFACE LES TRACES* ☀️\n\n⚡ *.del 5* – Supprimer les 5 derniers messages\n⚡ *.del 3 @user* – Supprimer les 3 derniers de @user\n⚡ *.del 2* (répondre) – Supprimer les 2 derniers messages\n\n☀️ *DONNE TON ORDRE, MORTEL.* ☀️`, 
                message, [], channelContext
            );
            return;
        }
        // Si pas de nombre mais mention → défaut à 1
        else if (countArg === null && mentioned) {
            countArg = 1;
        }

        // 🎯 Détermination de la cible
        let targetUser = null;
        let repliedMsgId = null;
        let deleteGroupMessages = false;
        
        if (repliedParticipant && ctxInfo.stanzaId) {
            targetUser = repliedParticipant;
            repliedMsgId = ctxInfo.stanzaId;
        } else if (mentioned) {
            targetUser = mentioned;
        } else {
            // Pas de cible → suppression des derniers messages du groupe
            deleteGroupMessages = true;
        }
        // 🗄️ Récupération des messages depuis le store
        const chatMessages = Array.isArray(store.messages[chatId]) ? store.messages[chatId] : [];
        const toDelete = [];
        const seenIds = new Set();

        if (deleteGroupMessages) {
            // Supprimer les N derniers messages du groupe (peu importe l'auteur)
            for (let i = chatMessages.length - 1; i >= 0 && toDelete.length < countArg; i--) {
                const m = chatMessages[i];
                if (!seenIds.has(m.key.id)) {
                    if (!m.message?.protocolMessage && !m.key.fromMe && m.key.id !== message.key.id) {
                        toDelete.push(m);
                        seenIds.add(m.key.id);
                    }
                }
            }
        } else {
            // Supprimer les messages d'un utilisateur spécifique
            if (repliedMsgId) {
                const repliedInStore = chatMessages.find(m => m.key.id === repliedMsgId && (m.key.participant || m.key.remoteJid) === targetUser);
                if (repliedInStore) {
                    toDelete.push(repliedInStore);
                    seenIds.add(repliedInStore.key.id);
                } else {
                    // Si pas dans le store, tenter suppression directe
                    try {
                        await sock.sendMessage(chatId, {
                            delete: {
                                remoteJid: chatId,
                                fromMe: false,
                                id: repliedMsgId,
                                participant: repliedParticipant
                            }
                        });
                        countArg = Math.max(0, countArg - 1);
                    } catch {}
                }
            }
            for (let i = chatMessages.length - 1; i >= 0 && toDelete.length < countArg; i--) {
                const m = chatMessages[i];
                const participant = m.key.participant || m.key.remoteJid;
                if (participant === targetUser && !seenIds.has(m.key.id)) {
                    if (!m.message?.protocolMessage) {
                        toDelete.push(m);
                        seenIds.add(m.key.id);
                    }
                }
            }
        }
        // ❌ Aucun message à supprimer
        if (toDelete.length === 0) {
            const errorMsg = deleteGroupMessages 
                ? `☀️ *AUCUN MESSAGE RÉCENT À SUPPRIMER.* ☀️\n\n⚡ *LE LION NE TROUVE RIEN À EFFACER.* ☀️`
                : `☀️ *AUCUN MESSAGE RÉCENT TROUVÉ POUR CET UTILISATEUR.* ☀️\n\n⚡ *LE MORTEL N'A RIEN LAISSÉ DE SUPPRIMABLE.* ☀️`;
            await sendStyledMessage(sock, chatId, errorMsg, message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } });
            return;
        }

        // ⚡ Exécution des suppressions
        let deletedCount = 0;
        for (const m of toDelete) {
            try {
                const msgParticipant = deleteGroupMessages 
                    ? (m.key.participant || m.key.remoteJid) 
                    : (m.key.participant || targetUser);
                    
                await sock.sendMessage(chatId, {
                    delete: {
                        remoteJid: chatId,
                        fromMe: false,
                        id: m.key.id,
                        participant: msgParticipant
                    }
                });
                deletedCount++;
                await new Promise(r => setTimeout(r, 300)); // Petit délai entre chaque suppression
            } catch (e) {
                console.error('☀️ ERREUR SUPPRESSION MESSAGE:', e);
            }
        }

        // ✅ Confirmation de suppression
        const senderNum = senderId.split('@')[0];
        const targetMention = targetUser ? `@${targetUser.split('@')[0]}` : 'MESSAGES DU GROUPE';
        
        const successMessage = `☀️ *SUPPRESSION EFFECTUÉE – LE LION EFFACE LES TRACES* ☀️\n\n🗑️ *SUPPRIMÉS:* ${deletedCount} MESSAGE${deletedCount > 1 ? 'S' : ''}\n👤 *CIBLE:* ${targetMention}\n👑 *PAR:* @${senderNum}\n\n🔥 *CE QUI EST EFFACÉ NE PEUT ÊTRE RÉCUPÉRÉ. LE LION EST IMPLACABLE.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;
        
        await sendStyledMessage(
            sock, 
            chatId, 
            successMessage, 
            message, 
            targetUser ? [targetUser, senderId] : [senderId], // Mentions cliquables
            { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
        
    } catch (err) {
        console.error('☀️ ERREUR DANS LA COMMANDE DELETE:', err);        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DE LA SUPPRESSION.* ☀️\n\n⚠️ *MÊME LE LION PEUT AVOIR UN HOQUET. RÉESSAIE, MORTEL.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

module.exports = deleteCommand;