const fs = require('fs');
const path = require('path');
const isOwnerOrSudo = require('../lib/isOwner');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ಢྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function clearSessionCommand(sock, chatId, msg) {
    try {
        const senderId = msg.key.participant || msg.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
        
        if (!msg.key.fromMe && !isOwner) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *SEUL MON MAITRE PEUT UTILISER CETTE COMMANDE.* ☀️\nLe Lion n\'obeit qu\'a celui qui l\'a dompte.',
                ...channelInfo
            });
            return;
        }

        const sessionDir = path.join(__dirname, '../session');

        if (!fs.existsSync(sessionDir)) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *DOSSIER SESSION INTROUVABLE.* ☀️\nLe Lion ne trouve pas sa taniere.',
                ...channelInfo
            });
            return;
        }

        let filesCleared = 0;
        let errors = 0;
        let errorDetails = [];

        await sock.sendMessage(chatId, { 
            text: `☀️ *LE LION OPTIMISE SA TANIERE...* ☀️\nNettoyage en cours.`,
            ...channelInfo
        });

        const files = fs.readdirSync(sessionDir);
        
        let appStateSyncCount = 0;
        let preKeyCount = 0;

        for (const file of files) {
            if (file.startsWith('app-state-sync-')) appStateSyncCount++;
            if (file.startsWith('pre-key-')) preKeyCount++;
        }

        for (const file of files) {
            if (file === 'creds.json') continue;

            try {
                const filePath = path.join(sessionDir, file);
                fs.unlinkSync(filePath);
                filesCleared++;
            } catch (error) {
                errors++;
                errorDetails.push(`Echec suppression ${file}: ${error.message}`);
            }
        }

        const message = `☀️ *SESSION NETTOYEE AVEC SUCCES !* ☀️

STATISTIQUES :
- Fichiers supprimes: ${filesCleared}
- App-state: ${appStateSyncCount}
- Pre-key: ${preKeyCount}
${errors > 0 ? `\nERREURS: ${errors}\n${errorDetails.join('\n')}` : ''}`;

        await sock.sendMessage(chatId, { 
            text: message,
            ...channelInfo
        });

    } catch (error) {
        console.error('☀️ Erreur clearsession:', error);

        await sock.sendMessage(chatId, { 
            text: '☀️ *ECHEC DU NETTOYAGE.* ☀️\nLe Lion a echoue... Reessaie.',
            ...channelInfo
        });
    }
}

module.exports = clearSessionCommand;