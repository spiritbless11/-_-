const fs = require('fs');
const path = require('path');
const settings = require('../settings');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '☀️ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ ☀️',
            serverMessageId: -1
        }
    }
};

async function ownerCommand(sock, chatId) {
    // Chemin de l'image
    const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
    let imageBuffer;
    try {
        imageBuffer = fs.readFileSync(imagePath);
    } catch {
        imageBuffer = null;
    }

    const ownerMessage = `☀️ *᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒* ☀️
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

👑 *MAÎTRE SUPRÊME*
────────────────────
🔥 NOM : ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒
📞 CONTACT : wa.me/243832881281
💻 RÔLE : Développeur | Hacker | Créateur

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🔗 *LIENS OFFICIELS*
────────────────────
📢 CHAÎNE : https://whatsapp.com/channel/0029Vb78ycrInlqYocbYLX0P
👥 GROUPE : https://chat.whatsapp.com/B5PZoLePELTLXzDkTboMno

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

💀 *"Derrière le Lion se tient un homme.
    Derrière cet homme se tient une légende."* 💀

☀️ *© ESCANOR PRIME – Le Lion de l'Orgueil* ☀️
💀 > *Codé par ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* 💀`;

    // Boutons : DISCUTER + VOIR LA CHAÎNE
    const buttons = [
        { buttonId: 'owner', buttonText: { displayText: '💬 DISCUTER' }, type: 1 },
        { buttonId: 'channel', buttonText: { displayText: '📢 VOIR LA CHAÎNE' }, type: 1 }
    ];

    try {
        if (imageBuffer) {
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: ownerMessage,
                buttons: buttons,
                headerType: 1,
                ...channelInfo
            });
        } else {
            await sock.sendMessage(chatId, {
                text: ownerMessage,
                buttons: buttons,
                headerType: 1,
                ...channelInfo
            });
        }
    } catch (error) {
        console.error('☀️ Erreur dans la commande owner:', error);
        await sock.sendMessage(chatId, {
            text: `☀️ *UNE ERREUR S'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.`,
            ...channelInfo
        });
    }
}

module.exports = ownerCommand;