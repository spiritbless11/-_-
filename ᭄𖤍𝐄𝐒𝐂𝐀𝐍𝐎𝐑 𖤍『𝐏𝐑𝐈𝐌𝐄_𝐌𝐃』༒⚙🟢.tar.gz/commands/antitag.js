const { setAntitag, getAntitag, removeAntitag } = require('../lib/index');
const isAdmin = require('../lib/isAdmin');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '☀️ ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ ☀️',
            serverMessageId: -1
        }
    }
};

async function handleAntitagCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message) {
    try {
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT GÉRER L\'ANTITAG.* ☀️\nLe Lion n\'obéit qu\'à ceux qui ont le pouvoir.',
                ...channelInfo
            }, { quoted: message });
            return;
        }

        const prefix = '.';
        const args = userMessage.slice(9).toLowerCase().trim().split(' ');
        const action = args[0];

        if (!action) {
            const usage = `☀️ *ANTITAG – LA VIGILANCE DU LION* ☀️\n\n${prefix}antitag on\n${prefix}antitag set delete | kick\n${prefix}antitag off\n\n*Commande réservée aux administrateurs.*`;
            await sock.sendMessage(chatId, { text: usage, ...channelInfo }, { quoted: message });
            return;
        }

        switch (action) {
            case 'on':
                const existingConfig = await getAntitag(chatId, 'on');
                if (existingConfig?.enabled) {
                    await sock.sendMessage(chatId, { text: '☀️ *L\'ANTITAG EST DÉJÀ ACTIF.* ☀️', ...channelInfo }, { quoted: message });
                    return;
                }
                const result = await setAntitag(chatId, 'on', 'delete');
                await sock.sendMessage(chatId, { 
                    text: result ? '☀️ *L\'ANTITAG EST MAINTENANT ACTIF.* ☀️\nQue les menteurs tremblent.' : '☀️ *ÉCHEC DE L\'ACTIVATION DE L\'ANTITAG.* ☀️',
                    ...channelInfo 
                }, { quoted: message });
                break;

            case 'off':
                await removeAntitag(chatId, 'on');
                await sock.sendMessage(chatId, { text: '☀️ *L\'ANTITAG EST MAINTENANT DÉSACTIVÉ.* ☀️\nLe Lion baisse sa garde... pour l\'instant.', ...channelInfo }, { quoted: message });
                break;

            case 'set':
                if (args.length < 2) {
                    await sock.sendMessage(chatId, { 
                        text: `☀️ *COMMANDE INCOMPLÈTE* ☀️\nUtilisation: ${prefix}antitag set delete | kick`,
                        ...channelInfo 
                    }, { quoted: message });
                    return;
                }
                const setAction = args[1];
                if (!['delete', 'kick'].includes(setAction)) {
                    await sock.sendMessage(chatId, { 
                        text: '☀️ *ACTION INVALIDE.* ☀️\nChoisis: delete ou kick.',
                        ...channelInfo 
                    }, { quoted: message });
                    return;
                }
                const setResult = await setAntitag(chatId, 'on', setAction);
                await sock.sendMessage(chatId, { 
                    text: setResult ? `☀️ *ACTION ANTITAG DÉFINIE SUR : ${setAction.toUpperCase()}* ☀️` : '☀️ *ÉCHEC DE LA CONFIGURATION.* ☀️',
                    ...channelInfo 
                }, { quoted: message });
                break;

            case 'get':
                const status = await getAntitag(chatId, 'on');
                const actionConfig = await getAntitag(chatId, 'on');
                await sock.sendMessage(chatId, { 
                    text: `☀️ *CONFIGURATION ANTITAG* ☀️\n\nStatut: ${status ? 'ACTIF' : 'INACTIF'}\nAction: ${actionConfig ? actionConfig.action : 'Non définie'}`,
                    ...channelInfo 
                }, { quoted: message });
                break;

            default:
                await sock.sendMessage(chatId, { text: `☀️ *Utilise ${prefix}antitag pour voir les options.* ☀️`, ...channelInfo }, { quoted: message });
        }
    } catch (error) {
        console.error('☀️ Erreur dans la commande antitag:', error);
        await sock.sendMessage(chatId, { text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.', ...channelInfo }, { quoted: message });
    }
}

async function handleTagDetection(sock, chatId, message, senderId) {
    try {
        // Vérifier si c'est un groupe
        if (!chatId.endsWith('@g.us')) return;

        const antitagSetting = await getAntitag(chatId, 'on');
        if (!antitagSetting || !antitagSetting.enabled) return;

        // Vérifier si le bot est admin
        const { isBotAdmin, isSenderAdmin } = await isAdmin(sock, chatId, senderId);
        if (!isBotAdmin) return;
        if (isSenderAdmin) return;

        // Get mentioned JIDs from contextInfo (proper mentions)
        const mentionedJids = message.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
        
        // Extract text from all possible message types
        const messageText = (
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            message.message?.imageMessage?.caption ||
            message.message?.videoMessage?.caption ||
            ''
        );

        // Find all @mentions in text
        const textMentions = messageText.match(/@[\d+\s\-()~.]+/g) || [];
        const numericMentions = messageText.match(/@\d{10,}/g) || [];
        
        // Count unique numeric mentions
        const uniqueNumericMentions = new Set();
        numericMentions.forEach(mention => {
            const numMatch = mention.match(/@(\d+)/);
            if (numMatch) uniqueNumericMentions.add(numMatch[1]);
        });
        
        const mentionedJidCount = mentionedJids.length;
        const numericMentionCount = uniqueNumericMentions.size;
        const totalMentions = Math.max(mentionedJidCount, numericMentionCount);

        // Check if it's a group message and has multiple mentions
        if (totalMentions >= 3) {
            const groupMetadata = await sock.groupMetadata(chatId);
            const participants = groupMetadata.participants || [];
            const mentionThreshold = Math.ceil(participants.length * 0.5);
            const hasManyNumericMentions = numericMentionCount >= 10 || 
                                          (numericMentionCount >= 5 && numericMentionCount >= mentionThreshold);
            
            if (totalMentions >= mentionThreshold || hasManyNumericMentions) {
                const action = antitagSetting.action || 'delete';
                
                // Supprimer le message
                try {
                    await sock.sendMessage(chatId, {
                        delete: {
                            remoteJid: chatId,
                            fromMe: false,
                            id: message.key.id,
                            participant: senderId
                        }
                    });
                } catch (e) {}
                
                if (action === 'delete') {
                    await sock.sendMessage(chatId, {
                        text: `☀️ *TAG EN MASSE DÉTECTÉ* ☀️\n\n@${senderId.split('@')[0]}, le tag en masse est interdit. Le Lion veille.`,
                        mentions: [senderId],
                        ...channelInfo
                    });
                } else if (action === 'kick') {
                    await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
                    await sock.sendMessage(chatId, {
                        text: `☀️ *EXPULSION* ☀️\n\n@${senderId.split('@')[0]} a été expulsé pour avoir tagué tout le groupe.\n\n*Le Lion n'aime pas les tricheurs.*`,
                        mentions: [senderId],
                        ...channelInfo
                    });
                }
            }
        }
    } catch (error) {
        console.error('☀️ Erreur dans la détection de tag:', error);
    }
}

module.exports = {
    handleAntitagCommand,
    handleTagDetection
};