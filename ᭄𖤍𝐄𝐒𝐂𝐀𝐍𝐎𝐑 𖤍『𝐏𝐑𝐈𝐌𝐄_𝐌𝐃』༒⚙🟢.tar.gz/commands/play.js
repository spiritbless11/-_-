/**
 * ☀️ COMMANDE PLAY – ESCANOR PRIME ☀️
 * Télécharge de la musique YouTube avec la puissance du Lion
 */

const yts = require('yt-search');
const axios = require('axios');
const sendStyledMessage = require('../utils/sendStyledMessage');
const ytdl = require('ytdl-core');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE – BOUTON CHAÎNE + IMAGE FALLBACK
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

const FALLBACK_IMAGE = 'https://i.imgur.com/2wzGhpF.jpeg';

// Images pour les messages d'erreur
const PLAY_IMAGES = [
    'https://cdn-icons-png.flaticon.com/512/727/727218.png',
    'https://cdn-icons-png.flaticon.com/512/2995/2995101.png',
    'https://cdn-icons-png.flaticon.com/512/1384/1384060.png'
];

const getRandomImage = () => PLAY_IMAGES[Math.floor(Math.random() * PLAY_IMAGES.length)];

// ============================================================================
// 🎵 UTILITAIRES DE FORMATAGE
// ============================================================================
function formatDuration(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
}

function formatViews(views) {
    if (!views) return '0';
    if (views >= 1000000) return (views / 1000000).toFixed(1) + 'M';
    if (views >= 1000) return (views / 1000).toFixed(1) + 'K';
    return views.toString();}

// ============================================================================
// 🦁 COMMANDE PLAY – VERSION PRINCIPALE
// ============================================================================
async function playCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || 
                     message.message?.extendedTextMessage?.text || 
                     message.message?.imageMessage?.caption || 
                     "";

        const args = text.split(' ').slice(1);
        const searchQuery = args.join(' ').trim();

        // ❌ Aucune requête de recherche
        if (!searchQuery) {
            await sendStyledMessage(sock, chatId, 
                `☀️ *UTILISATION – DEMANDE UNE CHANSON AU LION* ☀️\n\n⚡ *.play <nom de la chanson>*\n⚡ *.play <lien YouTube>*\n\n🎵 *EXEMPLE:* .play shape of you\n\n☀️ *LE LION ATTEND TA REQUÊTE.* ☀️`, 
                message, [], { ...channelContext, image: { url: getRandomImage() } }
            );
            return;
        }

        // 🔍 Recherche YouTube
        const searchingMsg = await sendStyledMessage(sock, chatId, 
            `☀️ *LE LION CHERCHE TA MUSIQUE...* ☀️\n\n⏳ *PATIENCE, LA PUISSANCE DU SOLEIL S'ACTIVE.* ☀️`, 
            message, [], channelContext
        );

        let search;
        try {
            search = await yts(searchQuery);
        } catch (err) {
            console.error('Erreur yt-search:', err);
            await sendStyledMessage(sock, chatId, 
                `☀️ *ERREUR DE RECHERCHE.* ☀️\n\n⚠️ *LE LION NE PEUT ACCÉDER À YOUTUBE POUR LE MOMENT.* ☀️`, 
                message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
            );
            return;
        }

        if (!search.videos || search.videos.length === 0) {
            await sendStyledMessage(sock, chatId, 
                `☀️ *AUCUNE MUSIQUE TROUVÉE.* ☀️\n\n⚡ *ESSAIE D'AUTRES MOTS-CLÉS, MORTEL.* ☀️`, 
                message, [], { ...channelContext, image: { url: getRandomImage() } }
            );
            return;
        }
        const video = search.videos[0];
        const videoUrl = video.url;

        // 📜 Informations sur la vidéo
        const duration = video.seconds ? formatDuration(video.seconds) : 'Inconnue';
        const views = formatViews(video.views);
        const published = video.ago || 'Inconnue';
        const artist = video.author?.name || 'Inconnu';

        const infoText = `☀️ *ESCANOR PRIME – LECTURE MUSICALE* ☀️\n\n🎵 *TITRE:* ${video.title}\n👤 *ARTISTE:* ${artist}\n⏱️ *DURÉE:* ${duration}\n👁️ *VUES:* ${views}\n📅 *PUBLIÉ:* ${published}\n\n🔥 *QUE LA PUISSANCE DU SOLEIL GUIDE TA MUSIQUE.* 🔥\n\n☀️ *© ᴹᴿ᭄𝐁𝐋𝐄𝐒𝐃𝐄 𖤍『𝐒𝐘_𝐇𝐂𝐊𝐄𝐃』* ☀️`;

        // 📤 Envoi des informations avec la miniature
        try {
            await sock.sendMessage(chatId, { delete: searchingMsg.key });
        } catch (e) {}

        await sock.sendMessage(chatId, {
            image: { url: video.thumbnail },
            caption: infoText,
            contextInfo: {
                ...channelContext.contextInfo,
                externalAdReply: {
                    title: "🎵 " + video.title.substring(0, 50),
                    body: `👤 ${artist} | ⏱️ ${duration}`,
                    thumbnailUrl: video.thumbnail,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    sourceUrl: videoUrl
                }
            }
        });

        // 🎵 TÉLÉCHARGEMENT AUDIO – MÉTHODE 1: ytdl-core
        let audioBuffer = null;
        let audioUrl = null;

        try {
            console.log('🎵 Téléchargement avec ytdl-core...');
            
            const stream = ytdl(videoUrl, {
                quality: 'highestaudio',
                filter: format => format.mimeType === 'audio/webm; codecs="opus"' || format.mimeType === 'audio/mp4',
                highWaterMark: 1 << 25
            });

            const chunks = [];
            for await (const chunk of stream) {
                chunks.push(chunk);
            }
                        audioBuffer = Buffer.concat(chunks);
            console.log(`✅ Audio téléchargé: ${audioBuffer.length} bytes`);

        } catch (ytdlError) {
            console.error('Erreur ytdl-core:', ytdlError);
            
            // 🔄 MÉTHODE 2: API de secours
            try {
                console.log('🔄 Tentative avec API de secours...');
                
                const apiUrls = [
                    `https://api.davidcyriltech.my.id/download/ytmp3?url=${encodeURIComponent(videoUrl)}`,
                    `https://api.lolhuman.xyz/api/ytaudio?apikey=beta&url=${encodeURIComponent(videoUrl)}`,
                    `https://yt-dl.officialhectormanuel.workers.dev/?url=${encodeURIComponent(videoUrl)}`
                ];

                for (const apiUrl of apiUrls) {
                    try {
                        const { data } = await axios.get(apiUrl, { timeout: 20000 });
                        
                        if (data?.status === 200 || data?.result?.download_url || data?.audio) {
                            audioUrl = data.result?.download_url || data.audio || data.result?.url;
                            
                            if (audioUrl) {
                                const audioResponse = await axios.get(audioUrl, {
                                    responseType: 'arraybuffer',
                                    timeout: 40000,
                                    headers: {
                                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                                        'Accept': '*/*'
                                    }
                                });
                                
                                audioBuffer = Buffer.from(audioResponse.data);
                                console.log(`✅ Audio téléchargé via API: ${audioBuffer.length} bytes`);
                                break;
                            }
                        }
                    } catch (apiErr) {
                        console.log(`API échouée: ${apiUrl}`);
                        continue;
                    }
                }
                
            } catch (apiError) {
                console.error('Toutes les APIs ont échoué:', apiError);
            }
        }

        if (!audioBuffer || audioBuffer.length < 1000) {            await sendStyledMessage(sock, chatId, 
                `☀️ *IMPOSSIBLE DE RÉCUPÉRER L'AUDIO.* ☀️\n\n⚠️ *ESSAIE UNE AUTRE CHANSON, MORTEL.* ☀️`, 
                message, [], { ...channelContext, image: { url: getRandomImage() } }
            );
            return;
        }

        // 🎧 Envoi de l'audio
        const safeTitle = (video.title || 'audio')
            .replace(/[<>:"/\\|?*]+/g, '')
            .substring(0, 100);

        const successText = `☀️ *TÉLÉCHARGEMENT TERMINÉ, MORTEL !* ☀️\n\n🎵 *${safeTitle}*\n📦 *FORMAT:* MP3 Audio\n🔊 *QUALITÉ:* Haute qualité\n\n☀️ *PROFITE DE TA MUSIQUE. LE LION TE SALUE.* ☀️\n\n☀️ *© ᴹᴿ᭄𝐁𝐄𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐃』༒* ☀️`;

        await sock.sendMessage(chatId, {
            audio: audioBuffer,
            mimetype: "audio/mpeg",
            fileName: `${safeTitle}.mp3`,
            ptt: false,
            contextInfo: {
                ...channelContext.contextInfo,
                externalAdReply: {
                    title: "🎵 " + safeTitle.substring(0, 50),
                    body: "☀️ Téléchargé par ESCANOR PRIME ☀️",
                    thumbnailUrl: video.thumbnail,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    sourceUrl: "https://whatsapp.com/channel/0029Vb78ycrInlqYocbYLX0P"
                }
            }
        }, { quoted: message });

        // Message de confirmation
        await sendStyledMessage(sock, chatId, successText, message, [], channelContext);

    } catch (error) {
        console.error('☀️ ERREUR DANS LA COMMANDE PLAY:', error);
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DU TÉLÉCHARGEMENT.* ☀️\n\n⚠️ *MÊME LE LION PEUT AVOIR UN HOQUET. RÉESSAIE, MORTEL.* ☀️`, 
            message, [], { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

module.exports = playCommand;