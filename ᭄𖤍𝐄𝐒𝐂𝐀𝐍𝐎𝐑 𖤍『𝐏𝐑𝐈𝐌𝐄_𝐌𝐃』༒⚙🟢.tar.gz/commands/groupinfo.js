/**
 * ☀️ COMMANDE GROUPINFO – ESCANOR PRIME ☀️
 * Affiche les informations détaillées d'un groupe avec la majesté du Lion
 */

const sendStyledMessage = require('../utils/sendStyledMessage');

// ============================================================================
// 🎨 CONFIGURATION GLOBALE – BOUTON CHAÎNE + IMAGE FALLBACK
// ============================================================================
const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

const FALLBACK_IMAGE = 'https://i.imgur.com/2wzGhpF.jpeg';

// ============================================================================
// 🦁 COMMANDE GROUPINFO – VERSION PRINCIPALE
// ============================================================================
async function groupInfoCommand(sock, chatId, message) {
    try {
        // 🏰 Récupération des métadonnées du groupe
        const groupMetadata = await sock.groupMetadata(chatId);
        
        // 🖼️ Photo de profil du groupe ou fallback
        let groupPic;
        try {
            groupPic = await sock.profilePictureUrl(chatId, 'image');
        } catch {
            groupPic = FALLBACK_IMAGE;
        }

        const participants = groupMetadata.participants || [];
        const groupAdmins = participants.filter(p => p.admin);
        const totalMembers = participants.length;
        const totalAdmins = groupAdmins.length;
        
        // 👑 Détermination du propriétaire
        const owner = groupMetadata.owner 
            || groupAdmins.find(p => p.admin === 'superadmin')?.id 
            || chatId.split('-')[0] + '@s.whatsapp.net';

        // 📝 Formatage de la liste des admins avec mentions
        const listAdmin = groupAdmins.map((v, i) => {
            const num = v.id.split('@')[0];
            return `${i + 1}. @${num}`;
        }).join('\n') || '⚠️ *AUCUN ADMIN DÉTECTÉ.* ☀️';

        // 🕐 Variables dynamiques
        const now = new Date();
        const currentTime = now.toLocaleTimeString('fr-FR', { timeZone: 'Africa/Douala' });
        const currentDate = now.toLocaleDateString('fr-FR', { timeZone: 'Africa/Douala' });
        const groupName = groupMetadata.subject?.toUpperCase() || 'DOMAINE INCONNU';
        const groupDesc = groupMetadata.desc?.toString() || 'AUCUNE DESCRIPTION DÉFINIE.';

        // 📜 Message style Escanor – 100% MAJUSCULE + GRAS
        const infoMessage = `☀️ *INFORMATIONS DU DOMAINE – LE LION VEILLE* ☀️\n\n🆔 *ID:* \`${groupMetadata.id}\`\n📛 *NOM:* ${groupName}\n👥 *MEMBRES:* ${totalMembers}\n👑 *PROPRIÉTAIRE:* @${owner.split('@')[0]}\n🛡️ *ADMINS:* ${totalAdmins}\n\n🛡️ *LISTE DES ÉLUS DU LION:*\n${listAdmin}\n\n📝 *DESCRIPTION:*\n_${groupDesc}_\n\n⏰ *HEURE:* ${currentTime}\n📅 *DATE:* ${currentDate}\n\n🔥 *CE DOMAINE EST SOUS LA PROTECTION DU LION. RESPECTEZ-LE.* 🔥\n\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;

        // 📦 Préparation du tableau de mentions : tous les admins + propriétaire
        const mentionList = [...groupAdmins.map(v => v.id), owner];

        // 📤 Envoi avec sendStyledMessage + mentions cliquables + bouton chaîne + image
        await sendStyledMessage(
            sock, 
            chatId, 
            infoMessage, 
            message, 
            mentionList, // 👈 JIDs complets pour mentions cliquables
            { ...channelContext, image: { url: groupPic } }
        );
        
    } catch (error) {
        console.error('☀️ ERREUR DANS LA COMMANDE GROUPINFO:', error);
        
        // 📜 Message d'erreur style Escanor
        const errorMessage = `☀️ *ÉCHEC DE LA RÉCUPÉRATION DES INFOS.* ☀️\n\n⚠️ *LE LION RENCONTRE UN OBSTACLE. VÉRIFIE QUE TU ES DANS UN GROUPE ET RÉESSAIE.* ☀️`;
        
        await sendStyledMessage(
            sock, 
            chatId, 
            errorMessage, 
            message, 
            [], 
            { ...channelContext, image: { url: FALLBACK_IMAGE } }
        );
    }
}

module.exports = groupInfoCommand;