const fs = require('fs');
const path = require('path');

const warningsFilePath = path.join(__dirname, '../data/warnings.json');

function loadWarnings() {
    if (!fs.existsSync(warningsFilePath)) {
        fs.writeFileSync(warningsFilePath, JSON.stringify({}), 'utf8');
    }
    const data = fs.readFileSync(warningsFilePath, 'utf8');
    return JSON.parse(data);
}

async function warningsCommand(sock, chatId, mentionedJidList) {
    const warnings = loadWarnings();

    if (mentionedJidList.length === 0) {
        await sock.sendMessage(chatId, { text: '☀️ *MENTIONNE LE MORTEL DONT TU VEUX VOIR LES AVERTISSEMENTS.* ☀️' });
        return;
    }

    const userToCheck = mentionedJidList[0];
    const warningCount = warnings[userToCheck] || 0;

    await sock.sendMessage(chatId, { text: `☀️ *AVERTISSEMENTS* ☀️\n\n@${userToCheck.split('@')[0]} a ${warningCount} avertissement${warningCount > 1 ? 's' : ''}.` });
}

module.exports = warningsCommand;