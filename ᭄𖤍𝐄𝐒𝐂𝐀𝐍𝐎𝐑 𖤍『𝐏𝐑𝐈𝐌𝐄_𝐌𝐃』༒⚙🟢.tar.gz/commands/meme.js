const fetch = require('node-fetch');

async function memeCommand(sock, chatId, message) {
    try {
        const response = await fetch('https://shizoapi.onrender.com/api/memes/cheems?apikey=shizo');
        
        // Check if response is an image
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('image')) {
            const imageBuffer = await response.buffer();
            
            const buttons = [
                { buttonId: '.meme', buttonText: { displayText: '🎭 Encore un Meme' }, type: 1 },
                { buttonId: '.joke', buttonText: { displayText: '😄 Blague' }, type: 1 }
            ];

            await sock.sendMessage(chatId, { 
                image: imageBuffer,
                caption: "☀️ *MEME DU LION* ☀️\nVoici ton cheems meme, mortel. 🐕",
                buttons: buttons,
                headerType: 1
            },{ quoted: message});
        } else {
            throw new Error('Invalid response type from API');
        }
    } catch (error) {
        console.error('☀️ Erreur dans la commande meme:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION DU MEME.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.'
        },{ quoted: message });
    }
}

module.exports = memeCommand;