const os = require('os');
const fs = require('fs');
const settings = require('../settings.js');

const NEWSLETTER_JID = "120363423626898675@newsletter"; 
const IMAGE_PATH = "./assets/ping.jpg";

function formatTime(seconds) {
    const days = Math.floor(seconds / (24 * 60 * 60));
    seconds = seconds % (24 * 60 * 60);
    const hours = Math.floor(seconds / (60 * 60));
    seconds = seconds % (60 * 60);
    const minutes = Math.floor(seconds / 60);
    seconds = Math.floor(seconds % 60);

    let time = '';
    if (days > 0) time += `${days}d `;
    if (hours > 0) time += `${hours}h `;
    if (minutes > 0) time += `${minutes}m `;
    if (seconds > 0 || time === '') time += `${seconds}s`;

    return time.trim();
}

async function pingCommand(sock, chatId, message) {
    try {
        const start = Date.now();
        await sock.sendMessage(chatId, { text: '☀️ *PONG !* ☀️' }, { quoted: message });
        const end = Date.now();
        const ping = Math.round((end - start) / 2);

        const uptimeInSeconds = process.uptime();
        const uptimeFormatted = formatTime(uptimeInSeconds);

        const botInfo = `
☀️ * ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ – LE LION DE L'ORGUEIL* ☀️

🦁 *Nom:*  ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒
⚡ *Latence:* ${ping} ms
⏱️ *Uptime:* ${uptimeFormatted}
📌 *Version:* v${settings.version}

👑 *Maître:* ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒
📢 *Chaîne:* https://whatsapp.com/channel/0029Vb78ycrInlqYocbYLX0P

☀️ *"Qui ose me défier ?"* ☀️`.trim();

        await sock.sendMessage(chatId, {
            image: fs.readFileSync(IMAGE_PATH),
            caption: botInfo,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: NEWSLETTER_JID,
                    newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
                    serverMessageId: 1
                }
            }
        }, { quoted: message });

    } catch (error) {
        console.error('☀️ Erreur dans la commande ping:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️' });
    }
}

module.exports = pingCommand;