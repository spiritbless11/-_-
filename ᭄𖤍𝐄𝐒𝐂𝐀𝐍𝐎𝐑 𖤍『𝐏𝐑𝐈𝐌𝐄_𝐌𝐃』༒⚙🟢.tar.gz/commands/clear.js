const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ಢྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function clearCommand(sock, chatId) {
    try {
        const message = await sock.sendMessage(chatId, { 
            text: '☀️ *LE LION NETTOIE SA TANIERE...* ☀️',
            ...channelInfo
        });

        const messageKey = message.key;
        
        await sock.sendMessage(chatId, { delete: messageKey });
        
    } catch (error) {
        console.error('☀️ Erreur lors du nettoyage:', error);

        await sock.sendMessage(chatId, { 
            text: '☀️ *ECHEC DU NETTOYAGE.* ☀️\nLe Lion a vacille... Reessaie, mortel.',
            ...channelInfo
        });
    }
}

module.exports = { clearCommand };