const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');

const USER_GROUP_DATA = path.join(__dirname, '../data/userGroupData.json');

// NEWSLETTER CONFIG (FIXE)
const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ಢྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

// Mémoire
const chatMemory = {
    messages: new Map(),
    userInfo: new Map()
};

function loadUserGroupData() {
    try {
        return JSON.parse(fs.readFileSync(USER_GROUP_DATA));
    } catch {
        return { groups: [], chatbot: {} };
    }
}

function saveUserGroupData(data) {
    try {
        fs.writeFileSync(USER_GROUP_DATA, JSON.stringify(data, null, 2));
    } catch {}
}

function getRandomDelay() {
    return Math.floor(Math.random() * 3000) + 2000;
}

async function showTyping(sock, chatId) {
    try {
        await sock.presenceSubscribe(chatId);
        await sock.sendPresenceUpdate('composing', chatId);
        await new Promise(r => setTimeout(r, getRandomDelay()));
    } catch {}
}

function extractUserInfo(message) {
    const info = {};

    if (message.toLowerCase().includes('my name is')) {
        info.name = message.split('my name is')[1].trim().split(' ')[0];
    }

    if (message.toLowerCase().includes('i am') && message.toLowerCase().includes('years old')) {
        info.age = message.match(/\d+/)?.[0];
    }

    if (message.toLowerCase().includes('i live in') || message.toLowerCase().includes('i am from')) {
        info.location = message.split(/(?:i live in|i am from)/i)[1].trim().split(/[.,!?]/)[0];
    }

    return info;
}

async function handleChatbotCommand(sock, chatId, message, match) {

    if (!match) {
        await showTyping(sock, chatId);
        return sock.sendMessage(chatId, {
            text: `☀️ *CHATBOT - LE LION PARLE* ☀️

.chatbot on
Activer le chatbot

.chatbot off
Desactiver le chatbot`,
            ...channelInfo
        }, { quoted: message });
    }

    const data = loadUserGroupData();
    const botNumber = sock.user.id.split(':')[0] + '@s.whatsapp.net';
    const senderId = message.key.participant || message.key.remoteJid;
    const isOwner = senderId === botNumber;

    let isAdmin = false;

    if (chatId.endsWith('@g.us')) {
        try {
            const meta = await sock.groupMetadata(chatId);
            isAdmin = meta.participants.some(p => p.id === senderId && p.admin);
        } catch {}
    }

    if (!isOwner && !isAdmin) {
        await showTyping(sock, chatId);
        return sock.sendMessage(chatId, {
            text: '☀️ *SEUL UN ADMIN PEUT COMMANDER LE LION.* ☀️',
            ...channelInfo
        }, { quoted: message });
    }

    if (match === 'on') {
        await showTyping(sock, chatId);

        if (data.chatbot[chatId]) {
            return sock.sendMessage(chatId, {
                text: '☀️ *DEJA ACTIF.* ☀️',
                ...channelInfo
            }, { quoted: message });
        }

        data.chatbot[chatId] = true;
        saveUserGroupData(data);

        return sock.sendMessage(chatId, {
            text: '☀️ *CHATBOT ACTIVE.* ☀️\nLe Lion est pret.',
            ...channelInfo
        }, { quoted: message });
    }

    if (match === 'off') {
        await showTyping(sock, chatId);

        if (!data.chatbot[chatId]) {
            return sock.sendMessage(chatId, {
                text: '☀️ *DEJA DESACTIVE.* ☀️',
                ...channelInfo
            }, { quoted: message });
        }

        delete data.chatbot[chatId];
        saveUserGroupData(data);

        return sock.sendMessage(chatId, {
            text: '☀️ *CHATBOT DESACTIVE.* ☀️',
            ...channelInfo
        }, { quoted: message });
    }

    await showTyping(sock, chatId);

    return sock.sendMessage(chatId, {
        text: '☀️ *COMMANDE INVALIDE.* ☀️',
        ...channelInfo
    }, { quoted: message });
}

async function handleChatbotResponse(sock, chatId, message, userMessage, senderId) {
    const data = loadUserGroupData();
    if (!data.chatbot[chatId]) return;

    try {
        const botNumber = sock.user.id.split(':')[0];

        let isMentioned = userMessage.includes(`@${botNumber}`);
        let isReply = message.message?.extendedTextMessage?.contextInfo?.participant === sock.user.id;

        if (!isMentioned && !isReply) return;

        if (!chatMemory.messages.has(senderId)) {
            chatMemory.messages.set(senderId, []);
            chatMemory.userInfo.set(senderId, {});
        }

        const userInfo = extractUserInfo(userMessage);
        if (Object.keys(userInfo).length > 0) {
            chatMemory.userInfo.set(senderId, {
                ...chatMemory.userInfo.get(senderId),
                ...userInfo
            });
        }

        const messages = chatMemory.messages.get(senderId);
        messages.push(userMessage);
        if (messages.length > 20) messages.shift();

        await showTyping(sock, chatId);

        const ai = await getAIResponse(userMessage);

        if (!ai) return;

        await new Promise(r => setTimeout(r, getRandomDelay()));

        await sock.sendMessage(chatId, {
            text: ai,
            ...channelInfo
        }, { quoted: message });

    } catch {}
}

async function getAIResponse(msg) {
    try {
        const res = await fetch("https://zellapi.autos/ai/chatbot?text=" + encodeURIComponent(msg));
        const data = await res.json();
        return data.result || null;
    } catch {
        return null;
    }
}

module.exports = {
    handleChatbotCommand,
    handleChatbotResponse
};