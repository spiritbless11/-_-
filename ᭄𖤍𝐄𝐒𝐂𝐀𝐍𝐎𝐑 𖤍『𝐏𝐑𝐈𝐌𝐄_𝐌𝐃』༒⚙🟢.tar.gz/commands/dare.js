const fetch = require('node-fetch');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '༄ྀ 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function dareCommand(sock, chatId, message) {
    try {
        const shizokeys = 'shizo';
        const res = await fetch(`https://shizoapi.onrender.com/api/texts/dare?apikey=${shizokeys}`);
        
        if (!res.ok) {
            throw await res.text();
        }
        
        const json = await res.json();
        const dareMessage = json.result;

        // Send the dare message
        await sock.sendMessage(chatId, { 
            text: `☀️ *DÉFI DU LION* ☀️\n\n${dareMessage}`,
            ...channelInfo
        }, { quoted: message });

    } catch (error) {
        console.error('☀️ Erreur dans la commande dare:', error);

        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DU DÉFI.* ☀️\nMême le Lion peut trébucher. Réessaie, mortel.',
            ...channelInfo
        }, { quoted: message });
    }
}

module.exports = { dareCommand };