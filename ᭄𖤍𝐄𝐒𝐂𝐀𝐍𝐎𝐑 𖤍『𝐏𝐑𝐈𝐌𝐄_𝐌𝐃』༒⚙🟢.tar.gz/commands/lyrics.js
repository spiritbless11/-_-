const fetch = require('node-fetch');

async function lyricsCommand(sock, chatId, songTitle, message) {
    if (!songTitle) {
        await sock.sendMessage(chatId, { 
            text: '☀️ *DONNE-MOI LE NOM D\'UNE CHANSON, MORTEL.* ☀️\nUtilisation: .lyrics <nom de la chanson>'
        },{ quoted: message });
        return;
    }

    try {
        // Use lyricsapi.fly.dev and return only the raw lyrics text
        const apiUrl = `https://lyricsapi.fly.dev/api/lyrics?q=${encodeURIComponent(songTitle)}`;
        const res = await fetch(apiUrl);
        
        if (!res.ok) {
            const errText = await res.text();
            throw errText;
        }
        
        const data = await res.json();

        const lyrics = data && data.result && data.result.lyrics ? data.result.lyrics : null;
        if (!lyrics) {
            await sock.sendMessage(chatId, {
                text: `☀️ *LE LION N'A PAS TROUVÉ DE PAROLES POUR "${songTitle}".* ☀️`
            },{ quoted: message });
            return;
        }

        const maxChars = 4096;
        const output = lyrics.length > maxChars ? lyrics.slice(0, maxChars - 3) + '...' : lyrics;

        await sock.sendMessage(chatId, { text: `☀️ *PAROLES DE "${songTitle}"* ☀️\n\n${output}` }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans la commande lyrics:', error);
        await sock.sendMessage(chatId, { 
            text: `☀️ *UNE ERREUR S'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.`
        },{ quoted: message });
    }
}

module.exports = { lyricsCommand };