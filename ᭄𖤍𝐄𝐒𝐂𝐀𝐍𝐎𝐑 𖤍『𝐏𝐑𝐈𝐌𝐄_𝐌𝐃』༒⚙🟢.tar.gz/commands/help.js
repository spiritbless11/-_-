const settings = require('../settings');
const fs = require('fs');
const path = require('path');

const channelButton = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function helpCommand(sock, chatId, message) {
    let currentMode = "PUBLIC";
    try {
        const data = JSON.parse(fs.readFileSync('./data/messageCount.json'));
        if (typeof data.isPublic === 'boolean') {
            currentMode = data.isPublic ? "PUBLIC" : "PRIVE";
        }
    } catch {}

    const helpMessage = `
┏━〔 ☀️  ᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ ☀️ 〕━━━━━┓
┃ 👑 MAÎTRE : ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒
┃ ⚡ VERSION : 1.0.0
┃ 🔥 MODE : ${currentMode}
┃ 📦 COMMANDES : +130
┃ 🔖 PRÉFIXE : .
┃ 📞 OWNER : +243832881281
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 🔥 MENU PRINCIPAL 🔥 〕━━━━━┓
┃ • .ALIVE 
┃ • .MENU 
┃ • .PING 
┃ • .RUNTIME 
┃ • .REPO 
┃ • .OWNER 
┃ • .PAIR 
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 👑 COMMANDES OWNER 👑 〕━━━━━┓
┃ • .MODE 
┃ • .AUTOREAD
┃ • .AUTOTYPING 
┃ • .AUTOSTATUS
┃ • .ANTIDELETE
┃ • .ANTICALL
┃ • .PMBLOCKER
┃ • .AREACT
┃ • .CLEARTMP
┃ • .CLEARSESSION 
┃ • .SETPP
┃ • .SUDO
┃ • .UPDATE
┃ • .SETTINGS
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 👥 GESTION DE GROUPES 👥 〕━━━┓
┃ • .PROMOTE
┃ • .DEMOTE
┃ • .KICK
┃ • .ADD
┃ • .MUTE
┃ • .UNMUTE
┃ • .TAGALL
┃ • .HIDETAG
┃ • .TAGNOTADMIN
┃ • .SETGDESC
┃ • .SETGNAME
┃ • .SETGPP
┃ • .RESETLINK
┃ • .GROUPINFO
┃ • .STAFF
┃ • .PURGE
┃ • .DELETE
┃ • .CLEAR
┃ • .JID
┃ • .ANNONCE
┃ • .ANTISPAM
┃ • .ANTIDEMOTE
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 🛡️ MODÉRATION 🛡️ 〕━━━━━━━━┓
┃ • .ANTILINK
┃ • .ANTITAG
┃ • .ANTIBADWORD
┃ • .WELCOME
┃ • .GOODBYE
┃ • .BAN
┃ • .UNBAN
┃ • .WARN
┃ • .WARNINGS
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 🤖 INTELLIGENCE ARTIFICIELLE 🤖 〕━━┓
┃ • .GPT
┃ • .GEMINI
┃ • .IMAGINE
┃ • .FLUX
┃ • .SORA
┃ • .CODEAI
┃ • .PHOTOAI
┃ • .STORYAI
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 🎨 STICKERS & EFFETS 🎨 〕━━━━┓
┃ • .STICKER
┃ • .TAKE
┃ • .CROP
┃ • .EMOJIMIX
┃ • .IGS
┃ • .TG
┃ • .ATTP
┃ • .SIMAGE
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 ✨ EFFETS DE TEXTE ✨ 〕━━━━━┓
┃ • .METALLIC 
┃ • .ICE 
┃ • .SNOW 
┃ • .IMPRESSIVE
┃ • .MATRIX 
┃ • .LIGHT 
┃ • .NEON 
┃ • .DEVIL
┃ • .PURPLE 
┃ • .THUNDER 
┃ • .LEAVES 
┃ • .1917
┃ • .ARENA 
┃ • .HACKER 
┃ • .SAND 
┃ • .BLACKPINK
┃ • .GLITCH 
┃ • .FIRE
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 📥 TÉLÉCHARGEMENTS 📥 〕━━━━━┓
┃ • .PLAY
┃ • .SONG
┃ • .VIDEO
┃ • .INSTAGRAM
┃ • .FACEBOOK
┃ • .TIKTOK
┃ • .SPOTIFY
┃ • .TOURL
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 🛠️ OUTILS 🛠️ 〕━━━━━━━━━━┓
┃ • .QRCODE
┃ • .SS
┃ • .TRANSLATE
┃ • .WEATHER
┃ • .NEWS
┃ • .LYRICS
┃ • .TTS
┃ • .REMOVEBG
┃ • .REMINI
┃ • .BLUR
┃ • .SHORTURL
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 🎮 JEUX 🎮 〕━━━━━━━━━━━┓
┃ • .TTT
┃ • .HANGMAN
┃ • .GUESS
┃ • .TRIVIA
┃ • .ANSWER
┃ • .SHIP
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 💬 FUN 💬 〕━━━━━━━━━━━━┓
┃ • .COMPLIMENT
┃ • .INSULT
┃ • .FLIRT
┃ • .JOKE
┃ • .MEME
┃ • .QUOTE
┃ • .FACT
┃ • .DARE
┃ • .TRUTH
┃ • .8BALL
┃ • .CHARACTER
┃ • .WASTED
┃ • .SIMP
┃ • .STUPID
┃ • .GOODNIGHT
┃ • .SHAYARI
┃ • .ROSEDAY
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┏━━〔 👁️ AUTRES 👁️ 〕━━━━━━━━━━┓
┃ • .VV
┃ • .VIEWONCE
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
> ☀️ "JE SUIS CELUI QUI CE TIENS AU DESSUS DE TOUS."
> 🔥  ᭄𖤍𝐄𝐒𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ – LE LION DE L'ORGUEIL
> 💀 CODÉ PAR ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                ...channelButton
            });
        } else {
            console.error('☀️ IMAGE DU BOT NON TROUVÉE:', imagePath);
            await sock.sendMessage(chatId, { text: helpMessage, ...channelButton });
        }
    } catch (error) {
        console.error('☀️ ERREUR DANS LA COMMANDE HELP:', error);
        await sock.sendMessage(chatId, { text: helpMessage, ...channelButton });
    }
}

module.exports = helpCommand;