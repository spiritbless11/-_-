const { handleAntiBadwordCommand } = require('../lib/antibadword');
const isAdminHelper = require('../lib/isAdmin');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

// Liste complète des mots interdits (insultes, sexe, racisme, etc.)
const badWordsList = [
    // Insultes françaises
    'merde', 'con', 'connard', 'connasse', 'pute', 'putain', 'salope', 'enculé', 'enculée',
    'bâtard', 'bâtarde', 'fils de pute', 'fdp', 'ntm', 'tg', 'va te faire', 'vas te faire',
    'ferme ta gueule', 'ta gueule', 'gueule', 'chier', 'merdeux', 'merdeuse', 'caca',
    'pipi', 'cul', 'bite', 'queue', 'zizi', 'nique', 'niquer', 'baise', 'baiser',
    
    // Insultes en anglais
    'fuck', 'fucking', 'shit', 'bitch', 'bastard', 'asshole', 'dick', 'cock', 'pussy',
    'cunt', 'whore', 'slut', 'motherfucker', 'mothafucka', 'mf', 'wtf', 'stfu',
    'bullshit', 'goddamn', 'damn', 'hell', 'crap', 'screw you', 'suck', 'sucker',
    
    // Termes sexuels explicites
    'sexe', 'sperme', 'ejaculation', 'ejaculer', 'orgasme', 'fellation', 'sodomie',
    'porn', 'porno', 'xxx', 'nudes', 'sextape', 'coquin', 'coquine', 'culotte',
    'soutien-gorge', 'string', 'nu', 'nue', 'déshabillé', 'déshabiller',
    
    // Racisme et discrimination
    'negre', 'négro', 'bamboula', 'bougnoule', 'bicot', 'raton', 'youpin', 'youpins',
    'youpinaille', 'blaireau', 'facho', 'nazi', 'nazie', 'hitler', 'shoah', 'gros',
    
    // Violences
    'meurtre', 'tuer', 'assassin', 'violer', 'viol', 'massacre', 'sadique', 'torture',
    'sang', 'cadavre', 'cadavres', 'suicide', 'se suicider', 'pendre', 'decapitation',
    
    // Variantes et abréviations
    'fuckyou', 'fuk', 'fcker', 'fker', 'bch', 'biotch', 'biatch', 'a-hole', 'azz',
    'dck', 'd1ck', 'pssy', 'cnt', 'mdf', 'mfk', 'wtf', 'stf', 'stfu',
    
    // Termes d'acharnement
    'gros nul', 'nul', 'nulle', 'idiot', 'idiote', 'stupide', 'imbécile', 'crétin',
    'crétine', 'abruti', 'abrutie', 'demeuré', 'demeurée', 'attardé', 'attardée',
    
    // Harcèlement
    'tocard', 'tocarde', 'loser', 'raté', 'ratée', 'clochard', 'clocharde', 'sans abri',
    'pauvre type', 'pauvre con', 'pauvre merde', 'cas social', 'marginal', 'marginale'
];

async function antibadwordCommand(sock, chatId, message, senderId, isSenderAdmin) {
    try {
        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT GÉRER L\'ANTIBADWORD.* ☀️\nLe Lion n\'obéit qu\'à ceux qui ont le pouvoir.',
                ...channelInfo
            }, { quoted: message });
            return;
        }

        // Extract match from message
        const text = message.message?.conversation || 
                    message.message?.extendedTextMessage?.text || '';
        const match = text.split(' ').slice(1).join(' ');

        await handleAntiBadwordCommand(sock, chatId, message, match);
    } catch (error) {
        console.error('☀️ Erreur dans la commande antibadword:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            ...channelInfo
        }, { quoted: message });
    }
}

// Fonction de détection des mots interdits (à intégrer dans le handler principal)
async function detectBadWords(sock, chatId, message, userMessage, senderId) {
    // Vérifier si c'est un groupe
    if (!chatId.endsWith('@g.us')) return;
    
    // Vérifier si la configuration est activée
    const fs = require('fs');
    const path = require('path');
    const configPath = path.join(__dirname, '../data/antibadword.json');
    let config = { enabled: false, action: 'delete' };
    
    if (fs.existsSync(configPath)) {
        config = JSON.parse(fs.readFileSync(configPath));
    }
    
    if (!config.enabled) return;
    
    // Nettoyer le message
    const cleanMessage = userMessage.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    
    let containsBadWord = false;
    let foundWord = '';
    
    for (const badWord of badWordsList) {
        if (cleanMessage.includes(badWord.toLowerCase())) {
            containsBadWord = true;
            foundWord = badWord;
            break;
        }
    }
    
    if (!containsBadWord) return;
    
    // Vérifier les permissions
    const { isBotAdmin, isSenderAdmin } = await isAdminHelper(sock, chatId, senderId);
    if (!isBotAdmin) return;
    if (isSenderAdmin) return;
    
    // Supprimer le message
    try {
        await sock.sendMessage(chatId, { delete: message.key });
    } catch (e) {}
    
    const action = config.action || 'delete';
    
    if (action === 'delete') {
        await sock.sendMessage(chatId, {
            text: `☀️ *MOT INTERDIT DÉTECTÉ* ☀️\n\n@${senderId.split('@')[0]}, le mot "${foundWord}" est interdit ici.\n\n🔥 *Le Lion veille sur la pureté de son antre.* 🔥`,
            mentions: [senderId],
            ...channelInfo
        });
    } else if (action === 'kick') {
        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
        await sock.sendMessage(chatId, {
            text: `☀️ *EXPULSION* ☀️\n\n@${senderId.split('@')[0]} a été expulsé pour avoir utilisé un mot interdit : "${foundWord}"`,
            mentions: [senderId],
            ...channelInfo
        });
    } else if (action === 'warn') {
        const warningsPath = path.join(__dirname, '../data/warnings.json');
        let warnings = {};
        if (fs.existsSync(warningsPath)) {
            warnings = JSON.parse(fs.readFileSync(warningsPath));
        }
        if (!warnings[chatId]) warnings[chatId] = {};
        if (!warnings[chatId][senderId]) warnings[chatId][senderId] = 0;
        warnings[chatId][senderId]++;
        
        if (warnings[chatId][senderId] >= 3) {
            await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
            delete warnings[chatId][senderId];
            await sock.sendMessage(chatId, {
                text: `☀️ *EXPULSION APRÈS 3 AVERTISSEMENTS* ☀️\n\n@${senderId.split('@')[0]} a été expulsé pour avoir utilisé des mots interdits.`,
                mentions: [senderId],
                ...channelInfo
            });
        } else {
            await sock.sendMessage(chatId, {
                text: `☀️ *AVERTISSEMENT ${warnings[chatId][senderId]}/3* ☀️\n\n@${senderId.split('@')[0]}, mot interdit détecté : "${foundWord}"`,
                mentions: [senderId],
                ...channelInfo
            });
        }
        fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));
    }
}

module.exports = { antibadwordCommand, detectBadWords, badWordsList };