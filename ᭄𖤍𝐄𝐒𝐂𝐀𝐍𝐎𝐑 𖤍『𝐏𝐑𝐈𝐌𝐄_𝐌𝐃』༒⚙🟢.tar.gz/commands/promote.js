const { isAdmin } = require('../lib/isAdmin');
const sendStyledMessage = require('../utils/sendStyledMessage');

const channelContext = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363423626898675@newsletter",
            newsletterName: "ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ",
            serverMessageId: -1
        }
    }
};

// ️ ANTI-DOUBLON FIABLE (Stocke JID + Timestamp)
const recentPromotions = new Map();

async function promoteCommand(sock, chatId, mentionedJids, message) {
    let userToPromote = [];
    
    if (mentionedJids && mentionedJids.length > 0) {
        userToPromote = mentionedJids.map(jid => 
            jid.includes('@') ? jid : `${jid}@s.whatsapp.net`
        );
    } else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToPromote = [message.message.extendedTextMessage.contextInfo.participant];
    }
    
    if (userToPromote.length === 0) {
        await sendStyledMessage(sock, chatId, 
            `☀️ *DÉSIGNE LE MORTEL À PROMOUVOIR.* ☀️\n\n⚡ *MENTIONNE-LE OU RÉPONDS À SON MESSAGE.* ☀️`, 
            message, [], channelContext
        );
        return;
    }

    try {
        // 🔒 Marquer comme traité AVANT l'exécution pour bloquer l'événement automatique
        const now = Date.now();
        userToPromote.forEach(jid => recentPromotions.set(jid.split('@')[0], now));

        await sock.groupParticipantsUpdate(chatId, userToPromote, "promote");
        
        const senderJid = message.key.participant || message.key.remoteJid;
        const senderNum = senderJid.split('@')[0];
        
        // ⚠️ FORMATAGE STRICT POUR WHATSAPP : @NUMÉRO (aucun espace, aucun +)
        const promotedTags = userToPromote.map(jid => `@${jid.split('@')[0]}`);
        const promotionMessage = `☀️ *PROMOTION – LE LION ÉLÈVE UN MORTEL* ☀️\n\n👤 *PROMU${userToPromote.length > 1 ? 'S' : ''}:*\n┃ ${promotedTags.join('\n┃ ')}\n\n👑 *PAR:* @${senderNum}\n\n📅 *DATE:* ${new Date().toLocaleString()}\n\n☀️ *LE POUVOIR DU SOLEIL REPOSE DÉSORMAIS SUR SES ÉPAULES.* ☀️\n☀️ *© ᴹᴿ᭄𖤍𝐁𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐂𝐊𝐃』༒* ☀️`;
        
        // 📦 Le 5ème argument DOIT contenir les JIDs complets pour que WhatsApp active le clic
        await sendStyledMessage(
            sock, 
            chatId, 
            promotionMessage, 
            message, 
            [...userToPromote, senderJid], 
            channelContext
        );
        
    } catch (error) {
        console.error('☀️ ERREUR PROMOTE:', error);
        await sendStyledMessage(sock, chatId, 
            `☀️ *ÉCHEC DE LA PROMOTION.* ☀️\n\n⚠️ *LE LION RENCONTRE UN OBSTACLE.* ☀️`, 
            message, [], channelContext
        );
    }
}

async function handlePromotionEvent(sock, groupId, participants, author) {
    try {
        if (!Array.isArray(participants) || participants.length === 0) return;

        // ️ VÉRIFICATION ANTI-DOUBLON (Fenêtre de 3 secondes)
        const now = Date.now();
        const isRecent = participants.some(p => {
            const pNum = (typeof p === 'string' ? p : (p.id || p.toString())).split('@')[0];
            const time = recentPromotions.get(pNum);
            return time && (now - time < 3000);
        });

        if (isRecent) {
            console.log('☀️ Promotion déjà annoncée par commande → Événement ignoré.');
            return; // 👈 C'EST ICI QUE LE DOUBLE MESSAGE EST TUÉ
        }

        const normalizedParticipants = participants.map(jid => {
            const jidString = typeof jid === 'string' ? jid : (jid.id || jid.toString());
            return jidString.includes('@') ? jidString : `${jidString}@s.whatsapp.net`;
        });

        const promotedTags = normalizedParticipants.map(jid => `@${jid.split('@')[0]}`);
        let promotedBy = 'SYSTÈME';
        let mentionList = [...normalizedParticipants];

        if (author && author.length > 0) {
            const authorJid = typeof author === 'string' ? author : (author.id || author.toString());
            const normAuthor = authorJid.includes('@') ? authorJid : `${authorJid}@s.whatsapp.net`;            promotedBy = `@${normAuthor.split('@')[0]}`;
            mentionList.push(normAuthor);
        }

        const promotionMessage = `☀️ *PROMOTION AUTOMATIQUE – LE LION VEILLE* ☀️\n\n👤 *PROMU${normalizedParticipants.length > 1 ? 'S' : ''}:*\n┃ ${promotedTags.join('\n┃ ')}\n\n👑 *PAR:* ${promotedBy}\n\n📅 *DATE:* ${new Date().toLocaleString()}\n\n☀️ *LE LION ACCORDE SA CONFIANCE. RESPECTEZ-LE.* ☀️\n☀️ *© ᴹᴿ᭄𖤍𝐋𝐄𝐒𝐒𝐃𝐄 𖤍『𝐒𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒* ☀️`;
        
        await sendStyledMessage(sock, groupId, promotionMessage, null, mentionList, channelContext);
        
    } catch (error) {
        console.error('☀️ ERREUR ÉVÉNEMENT PROMOTION:', error);
    }
}

module.exports = { promoteCommand, handlePromotionEvent };