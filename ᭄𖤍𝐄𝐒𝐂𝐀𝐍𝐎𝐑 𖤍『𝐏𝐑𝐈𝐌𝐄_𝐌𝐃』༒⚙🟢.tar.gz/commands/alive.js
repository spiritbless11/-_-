const fs = require('fs');
const path = require('path');
const settings = require("../settings");

// NEWSLETTER - La chaîne du Lion
const NEWSLETTER = {
    jid: '120363423626898675@newsletter',
    name: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ'   
};

// IMAGE DU BOT
const BOT_IMAGE = './assets/sticktag.webp';

// 🔹 DÉCOR MODIFIABLE - Le rugissement du Lion (police normale)
const DECOR = `
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ ☀️ *᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ EST ACTIF* ☀️
┃                               
┃ ⚔️ Version : ${settings.version}          
┃ ☀️ Statut  : Le Lion veille 🔥        
┃ 👑 Mode    : {mode} ⚔️     
┃                               
┃ 🔥 *Fonctionnalités du Lion* :          
┃ • ⚔️ Gestion des groupes    
┃ • 🛡️ Protection anti-liens   
┃ • ☀️ Commandes puissantes     
┃ • 🔥 Et bien plus encore ✨           
┃                               
┃ ☀️ *ÉCOUTE, MORTEL.* ☀️
┃ Tu viens de réveiller le Lion.
┃ Puissance absolue, fierté sans limite.
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛
> ☀️ powered by ᴹᴿ᭄𖤍𝐁𝐋𝐄𝐒𝐒𝐃𝐄𝐕 𖤍『𝐒𝐘𝐒_𝐇𝐀𝐂𝐊𝐄𝐃』༒ ☀️
`;

async function aliveCommand(sock, chatId, message) {
    // Lire le mode réel du bot
    let currentMode = "PUBLIC";
    try {
        const data = JSON.parse(fs.readFileSync('./data/messageCount.json'));
        if (typeof data.isPublic === 'boolean') {
            currentMode = data.isPublic ? "PUBLIC" : "PRIVE";
        }
    } catch (error) {}

    // Remplacer {mode} par la valeur réelle
    const finalDecor = DECOR.replace('{mode}', currentMode);

    try {
        await sock.sendMessage(chatId, {
            image: fs.readFileSync(BOT_IMAGE),
            caption: finalDecor,
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: NEWSLETTER.jid,
                    newsletterName: NEWSLETTER.name,
                    serverMessageId: 1
                }
            }
        }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans la commande alive:', error);
        await sock.sendMessage(chatId, { text: '☀️ *᭄𖤍𝐄𝐒𝐂𝐀𝐍𝐎𝐑 𖤍『𝐏𝐑𝐈𝐌𝐄_𝐌𝐃』༒ EST VIVANT !* ☀️' }, { quoted: message });
    }
}

module.exports = aliveCommand;