const fetch = require('node-fetch');

async function shayariCommand(sock, chatId, message) {
    try {
        const response = await fetch('https://shizoapi.onrender.com/api/texts/shayari?apikey=shizo');
        const data = await response.json();
        
        if (!data || !data.result) {
            throw new Error('Invalid response from API');
        }

        const buttons = [
            { buttonId: '.shayari', buttonText: { displayText: '🎭 Shayari' }, type: 1 },
            { buttonId: '.roseday', buttonText: { displayText: '🌹 RoseDay' }, type: 1 }
        ];

        await sock.sendMessage(chatId, { 
            text: `☀️ *SHAYARI DU LION* ☀️\n\n${data.result}`,
            buttons: buttons,
            headerType: 1
        }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur dans shayari:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
        }, { quoted: message });
    }
}

module.exports = { shayariCommand };