const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '༄ྀ 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

const eightBallResponses = [
    "☀️ *OUI, C'EST ABSOLUMENT CERTAIN.* ☀️",
    "🔥 *NON, MORTEL. TU TE TROMPES.* 🔥",
    "☀️ *REPOSE TA QUESTION PLUS TARD.* ☀️",
    "⚔️ *C'EST ÉVIDENT. OUI.* ⚔️",
    "☀️ *TRÈS DOUTEUX. PRESQUE IMPOSSIBLE.* ☀️",
    "🔥 *SANS AUCUN DOUTE.* 🔥",
    "☀️ *MA RÉPONSE EST NON. ACCEPTE-LE.* ☀️",
    "⚔️ *LES SIGNES POINTENT VERS OUI.* ⚔️"
];

async function eightBallCommand(sock, chatId, question) {
    if (!question) {
        await sock.sendMessage(chatId, { 
            text: '☀️ *POSE TA QUESTION, MORTEL.* ☀️',
            ...channelInfo
        });
        return;
    }

    const randomResponse = eightBallResponses[Math.floor(Math.random() * eightBallResponses.length)];

    await sock.sendMessage(chatId, { 
        text: `☀️ ${randomResponse}`,
        ...channelInfo
    });
}

module.exports = { eightBallCommand };