const fs = require('fs');
const path = require('path');
const isAdmin = require('../lib/isAdmin');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function handleAntidemoteCommand(sock, chatId, message, senderId, isSenderAdmin, args) {
    try {
        // Vérifier si l'utilisateur est admin ou propriétaire
        let adminStatus = isSenderAdmin;
        if (!adminStatus && !message.key.fromMe) {
            const adminCheck = await isAdmin(sock, chatId, senderId);
            adminStatus = adminCheck.isSenderAdmin;
        }

        const isOwner = senderId === '243832881281@s.whatsapp.net' || 
                        senderId === '243832881281' || 
                        senderId.includes('243832881281');

        if (!adminStatus && !message.key.fromMe && !isOwner) {
            return sock.sendMessage(chatId, {
                text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT GÉRER L\'ANTIDEMOTE.* ☀️\nLe Lion n\'obéit qu\'à ceux qui ont le pouvoir.',
                ...channelInfo
            }, { quoted: message });
        }

        const action = args[0]?.toLowerCase();
        const configPath = path.join(__dirname, '../data/antidemote.json');
        let config = { enabled: false };

        if (fs.existsSync(configPath)) {
            config = JSON.parse(fs.readFileSync(configPath));
        }

        if (!action) {
            return sock.sendMessage(chatId, {
                text: `☀️ *ANTIDEMOTE – PROTECTION DES ADMINS* ☀️\n\nStatut: ${config.enabled ? 'ACTIVÉ' : 'DÉSACTIVÉ'}\n\nCommandes:\n.antidemote on → Activer\n.antidemote off → Désactiver`,
                ...channelInfo
            }, { quoted: message });
        }

        if (action === 'on') {
            config.enabled = true;
            fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
            return sock.sendMessage(chatId, { text: '☀️ *ANTIDEMOTE ACTIVÉ* ☀️\nPlus personne ne pourra rétrograder les administrateurs.', ...channelInfo }, { quoted: message });
        }

        if (action === 'off') {
            config.enabled = false;
            fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
            return sock.sendMessage(chatId, { text: '☀️ *ANTIDEMOTE DÉSACTIVÉ* ☀️\nLe Lion baisse sa garde...', ...channelInfo }, { quoted: message });
        }

        return sock.sendMessage(chatId, { text: '☀️ *COMMANDE INVALIDE* ☀️\nUtilise .antidemote on/off', ...channelInfo }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur antidemote command:', error);
        await sock.sendMessage(chatId, { text: '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️', ...channelInfo }, { quoted: message });
    }
}

// Détection d'une tentative de demote sur un admin
async function handleDemoteProtection(sock, chatId, message, targetUser, senderId) {
    // Vérifier si c'est un groupe
    if (!chatId.endsWith('@g.us')) return;

    const configPath = path.join(__dirname, '../data/antidemote.json');
    if (!fs.existsSync(configPath)) return;
    
    const config = JSON.parse(fs.readFileSync(configPath));
    if (!config.enabled) return;

    // Vérifier si le bot est admin
    const { isBotAdmin } = await isAdmin(sock, chatId, senderId);
    if (!isBotAdmin) return;

    // Vérifier si la cible est un administrateur
    const groupMetadata = await sock.groupMetadata(chatId);
    const targetParticipant = groupMetadata.participants.find(p => p.id === targetUser);
    
    if (!targetParticipant || !targetParticipant.admin) return;

    // Vérifier si l'expéditeur est le propriétaire
    const isOwner = senderId === '243832881281@s.whatsapp.net' || 
                    senderId === '243832881281' || 
                    senderId.includes('243832881281');

    // Le propriétaire peut toujours demote
    if (isOwner) return;

    // Tentative de demote sur un admin détectée
    try {
        // Supprimer le message de la commande
        await sock.sendMessage(chatId, { delete: message.key });
    } catch (e) {}

    // Avertir l'utilisateur
    await sock.sendMessage(chatId, {
        text: `☀️ *TENTATIVE DE RÉTROGRADATION BLOQUÉE* ☀️\n\n@${senderId.split('@')[0]} a essayé de rétrograder @${targetUser.split('@')[0]}, mais @${targetUser.split('@')[0]} est administrateur.\n\n🔥 *Le Lion protège ses guerriers.* 🔥\n\n*"Personne ne touche à mes administrateurs, sauf mon maître."* ☀️`,
        mentions: [senderId, targetUser],
        ...channelInfo
    });

    // Si l'utilisateur n'est pas admin, le kicker (optionnel)
    const { isSenderAdmin } = await isAdmin(sock, chatId, senderId);
    if (!isSenderAdmin) {
        try {
            await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
            await sock.sendMessage(chatId, {
                text: `☀️ *EXPULSION* ☀️\n@${senderId.split('@')[0]} a été expulsé pour avoir tenté de rétrograder un administrateur.`,
                mentions: [senderId],
                ...channelInfo
            });
        } catch (e) {}
    }

    return true; // Indique que la tentative a été bloquée
}

module.exports = { handleAntidemoteCommand, handleDemoteProtection };