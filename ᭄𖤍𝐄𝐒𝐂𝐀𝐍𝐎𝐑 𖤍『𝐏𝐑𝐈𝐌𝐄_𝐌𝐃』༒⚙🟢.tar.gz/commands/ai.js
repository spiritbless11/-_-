const axios = require('axios');
const fetch = require('node-fetch');
const sendStyledMessage = require('../utils/sendStyledMessage');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function aiCommand(sock, chatId, message) {
    try {
        const text = message.message?.conversation || message.message?.extendedTextMessage?.text;
        
        if (!text) {
            return await sendStyledMessage(sock, chatId,
                "☀️ *TU OSES ME PARLER SANS QUESTION, MORTEL ?* ☀️\n\nDonne-moi ta requête après .gpt ou .gemini\n\nExemple : .gpt écris un code HTML basique",
                message
            );
        }

        const parts = text.split(' ');
        const command = parts[0].toLowerCase();
        const query = parts.slice(1).join(' ').trim();

        if (!query) {
            return await sendStyledMessage(sock, chatId,
                "☀️ *JE N'ENTENDS PAS LE VIDE.* ☀️\nPose ta question après .gpt ou .gemini, si tu oses.",
                message
            );
        }

        try {
            await sock.sendMessage(chatId, {
                react: { text: '☀️', key: message.key }
            });

            if (command === '.gpt') {
                const apis = [
                    `https://api.ryzendesu.vip/api/ai/gpt4?text=${encodeURIComponent(query)}`,
                    `https://api.siputzx.my.id/api/ai/gpt4?text=${encodeURIComponent(query)}`,
                    `https://api.agatz.xyz/api/gpt?text=${encodeURIComponent(query)}`
                ];

                let answer = null;
                for (const api of apis) {
                    try {
                        const response = await axios.get(api, { timeout: 15000 });
                        if (response.data && (response.data.result || response.data.response || response.data.answer || response.data.message)) {
                            answer = response.data.result || response.data.response || response.data.answer || response.data.message;
                            break;
                        }
                    } catch (e) {
                        continue;
                    }
                }

                if (!answer) throw new Error('Toutes les APIs GPT ont échoué');

                await sendStyledMessage(sock, chatId, answer, message);
                
            } else if (command === '.gemini') {
                const apis = [
                    `https://api.ryzendesu.vip/api/ai/gemini?text=${encodeURIComponent(query)}`,
                    `https://api.siputzx.my.id/api/ai/gemini?text=${encodeURIComponent(query)}`,
                    `https://vapis.my.id/api/gemini?q=${encodeURIComponent(query)}`
                ];

                let answer = null;
                for (const api of apis) {
                    try {
                        const response = await axios.get(api, { timeout: 15000 });
                        if (response.data && (response.data.result || response.data.response || response.data.answer || response.data.message || response.data.data)) {
                            answer = response.data.result || response.data.response || response.data.answer || response.data.message || response.data.data;
                            break;
                        }
                    } catch (e) {
                        continue;
                    }
                }

                if (!answer) throw new Error('Toutes les APIs Gemini ont échoué');

                await sendStyledMessage(sock, chatId, answer, message);
            }

        } catch (error) {
            console.error('API Error:', error);
            await sendStyledMessage(sock, chatId,
                "☀️ *LES DIEUX ONT REFUSÉ DE RÉPONDRE.* ☀️\nRéessaie plus tard, mortel. Même le Lion doit parfois attendre.",
                message
            );
        }

    } catch (error) {
        console.error('AI Command Error:', error);
        await sendStyledMessage(sock, chatId,
            "☀️ *UNE FORCE M'A RÉSISTÉ.* ☀️\nRéessaie, si ton cœur est assez vaillant.",
            message
        );
    }
}

module.exports = aiCommand;