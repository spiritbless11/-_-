const { bots } = require('../lib/antilink');
const { setAntilink, getAntilink, removeAntilink } = require('../lib/index');
const isAdmin = require('../lib/isAdmin');
const sendStyledMessage = require('../utils/sendStyledMessage');

async function handleAntilinkCommand(sock, chatId, userMessage, senderId, isSenderAdmin, message) {
    try {
        if (!isSenderAdmin) {
            await sendStyledMessage(
                sock,
                chatId,
                '☀️ *SEULS LES ADMINISTRATEURS PEUVENT GÉRER L\'ANTILINK.* ☀️\nLe Lion n\'obéit qu\'à ceux qui ont le pouvoir.',
                message
            );
            return;
        }

        const prefix = '.';
        const args = userMessage.slice(9).toLowerCase().trim().split(' ');
        const action = args[0];

        if (!action) {
            const usage = `☀️ *ANTILINK – LA PROTECTION DU LION* ☀️\n\n${prefix}antilink on\n${prefix}antilink set delete | kick | warn\n${prefix}antilink off\n\n*Commande réservée aux administrateurs.*`;
            await sendStyledMessage(sock, chatId, usage, message);
            return;
        }

        switch (action) {
            case 'on':
                const existingConfig = await getAntilink(chatId, 'on');
                if (existingConfig?.enabled) {
                    await sendStyledMessage(sock, chatId, '☀️ *L\'ANTILINK EST DÉJÀ ACTIF.* ☀️', message);
                    return;
                }
                const result = await setAntilink(chatId, 'on', 'delete');
                await sendStyledMessage(
                    sock,
                    chatId,
                    result 
                        ? '☀️ *L\'ANTILINK EST MAINTENANT ACTIF.* ☀️\nQue les liens interdits tremblent.' 
                        : '☀️ *ÉCHEC DE L\'ACTIVATION DE L\'ANTILINK.* ☀️',
                    message
                );
                break;

            case 'off':
                await removeAntilink(chatId, 'on');
                await sendStyledMessage(
                    sock,
                    chatId,
                    '☀️ *L\'ANTILINK EST MAINTENANT DÉSACTIVÉ.* ☀️\nLe Lion baisse sa garde... pour l\'instant.',
                    message
                );
                break;

            case 'set':
                if (args.length < 2) {
                    await sendStyledMessage(
                        sock,
                        chatId,
                        `☀️ *COMMANDE INCOMPLÈTE* ☀️\nUtilisation: ${prefix}antilink set delete | kick | warn`,
                        message
                    );
                    return;
                }

                const setAction = args[1];
                if (!['delete', 'kick', 'warn'].includes(setAction)) {
                    await sendStyledMessage(
                        sock,
                        chatId,
                        '☀️ *ACTION INVALIDE.* ☀️\nChoisis: delete, kick, ou warn.',
                        message
                    );
                    return;
                }

                const setResult = await setAntilink(chatId, 'on', setAction);
                await sendStyledMessage(
                    sock,
                    chatId,
                    setResult 
                        ? `☀️ *ACTION ANTILINK DÉFINIE SUR : ${setAction.toUpperCase()}* ☀️` 
                        : '☀️ *ÉCHEC DE LA CONFIGURATION.* ☀️',
                    message
                );
                break;

            case 'get':
                const status = await getAntilink(chatId, 'on');
                await sendStyledMessage(
                    sock,
                    chatId,
                    `☀️ *CONFIGURATION ANTILINK* ☀️\n\nStatut: ${status ? 'ACTIF' : 'INACTIF'}\nAction: ${status ? status.action : 'Non définie'}`,
                    message
                );
                break;

            default:
                await sendStyledMessage(
                    sock,
                    chatId,
                    `☀️ *Utilise ${prefix}antilink pour voir les options.* ☀️`,
                    message
                );
        }
    } catch (error) {
        console.error('☀️ Erreur dans la commande antilink:', error);
        await sendStyledMessage(
            sock,
            chatId,
            '☀️ *UNE ERREUR S\'EST PRODUITE.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            message
        );
    }
}

async function handleLinkDetection(sock, chatId, message, userMessage, senderId) {
    if (!chatId.endsWith('@g.us')) return;

    const antilinkConfig = await getAntilink(chatId, 'on');
    if (!antilinkConfig || !antilinkConfig.enabled) return;

    const { isBotAdmin, isSenderAdmin } = await isAdmin(sock, chatId, senderId);
    if (!isBotAdmin) return;
    if (isSenderAdmin) return;

    const linkPatterns = [
        /chat\.whatsapp\.com\/[A-Za-z0-9]{20,}/i,
        /whatsapp\.com\/channel\/[A-Za-z0-9]{20,}/i,
        /t\.me\/[A-Za-z0-9_]+/i,
        /telegram\.me\/[A-Za-z0-9_]+/i,
        /bit\.ly\/[A-Za-z0-9]+/i,
        /tinyurl\.com\/[A-Za-z0-9]+/i,
        /shorturl\.at\/[A-Za-z0-9]+/i,
        /cutt\.ly\/[A-Za-z0-9]+/i,
        /ow\.ly\/[A-Za-z0-9]+/i,
        /is\.gd\/[A-Za-z0-9]+/i,
        /buff\.ly\/[A-Za-z0-9]+/i,
        /(?:www\.)?facebook\.com\/[A-Za-z0-9.]+/i,
        /(?:www\.)?instagram\.com\/[A-Za-z0-9_.]+/i,
        /(?:www\.)?twitter\.com\/[A-Za-z0-9_]+/i,
        /(?:www\.)?tiktok\.com\/@[A-Za-z0-9_.]+/i,
        /(?:www\.)?youtube\.com\/[A-Za-z0-9?=&_]+/i,
        /youtu\.be\/[A-Za-z0-9_-]+/i,
        /https?:\/\/[^\s]+/i,
        /www\.[^\s]+/i
    ];

    let containsLink = false;
    let foundLink = '';

    for (const pattern of linkPatterns) {
        const match = userMessage.match(pattern);
        if (match) {
            containsLink = true;
            foundLink = match[0];
            break;
        }
    }

    if (!containsLink) return;

    try {
        await sock.sendMessage(chatId, { delete: message.key });
    } catch (e) {}

    const action = antilinkConfig.action || 'delete';

    if (action === 'delete') {
        await sendStyledMessage(
            sock,
            chatId,
            `☀️ *LIEN DÉTECTÉ* ☀️\n\n@${senderId.split('@')[0]}, les liens sont interdits ici.\n\n🔥 *Le Lion veille.* 🔥`,
            null,
            { mentions: [senderId] }
        );

    } else if (action === 'kick') {
        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');

        await sendStyledMessage(
            sock,
            chatId,
            `☀️ *EXPULSION* ☀️\n\n@${senderId.split('@')[0]} a été expulsé pour lien : ${foundLink}`,
            null,
            { mentions: [senderId] }
        );

    } else if (action === 'warn') {
        const fs = require('fs');
        const path = require('path');
        const warningsPath = path.join(__dirname, '../data/warnings.json');

        let warnings = {};
        if (fs.existsSync(warningsPath)) {
            warnings = JSON.parse(fs.readFileSync(warningsPath));
        }

        if (!warnings[chatId]) warnings[chatId] = {};
        if (!warnings[chatId][senderId]) warnings[chatId][senderId] = 0;

        warnings[chatId][senderId]++;

        if (warnings[chatId][senderId] >= 3) {
            await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
            delete warnings[chatId][senderId];

            await sendStyledMessage(
                sock,
                chatId,
                `☀️ *EXPULSION APRÈS 3 AVERTISSEMENTS* ☀️\n\n@${senderId.split('@')[0]} expulsé.`,
                null,
                { mentions: [senderId] }
            );
        } else {
            await sendStyledMessage(
                sock,
                chatId,
                `☀️ *AVERTISSEMENT ${warnings[chatId][senderId]}/3* ☀️\n\n@${senderId.split('@')[0]}, les liens sont interdits.`,
                null,
                { mentions: [senderId] }
            );
        }

        fs.writeFileSync(warningsPath, JSON.stringify(warnings, null, 2));
    }
}

module.exports = {
    handleAntilinkCommand,
    handleLinkDetection
};