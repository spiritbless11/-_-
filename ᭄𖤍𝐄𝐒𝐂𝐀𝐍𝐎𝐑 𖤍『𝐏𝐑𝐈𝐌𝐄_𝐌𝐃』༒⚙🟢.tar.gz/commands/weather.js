const axios = require('axios');

module.exports = async function (sock, chatId, message, city) {
    try {
        const apiKey = '4902c0f2550f58298ad4146a92b65e10';
        const response = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`);
        const weather = response.data;
        const weatherText = `☀️ *MÉTÉO – LE LION VOIT CLAIR* ☀️\n\n📍 ${weather.name}\n🌤️ ${weather.weather[0].description}\n🌡️ Température: ${weather.main.temp}°C\n💧 Humidité: ${weather.main.humidity}%\n💨 Vent: ${weather.wind.speed} m/s`;
        await sock.sendMessage(chatId, { text: weatherText }, { quoted: message });
    } catch (error) {
        console.error('☀️ Erreur météo:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️\nVille introuvable ou API indisponible.' }, { quoted: message });
    }
};