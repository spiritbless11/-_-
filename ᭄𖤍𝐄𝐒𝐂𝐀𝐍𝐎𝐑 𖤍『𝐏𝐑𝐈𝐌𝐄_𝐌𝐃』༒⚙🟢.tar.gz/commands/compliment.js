const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: '༄ྀ 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

const compliments = [
"☀️ Tu es digne de te tenir face au Lion.",
"🔥 Ta puissance rivalise avec celle du soleil à son zénith.",
"⚔️ Ton courage ferait trembler les plus grands guerriers.",
"👑 Tu es digne de porter une couronne.",
"🌞 Tu brilles comme l'or sous la lumière du soleil.",
"💪 Une aura impressionnante émane de toi.",
"🦁 Ta présence résonne comme le rugissement du Lion.",
"☀️ Tu es une véritable source d'énergie.",
"🔥 Même le soleil s'incline devant ta grandeur.",
"⚡ Ta lumière n'a aucun égal.",
"👑 Tu es né pour régner, cela ne fait aucun doute.",
"🌞 Ton charisme éclipse les étoiles.",
"💎 Tu es une perle rare et précieuse.",
"🦁 Tu portes en toi l'essence du Lion.",
"☀️ Tu es une légende en devenir.",
"🔥 Ta simple présence fait vibrer ton environnement.",
"⚔️ Ta bravoure est sans faille.",
"👑 Tu incarnes la puissance elle-même.",
"🌞 Tu surpasses tous ceux qui t'entourent.",
"🔥 Même le Lion reconnaît ta grandeur."
];

async function complimentCommand(sock, chatId, message) {
    try {
        if (!message || !chatId) {
            console.log('☀️ Message ou chatId invalide:', { message, chatId });
            return;
        }

        let userToCompliment;
        
        // Mention
        if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            userToCompliment = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }
        // Réponse
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToCompliment = message.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!userToCompliment) {
            await sock.sendMessage(chatId, { 
                text: '☀️ *DÉSIGNE LA PERSONNE À HONORER.* ☀️\nMentionne-la ou réponds à son message.',
                ...channelInfo
            });
            return;
        }

        const compliment = compliments[Math.floor(Math.random() * compliments.length)];

        await new Promise(resolve => setTimeout(resolve, 1000));

        await sock.sendMessage(chatId, { 
            text: `☀️ *ÉCOUTE BIEN* ☀️\n@${userToCompliment.split('@')[0]}, ${compliment}`,
            mentions: [userToCompliment],
            ...channelInfo
        });

    } catch (error) {
        console.error('☀️ Erreur dans la commande compliment:', error);

        if (error.data === 429) {
            await new Promise(resolve => setTimeout(resolve, 2000));
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *TROP DE DEMANDES.* ☀️\nLe Lion se repose. Réessaie dans un instant.',
                    ...channelInfo
                });
            } catch (retryError) {
                console.error('☀️ Erreur envoi message attente:', retryError);
            }
        } else {
            try {
                await sock.sendMessage(chatId, { 
                    text: '☀️ *UNE ERREUR EST SURVENUE.* ☀️\nRéessaie, mortel.',
                    ...channelInfo
                });
            } catch (sendError) {
                console.error('☀️ Erreur envoi message erreur:', sendError);
            }
        }
    }
}

module.exports = { complimentCommand };