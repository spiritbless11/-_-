const axios = require('axios');

const sendStyledMessage = require('../utils/sendStyledMessage');

module.exports = async function (sock, chatId, message) {

    try {

        const response = await axios.get('https://uselessfacts.jsph.pl/random.json?language=en');

        const fact = response.data.text;

        await sendStyledMessage(

            sock,

            chatId,

            `☀️ *FAIT DU LION* ☀️\n\n${fact}`,

            message

        );

    } catch (error) {

        console.error(error);

        await sendStyledMessage(

            sock,

            chatId,

            '☀️ *ÉCHEC DE LA RÉCUPÉRATION.* ☀️\nMême le Lion peut avoir un hoquet.',

            message

        );

    }

};