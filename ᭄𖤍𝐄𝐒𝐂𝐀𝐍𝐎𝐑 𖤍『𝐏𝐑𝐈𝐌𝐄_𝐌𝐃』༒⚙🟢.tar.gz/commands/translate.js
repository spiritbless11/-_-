const fetch = require('node-fetch');

async function handleTranslateCommand(sock, chatId, message, match) {
    try {
        await sock.presenceSubscribe(chatId);
        await sock.sendPresenceUpdate('composing', chatId);

        let textToTranslate = '';
        let lang = '';

        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        if (quotedMessage) {
            textToTranslate = quotedMessage.conversation || 
                            quotedMessage.extendedTextMessage?.text || 
                            quotedMessage.imageMessage?.caption || 
                            quotedMessage.videoMessage?.caption || 
                            '';

            lang = match.trim();
        } else {
            const args = match.trim().split(' ');
            if (args.length < 2) {
                return sock.sendMessage(chatId, {
                    text: `☀️ *TRADUCTEUR* ☀️\n\nUtilisation:\n1. Réponds à un message avec: .translate <langue>\n2. Ou tape: .translate <texte> <langue>\n\nExemple:\n.translate hello fr\n\nCodes langue:\nfr - français\nes - espagnol\nde - allemand\nit - italien\npt - portugais\nru - russe\nja - japonais\nko - coréen\nzh - chinois\nar - arabe\nhi - hindi`,
                    quoted: message
                });
            }

            lang = args.pop();
            textToTranslate = args.join(' ');
        }

        if (!textToTranslate) {
            return sock.sendMessage(chatId, {
                text: '☀️ *DONNE-MOI UN TEXTE À TRADUIRE, MORTEL.* ☀️',
                quoted: message
            });
        }

        let translatedText = null;
        let error = null;

        try {
            const response = await fetch(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(textToTranslate)}`);
            if (response.ok) {
                const data = await response.json();
                if (data && data[0] && data[0][0] && data[0][0][0]) {
                    translatedText = data[0][0][0];
                }
            }
        } catch (e) {
            error = e;
        }

        if (!translatedText) {
            try {
                const response = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(textToTranslate)}&langpair=auto|${lang}`);
                if (response.ok) {
                    const data = await response.json();
                    if (data && data.responseData && data.responseData.translatedText) {
                        translatedText = data.responseData.translatedText;
                    }
                }
            } catch (e) {
                error = e;
            }
        }

        if (!translatedText) {
            try {
                const response = await fetch(`https://api.dreaded.site/api/translate?text=${encodeURIComponent(textToTranslate)}&lang=${lang}`);
                if (response.ok) {
                    const data = await response.json();
                    if (data && data.translated) {
                        translatedText = data.translated;
                    }
                }
            } catch (e) {
                error = e;
            }
        }

        if (!translatedText) {
            throw new Error('All translation APIs failed');
        }

        await sock.sendMessage(chatId, {
            text: `☀️ *TRADUCTION PAR LE LION* ☀️\n\n${translatedText}`,
        }, {
            quoted: message
        });

    } catch (error) {
        console.error('☀️ Erreur translate:', error);
        await sock.sendMessage(chatId, {
            text: '☀️ *ÉCHEC DE LA TRADUCTION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            quoted: message
        });
    }
}

module.exports = {
    handleTranslateCommand
};