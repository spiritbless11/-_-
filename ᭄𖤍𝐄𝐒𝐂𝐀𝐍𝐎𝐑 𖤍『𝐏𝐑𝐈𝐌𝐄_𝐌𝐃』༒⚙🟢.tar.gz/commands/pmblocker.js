const fs = require('fs');
const isOwnerOrSudo = require('../lib/isOwner');

const PMBLOCKER_PATH = './data/pmblocker.json';

function readState() {
    try {
        if (!fs.existsSync(PMBLOCKER_PATH)) return { enabled: false, message: '☀️ *LES MESSAGES PRIVÉS SONT BLOQUÉS.* ☀️\nTu ne peux pas DM le Lion. Rejoins un groupe si tu veux me parler.' };
        const raw = fs.readFileSync(PMBLOCKER_PATH, 'utf8');
        const data = JSON.parse(raw || '{}');
        return {
            enabled: !!data.enabled,
            message: typeof data.message === 'string' && data.message.trim() ? data.message : '☀️ *LES MESSAGES PRIVÉS SONT BLOQUÉS.* ☀️\nTu ne peux pas DM le Lion. Rejoins un groupe si tu veux me parler.'
        };
    } catch {
        return { enabled: false, message: '☀️ *LES MESSAGES PRIVÉS SONT BLOQUÉS.* ☀️\nTu ne peux pas DM le Lion. Rejoins un groupe si tu veux me parler.' };
    }
}

function writeState(enabled, message) {
    try {
        if (!fs.existsSync('./data')) fs.mkdirSync('./data', { recursive: true });
        const current = readState();
        const payload = {
            enabled: !!enabled,
            message: typeof message === 'string' && message.trim() ? message : current.message
        };
        fs.writeFileSync(PMBLOCKER_PATH, JSON.stringify(payload, null, 2));
    } catch {}
}

async function pmblockerCommand(sock, chatId, message, args) {
    const senderId = message.key.participant || message.key.remoteJid;
    const isOwner = await isOwnerOrSudo(senderId, sock, chatId);
    
    if (!message.key.fromMe && !isOwner) {
        await sock.sendMessage(chatId, { text: '☀️ *SEUL MON MAÎTRE PEUT UTILISER CETTE COMMANDE.* ☀️' }, { quoted: message });
        return;
    }
    
    const argStr = (args || '').trim();
    const [sub, ...rest] = argStr.split(' ');
    const state = readState();

    if (!sub || !['on', 'off', 'status', 'setmsg'].includes(sub.toLowerCase())) {
        await sock.sendMessage(chatId, { text: '☀️ *PMBLOCKER (OWNER UNIQUEMENT)* ☀️\n\n.pmblocker on - Activer le blocage des MP\n.pmblocker off - Désactiver\n.pmblocker status - Voir l\'état\n.pmblocker setmsg <message> - Définir le message' }, { quoted: message });
        return;
    }

    if (sub.toLowerCase() === 'status') {
        await sock.sendMessage(chatId, { text: `☀️ *ÉTAT DU PMBLOCKER* ☀️\n\nStatut: ${state.enabled ? 'ACTIF' : 'INACTIF'}\nMessage: ${state.message}` }, { quoted: message });
        return;
    }

    if (sub.toLowerCase() === 'setmsg') {
        const newMsg = rest.join(' ').trim();
        if (!newMsg) {
            await sock.sendMessage(chatId, { text: '☀️ *UTILISATION:* .pmblocker setmsg <message>' }, { quoted: message });
            return;
        }
        writeState(state.enabled, newMsg);
        await sock.sendMessage(chatId, { text: '☀️ *MESSAGE PMBLOCKER MIS À JOUR.* ☀️' }, { quoted: message });
        return;
    }

    const enable = sub.toLowerCase() === 'on';
    writeState(enable);
    await sock.sendMessage(chatId, { text: `☀️ *PMBLOCKER ${enable ? 'ACTIVÉ' : 'DÉSACTIVÉ'}* ☀️` }, { quoted: message });
}

module.exports = { pmblockerCommand, readState };