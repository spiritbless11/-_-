const fetch = require('node-fetch');

async function simpCommand(sock, chatId, quotedMsg, mentionedJid, sender) {
    try {
        let who = quotedMsg 
            ? quotedMsg.sender 
            : mentionedJid && mentionedJid[0] 
                ? mentionedJid[0] 
                : sender;

        let avatarUrl;
        try {
            avatarUrl = await sock.profilePictureUrl(who, 'image');
        } catch (error) {
            console.error('☀️ Erreur photo de profil:', error);
            avatarUrl = 'https://telegra.ph/file/24fa902ead26340f3df2c.png';
        }

        const apiUrl = `https://some-random-api.com/canvas/misc/simpcard?avatar=${encodeURIComponent(avatarUrl)}`;
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`API responded with status: ${response.status}`);
        }

        const imageBuffer = await response.buffer();

        await sock.sendMessage(chatId, {
            image: imageBuffer,
            caption: '☀️ *TA RELIGION EST LE SIMPING, MORTEL.* ☀️',
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363419277738229@newsletter',
                    newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
                    serverMessageId: -1
                }
            }
        });

    } catch (error) {
        console.error('☀️ Erreur dans simp:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ÉCHEC DE LA GÉNÉRATION.* ☀️\nMême le Lion peut avoir un hoquet. Réessaie, mortel.',
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363419277738229@newsletter',
                    newsletterName: '☀️ ESCANOR PRIME – LE LION DE L\'ORGUEIL ☀️',
                    serverMessageId: -1
                }
            }
        });
    }
}

module.exports = { simpCommand };