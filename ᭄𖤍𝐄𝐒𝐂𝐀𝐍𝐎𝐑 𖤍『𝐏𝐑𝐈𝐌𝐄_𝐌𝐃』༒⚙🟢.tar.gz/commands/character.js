const axios = require('axios');

const channelInfo = {
    contextInfo: {
        forwardingScore: 1,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: '120363423626898675@newsletter',
            newsletterName: 'ಢྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',
            serverMessageId: -1
        }
    }
};

async function characterCommand(sock, chatId, message) {
    let userToAnalyze;
    
    // Check for mentioned users
    if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
    }
    // Check for replied message
    else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
        userToAnalyze = message.message.extendedTextMessage.contextInfo.participant;
    }
    
    if (!userToAnalyze) {
        await sock.sendMessage(chatId, { 
            text: '☀️ *DESIGNE LE MORTEL A ANALYSER.* ☀️\nMentionne-le ou reponds a son message, si tu oses.', 
            ...channelInfo 
        });
        return;
    }

    try {
        // Get user's profile picture
        let profilePic;
        try {
            profilePic = await sock.profilePictureUrl(userToAnalyze, 'image');
        } catch {
            profilePic = 'https://i.imgur.com/2wzGhpF.jpeg';
        }

        const traits = [
            "☀️ Fier", "🔥 Puissant", "⚔️ Honorable", "👑 Digne", "🌞 Rayonnant",
            "🛡️ Protecteur", "💪 Indomptable", "✨ Exceptionnel", "🎯 Precis", "🌟 Grand",
            "⚡ Electrisant", "🏆 Vainqueur", "🔱 Indomptable", "🌅 Majestueux", "💥 Explosif",
            "🎖️ Heroique", "🔥 Ardent", "☀️ Radiant", "⚜️ Noble", "💫 Supreme"
        ];

        // Get 3-5 random traits
        const numTraits = Math.floor(Math.random() * 3) + 3;
        const selectedTraits = [];
        while (selectedTraits.length < numTraits) {
            const randomTrait = traits[Math.floor(Math.random() * traits.length)];
            if (!selectedTraits.includes(randomTrait)) {
                selectedTraits.push(randomTrait);
            }
        }

        // Calculate random percentages
        const traitPercentages = selectedTraits.map(trait => {
            const percentage = Math.floor(Math.random() * 41) + 60;
            return `${trait}: ${percentage}%`;
        });

        const analysis = `☀️ *ANALYSE DU LION* ☀️\n\n` +
            `👤 *Mortel:* @${userToAnalyze.split('@')[0]}\n\n` +
            `✨ *Traits detectes:*\n${traitPercentages.join('\n')}\n\n` +
            `🎯 *Puissance absolue:* ${Math.floor(Math.random() * 21) + 80}%\n\n` +
            `☀️ *Note du Lion:* Cette analyse revele ta veritable essence, mortel. Ne la prends pas a la legere, car le Lion voit clair en toi. ☀️`;

        await sock.sendMessage(chatId, {
            image: { url: profilePic },
            caption: analysis,
            mentions: [userToAnalyze],
            ...channelInfo
        });

    } catch (error) {
        console.error('☀️ Erreur dans la commande character:', error);
        await sock.sendMessage(chatId, { 
            text: '☀️ *ECHEC DE L\'ANALYSE.* ☀️\nMeme le Lion peut avoir un hoquet. Reessaie, mortel.',
            ...channelInfo 
        });
    }
}

module.exports = characterCommand;