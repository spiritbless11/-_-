const isAdmin = require('../lib/isAdmin');

async function purgeCommand(sock, chatId, senderId, message) {
    try {
        const { isSenderAdmin, isBotAdmin } = await isAdmin(sock, chatId, senderId);

        if (!isBotAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *FAIS-MOI ADMIN, MORTEL.* ☀️' }, { quoted: message });
            return;
        }

        if (!isSenderAdmin) {
            await sock.sendMessage(chatId, { text: '☀️ *SEULS LES ADMINISTRATEURS PEUVENT PURGER.* ☀️' }, { quoted: message });
            return;
        }

        const groupMetadata = await sock.groupMetadata(chatId);
        const participants = groupMetadata.participants;
        const groupOwner = groupMetadata.owner;

        if (!participants || participants.length === 0) {
            await sock.sendMessage(chatId, { text: '☀️ *AUCUN MEMBRE À PURGER.* ☀️' }, { quoted: message });
            return;
        }

        const membersToRemove = participants
            .filter(p => !p.admin && p.id !== groupOwner)
            .map(p => p.id);

        if (membersToRemove.length === 0) {
            await sock.sendMessage(chatId, { text: '☀️ *AUCUN NON-ADMIN À PURGER.* ☀️' }, { quoted: message });
            return;
        }

        for (let member of membersToRemove) {
            await sock.groupParticipantsUpdate(chatId, [member], "remove");
            await new Promise(resolve => setTimeout(resolve, 1000));
        }

        await sock.sendMessage(chatId, {
            text: `☀️ *PURGE TERMINÉE* ☀️\n${membersToRemove.length} mortels ont été expulsés par le Lion.`
        }, { quoted: message });

    } catch (error) {
        console.error('☀️ Erreur dans la commande purge:', error);
        await sock.sendMessage(chatId, { text: '☀️ *ÉCHEC DE LA PURGE.* ☀️\nMême le Lion peut avoir un hoquet.' }, { quoted: message });
    }
}

module.exports = purgeCommand;