const escanorImages = [

    'https://i.imgur.com/vuxb8q8.jpeg',

    'https://i.imgur.com/bnNqadw.jpeg',

    'https://i.imgur.com/dPs7W0M.jpeg',

    'https://i.imgur.com/yfzN3SF.jpeg',

    'https://i.imgur.com/CsM1J92.jpeg',

    'https://i.imgur.com/TJZIVMK.jpeg',

    'https://i.imgur.com/3m25faw.jpeg',

    'https://i.imgur.com/usGavWl.jpeg',

    'https://i.imgur.com/zN44oon.jpeg',

    'https://i.imgur.com/wq4KEVB.jpeg',

    'https://i.imgur.com/O8fAOox.jpeg'

];

const channelInfo = {

    forwardingScore: 1,

    isForwarded: true,

    forwardedNewsletterMessageInfo: {

        newsletterJid: '120363423626898675@newsletter',

        newsletterName: 'ೄྀ . 🌸 🅓𝐄𝐕 𝐋𝐀𝐁 𝐁𝐘 ᥬ𝐌𝐑 𝐁𝐋𝐄𝐒𝐒᭄ 🅓𝐄𝐕 💻 ୨ ིྀ ˚ᬊ',

        serverMessageId: -1

    }

};

/**

 * ☀️ ENVOI DE MESSAGE STYLISÉ AVEC MENTIONS ☀️

 * @param {object} sock - Instance Baileys

 * @param {string} chatId - JID du destinataire

 * @param {string} text - Texte du message

 * @param {object} quoted - Message cité (optionnel)

 * @param {array} mentions - Tableau de JIDs pour les mentions [@user1@s.whatsapp.net, @user2@s.whatsapp.net]

 * @param {object} extraOptions - Options supplémentaires (contextInfo personnalisé, etc.)

 */

async function sendStyledMessage(sock, chatId, text, quoted = null, mentions = [], extraOptions = {}) {

    // 🎲 Choisir une image aléatoire

    const randomImage = escanorImages[Math.floor(Math.random() * escanorImages.length)];

    // 🔀 Fusionner le channelInfo par défaut avec les options personnalisées

    const mergedContextInfo = {

        ...channelInfo,

        ...(extraOptions.contextInfo || {})

    };

    return await sock.sendMessage(chatId, {

        image: { url: randomImage },

        caption: text,

        mentions: mentions, // 👈 PARAMÈTRE CRUCIAL POUR LES MENTIONS CLIQUABLES

        contextInfo: mergedContextInfo,

        ...extraOptions // Autres options (adReply, etc.)

    }, { quoted });

}

module.exports = sendStyledMessage;